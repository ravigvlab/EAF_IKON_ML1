import time
t0 = time.time()
import configparser
import subprocess
import threading
import sys, getopt
import os
from schedule_common import get_common_args, get_config, check_process, end_process, reset_account_process

# Arguments
argumentList = sys.argv[1:]

args_list = get_common_args(argumentList)
accountName = args_list[0]
processName = args_list[1]
sub_process_args = '--accountName ' + accountName

def  incident_score():
    ##################### calling incident score file #########################

   
    print('python ' + commonsFolderPath + 'incident_score_common.py '+ sub_process_args)#, shell=True)
    inc_score_result = subprocess.call('python '+ commonsFolderPath + 'incident_score_common.py '+ sub_process_args)#, shell=True)
    print(inc_score_result)
    
def  level1():

    ##################### calling incident ko link file #######################                     
    print('python ' + commonsFolderPath + 'inc_ko_link_common.py '+ sub_process_args)#, shell=True)            
    inc_ko_link_result = subprocess.call('python ' + commonsFolderPath + 'inc_ko_link_common.py '+ sub_process_args)#, shell=True)            
    print(inc_ko_link_result)
    
def  level2():

    ################## calling ko ko similarity file ####################
    print('python ' + commonsFolderPath + 'ko_processing_common.py '+ sub_process_args)#, shell=True)
    inc_ko_similarity_result = subprocess.call('python ' + commonsFolderPath + 'ko_processing_common.py '+ sub_process_args)#, shell=True)                             
    print(inc_ko_similarity_result)  

 
def level3():
    ################## calling incident ko similarity file ####################

    print('python ' + commonsFolderPath + 'inc_ko_similarity_common.py '+ sub_process_args)#, shell=True)
    inc_ko_similarity_result = subprocess.call('python ' + commonsFolderPath + 'inc_ko_similarity_common.py '+ sub_process_args)#, shell=True)                              
    print(inc_ko_similarity_result)    
 
def relevancy_main():
    ################## calling relevancy main file ####################

    print('python ' + commonsFolderPath + 'relevancy_main_common.py '+ sub_process_args)#, shell=True)
    relevancy_main_result = subprocess.call('python '+ commonsFolderPath + 'relevancy_main_common.py '+ sub_process_args)#, shell=True)
    print(relevancy_main_result)

#####  DL
def ikon_dl():

    ################## calling relevancy main file ####################

    print('python ' + commonsFolderPath + 'inc_send_ko_proposal_common.py '+ sub_process_args)#, shell=True)
    dl_error = subprocess.call('python '+ commonsFolderPath + 'inc_send_ko_proposal_common.py '+ sub_process_args)#, shell=True)
    print(dl_error)
    
    
def auto_ko():

    print('python ' + commonsFolderPath + 'auto_ko_creation.py '+ sub_process_args)#, shell=True)
    ko_error = subprocess.call('python '+ commonsFolderPath + 'auto_ko_creation.py '+ sub_process_args)#, shell=True)
    print(ko_error)
   
try:
    print('going to read config file')
    print('account Name: ', accountName)
    config = get_config(accountName)
    commonsFolderPath = config.get('PathsSection', 'path.commons')
    includeLevel2 = int(config.get('FileSection', 'file.level2'))
    send_proposal = int(config.get('DatalakeSection', 'send.proposal'))
    multitenant = int(config.get('Multitanancy', 'check.running.process'))
    print(' --------------------- multitenant -----------------: ', multitenant)
    
    ## ko creation section
    ko_creation = int(config.get('KoCreationSection', 'ko.creation'))
    
    config_file = configparser.RawConfigParser()
    configFile = os.path.join(os.getcwd(), "conf", "CommonConfigFile.properties")
    config_file.read(configFile)
    config_Db = config_file.get('GenericSection', 'conf.Db')

    NonCiap = int(config.get('GenericSection', 'account.type.nonciap'))
    print('reading config file is done')
    
except Exception as e:
    print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
    print(str(e))
    
else:
    ########################## declaring threads #############################
    if check_process(accountName, processName):        
        sys.exit()    

try:
    if multitenant == 1:
        reset_account_process(accountName, processName)
        

    ######################### declaring threads #############################
    print('__________________ incident score ______________________')
    t1 = threading.Thread(target=incident_score) 
    t2 = threading.Thread(target=level1) 
    if includeLevel2 == 1:
        t3 = threading.Thread(target=level2)
    t4 = threading.Thread(target=level3)
    t5 = threading.Thread(target=relevancy_main)
    if NonCiap != 1:
        if send_proposal == 1:
            t6 = threading.Thread(target=ikon_dl) 
    if ko_creation == 1:
        t7 = threading.Thread(target=auto_ko) 
 
    ######################## initializing threads #############################
    t1.start() 
    t1.join()
    t2.start()
    t2.join()
    if includeLevel2 == 1:
        t3.start()
        t3.join()
    t4.start()
    t4.join()
    t5.start()
    t5.join()
    if NonCiap != 1:
        if send_proposal == 1:
            print("creating thread 6")
            t6.start()
            t6.join()
            print("thread 6 completed in Data Lake")
            
    time.sleep(30)
    if ko_creation == 1:

        print("creating thread 7")
        t7.start()
        t7.join()
        print("thread 7 completed in auto ko creation")
except Exception as e:
    print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
    print(str(e))
    
finally:
    print('Incidents Feed Processed!')
    end_process(accountName, processName)   
    t1 = time.time()
    print(f'script runing time in {round(t1-t0,3)} seconds \n')

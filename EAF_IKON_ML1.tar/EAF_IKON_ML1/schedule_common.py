import os
import sys
import configparser
import pandas as pd
import numpy as np
from datetime import datetime
from common_module.DatabaseFunctions import DatabaseFunctions
import getopt
from azure.keyvault.secrets import SecretClient
from azure.identity import ClientSecretCredential
import requests
from ast import literal_eval
import json

def check_process(account_name, process_name):
    try:
        print("++++++++++++++++++++++++++++++++ Checking process started")
        check_process_config = get_config(account_name)
        dbDetail = get_dbdetail(check_process_config)
        dbName = dbDetail['dbName']
        host = dbDetail['host']
        user = dbDetail['user']
        password = dbDetail['password']
        port = dbDetail['port']
        schema = dbDetail['schema']

        check_running_process = int(check_process_config.get('Multitanancy', 'check.running.process'))
        running_threshold = int(check_process_config.get('Multitanancy', 'running.threshold'))

        psql_check = DatabaseFunctions(host, user, password, port, dbName, schema)
        print("Connected successfully!!!")
        
    except Exception as e:
        print(str(e))
        sys.exit()

    if check_running_process:
        table_name =  'lock_process_' + process_name
        sheduler_time = psql_check.select_df(table_name)
        # print(sheduler_time.head())

        if len(sheduler_time) > 0:
            current_porcess_creationtime = sheduler_time['createdtime'][0].to_pydatetime()
            current_porcess_currenttime = datetime.now()

            print("Process already running")

            if (current_porcess_currenttime -  current_porcess_creationtime).total_seconds()/60 > running_threshold:
                print("Process running for longer than " + str(running_threshold) + " minutes. Unlocking the process to run new instance.")
                psql_check.delete_df(sheduler_time, table_name, {'id'})
                return True

        sheduler_time = sheduler_time.append({'id': 1, 'createdtime':datetime.now()}, ignore_index=True)
        psql_check.upsert_df(sheduler_time, table_name)
        return False
    print("++++++++++++++++++++++++++++++++ Checking process ended")
    return False
 
def reset_account_process(account_name, process_name):
    try:
        print("================================== reset_account_process started")
        reset_process_config = get_config()
        check_running_process = int(reset_process_config.get('Multitanancy', 'check.running.process'))
        
        if check_running_process:
    
            reset_account_process_config = get_config()

            dbDetail = get_dbdetail(reset_account_process_config)
            dbName = dbDetail['dbName']
            host = dbDetail['host']
            user = dbDetail['user']
            password = dbDetail['password']
            port = dbDetail['port']
            schema = dbDetail['schema']

            psql_reset = DatabaseFunctions(host, user, password, port, dbName, schema)

            psql_reset.delete_sql('account_processes', {'type': process_name, 'tenant': account_name, 'createdtime:<': str(datetime.now())})
            print("================================== reset_account_process ended")
    except Exception as e:
        print("Could not connect to postgresql to reset account process in schedule_common and error is--->" + str(e))
        sys.exit()
        
# def reset_account_process(account_name, process_name):
    # try:
        # reset_account_process_config = get_config()

        # dbDetail = get_dbdetail(reset_account_process_config)
        # dbName = dbDetail['dbName']
        # host = dbDetail['host']
        # user = dbDetail['user']
        # password = dbDetail['password']
        # port = dbDetail['port']
        # schema = dbDetail['schema']

        # psql_reset = DatabaseFunctions(host, user, password, port, dbName, schema)

        # psql_reset.delete_sql('account_processes', {'type': process_name, 'tenant': account_name, 'createdtime:<': str(datetime.now())})

    # except Exception as e:
        # print("Could not connect to postgresql to reset account process in schedule_common and error is--->" + str(e))
        # sys.exit()
   
def end_process(account_name, process_name):
    try:
        end_process_config = get_config(account_name)

        dbDetail = get_dbdetail(end_process_config)
        dbName = dbDetail['dbName']
        host = dbDetail['host']
        user = dbDetail['user']
        password = dbDetail['password']
        port = dbDetail['port']
        schema = dbDetail['schema']

        check_running_process = int(end_process_config.get('Multitanancy', 'check.running.process'))

        psql_check = DatabaseFunctions(host, user, password, port, dbName, schema)
        print("Connected successfully!!!")

    except Exception as e:
        print(str(e))
        sys.exit()

    if check_running_process:
        table_name =  'lock_process_' + process_name
        sheduler_time = psql_check.select_df(table_name)

        if len(sheduler_time) > 0:
            psql_check.delete_df(sheduler_time, table_name, {'id'})

def get_common_args(argumentList):
    # Options
    short_options = "a:p:"
    # Long options
    long_options = ["accountName=","processName="]

    accountName = ''
    processName = ''
    args_list = []

    try:
        # Parsing argument
        arguments, values = getopt.getopt(argumentList, short_options, long_options)
        # checking each argument
        for currentArgument, currentValue in arguments:
            if currentArgument in ("-a","--accountName"):
                print ("accountName: ", currentValue)
                accountName=currentValue
            elif currentArgument in ("-p","--processName"):
                print ("processName: ", currentValue)
                processName=currentValue
    except getopt.error as err:
        # output error, and return with an error code
        print (str(err))
        sys.exit()

    if( accountName == '' or processName == ''):
        print("Required arguments missing. List of required arguments: accountName, processName")
        sys.exit()

    args_list = [accountName, processName]

    return args_list


def print_config(config):
    for section in config.sections():
        print(f"[{section}]")
        for option in config[section]:
            value = config.get(section, option)
            print(f"{option} = {value}")

def get_config(accountName=""):
    print('============== account name =============: ', accountName)
    config = configparser.RawConfigParser()
    if (os.getenv('IKON_CONFIG_HOME')):
        configFile = os.path.join(os.getenv('IKON_CONFIG_HOME'), "CommonConfigFile.properties")
    else:
        configFile = os.path.join(os.getcwd(), "conf", "CommonConfigFile.properties")
    config.read(configFile)
    config_Db = config.get('GenericSection', 'conf.Db')
    if int(config_Db) == 1 and accountName != "":
        try:
            
            db_detail = get_dbdetail(config)
            dbName = db_detail['dbName']
            host = db_detail['host']
            port = db_detail['port']
            schema = db_detail['schema']
            user = db_detail['user']
            password = db_detail['password']

            psql = DatabaseFunctions(host, user, password, port, dbName, schema)
            conf_final = psql.select_df('account_config', 'account_name', [accountName])
            
            conf_final = conf_final.drop(['account_name'], axis=1)
            conf_final = conf_final.reset_index(drop=True)
            config = configparser.ConfigParser()
            for section_name in conf_final.columns:
                try:
                    config.add_section(section_name)
                    data = json.loads(conf_final[section_name][0])
                    if isinstance(data, dict):
                        for key, value in data.items():
                            config.set(section_name, key, value)
                            # print("##############################")
                            # print_config(config)
                            # print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
                    else:
                        print(f"Section '{section_name}' data is not a valid JSON object: {conf_final[section_name][0]}")
  
                     
                except Exception as e:
                    print(f"Error processing section '{section_name}': {e}")
            
                
        except Exception as error:
            print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(error).__name__, error)
            print('common==>  ', error)
            
    else:
        if(accountName != ""):
            accountConfig = configparser.RawConfigParser()

            if (os.getenv('IKON_CONFIG_HOME')):
                accountConfigFile = os.path.join(os.getenv('IKON_CONFIG_HOME'), accountName, "ConfigFile.properties")
            else:
                accountConfigFile = os.path.join(os.getcwd(), "conf", accountName, "ConfigFile.properties")
                print(accountConfigFile)

            accountConfig.read(accountConfigFile)

            for sectionKey in accountConfig:
                for key in accountConfig[sectionKey]:
                    value = accountConfig.get(sectionKey, key)
                    config.set(sectionKey, key, value)

    return config

def AwsResponseValidation(data):
    data = literal_eval(data.decode('utf8'))
    data = data['value']
    data = data.replace('"{"','{"').replace('"}"','"}')
    data = json.loads(data)
    data = list(data.values())[0]
    usrName = data['user']
    Pwd = data['password']
    return[Pwd, usrName] 


def get_dbdetail(config):

    dbDetail = {}

    dbDetail['dbName'] = config.get('DatabaseSection', 'database.dbname')
    dbDetail['host'] = config.get('DatabaseSection', 'database.host')
    dbDetail['port'] = config.get('DatabaseSection', 'database.port')
    dbDetail['schema'] = config.get('DatabaseSection', 'database.schema')
    
    awssection = int(config.get('AWSSection', 'API.proposal'))
    filter=config.get('FilterSection','filter.AG')
    azuresection = int(config.get('VaultSection', 'azure.keyvault'))
    if awssection == 1:
        try:
            token =config.get('AWSSection', 'API.token')
            url = config.get('AWSSection', 'API.url')
            tenentUserName = config.get('DatabaseSection', 'database.user')
            tenentPasword = config.get('DatabaseSection', 'database.password')
            url_username = url+'key='+str(tenentUserName)
            url_Pasword = url+'key='+str(tenentPasword)
            payload_header = {"Content-Type":"application/json", "Authorization": "Bearer "+str(token)}
            response = requests.get(url = url_username, headers =payload_header)
            print("Printing the response in Schedule_Common: ",response)
            if response.status_code == 200 or response.status_code == 201:
                print("response status is ", str(response.status_code))
            else:
                print("response status is ", str(response.status_code))
            validation_result = AwsResponseValidation(response.content)
            dbDetail['user'] = validation_result[1]
            dbDetail['password'] = validation_result[0]
        except Exception as e:
            raise Exception("Unable to get the DB detail from AWSkeyManager") from e
    elif azuresection == 1:

        client_id = config.get('VaultSection', 'azure.application.client.id')
        tenant_id = config.get('VaultSection', 'azure.application.tenant.id')
        client_secret = config.get('VaultSection', 'azure.application.client.key')
        KeyUri = config.get('VaultSection', 'azure.secret.vault.url')

        try:
            credentials = ClientSecretCredential(client_id=client_id, client_secret=client_secret,tenant_id=tenant_id)
            secrets = SecretClient(vault_url=KeyUri, credential=credentials)

            userkey = config.get('DatabaseSection', 'database.user')
            passwordkey = config.get('DatabaseSection', 'database.password')

            dbDetail['user'] = secrets.get_secret(userkey).value
            dbDetail['password'] = secrets.get_secret(passwordkey).value

        except Exception as e:
            raise Exception("Unable to get the DB detail from Vault") from e

    else:
        dbDetail['user'] = config.get('DatabaseSection', 'database.user')
        dbDetail['password'] = config.get('DatabaseSection', 'database.password')

    return dbDetail


# python schedule_ikon.py -a TEST1
# from common_module import common_functions
import configparser
import os
import subprocess
import threading
import sys, getopt
from datetime import datetime



# Arguments
argumentList = sys.argv[1:]
 
# Options
short_options = "a:"
 
# Long options
long_options = ["accountName ="]
 
try:
    # Parsing argument
    arguments, values = getopt.getopt(argumentList, short_options, long_options)

    # checking each argument
    for currentArgument, currentValue in arguments:
            
        if currentArgument in ("-a","--accountName"):
            print ("accountName: ", currentValue)
            accountName=currentValue
        
except getopt.error as err:
    # output error, and return with an error code
    print (str(err))
    sys.exit()



types = {'schedule_inc.py':'inc','schedule_ko.py':'ko'}


try:
    for type in types:
        print('type is: ', type)
        process_result = subprocess.Popen('python ' + type + ' -a ' + accountName + ' -p ' +types[type] , shell=True )

except Exception as error:
    print("Error in the sub processed file ", error)


    


import subprocess
import os
import sys
import configparser
from common_module.DatabaseFunctions import DatabaseFunctions
from schedule_common import get_config, get_dbdetail

try:
    config = get_config()  
    dbName = config.get('DatabaseSection', 'database.dbname')
    host = config.get('DatabaseSection', 'database.host')
    port = config.get('DatabaseSection', 'database.port')
    schema = config.get('DatabaseSection', 'database.schema')
    user = config.get('DatabaseSection', 'database.user')
    password = config.get('DatabaseSection', 'database.password')

    dbDetail = get_dbdetail(config)
    db_name = dbDetail['dbName']
    host_name = dbDetail['host']
    user_id = dbDetail['user']
    pwd = dbDetail['password']
    port_no = dbDetail['port']
    schema = dbDetail['schema']

    psql = DatabaseFunctions(host_name, user_id, pwd, port_no,db_name,schema)
    
    print('Connected successfully!!!')
except Exception as e:
    print("Could not connect to postgresql in incident ko link file and error is--->" + str(e))
    print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, error)
    sys.exit()

lst= dict()
scheduler_files = config.get('FileSection', 'file.files').split(",")
scheduler_files_list = (file.split(':') for file in scheduler_files)
lst = {type: script for type,script in scheduler_files_list}

tenent = psql.select_df('account_processes', 'processed', [0])
print('###########Printing the contents of account process table#########')
print(tenent) 
distinct_account = list(set(tenent['tenant'].to_list()))
print('distinct_account', distinct_account)

for account in distinct_account:
    types = list(set(tenent[tenent['tenant'] == account]['type'].to_list()))
    print('@@@@@@@@@types',types)
    try:
        for type in types:
            print('@@@@@@@@@@@ type', type)
            process_result = subprocess.Popen('python ' + lst[type] + ' -a ' + account + ' -p ' +type )#, shell=True )
            print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ process_result:", process_result)

    except Exception as error:
        print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, error)
        print("Error in the sub processed file ", error)


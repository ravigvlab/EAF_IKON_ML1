# =========================================================================================================================
# File Name     : inc_ko_similarity_common.py
# -------------------------------------------------------------------------------------------------------------------------
# Purpose       : Purpose of this script is to find most Ko's incidents.
# Author        : Sai, Harinadh Reddy
# Co-Author     : 
# Creation Date : 11-NOV-2022
# Usage         : 'python ' + commonsFolderPath + 'inc_ko_similarity_common.py --accountName ' + accountName
# History       :
# -------------------------------------------------------------------------------------------------------------------------
# Date          | Author                       | Co-Author                    | Remark
# 11-Nov-2022   | Sai, Harinadh Reddy          |                              | Initial Release
# =========================================================================================================================
###########################################################################################################################
# Import required Module / Packages
###########################################################################################################################


import common_functions
from common_functions import multilingual #,model                                                
from typing import List
import sys,getopt
import nltk
from datetime import datetime
import pandas as pd
import os
import numpy as np
from DatabaseFunctions import DatabaseFunctions
from sklearn.feature_extraction.text import TfidfVectorizer
from sparse_dot_topn import awesome_cossim_topn
from scipy.sparse import csr_matrix
import warnings
import ast

warnings.filterwarnings("ignore")

error_string = ''
runid = 0
logger_inc_ko_similarity = ''
df_inc_ko_similarity_score = pd.DataFrame()
no_of_feed_inc = 0
no_of_inc_ko_sim = 0
start_time = datetime.now()
runid = datetime.now().strftime('%Y%m%d%H%M%S')  # + str(uuid4())

# Arguments
argumentList = sys.argv[1:]
args_list = common_functions.get_common_args(argumentList)
accountName = args_list[0]

try:

    config = common_functions.get_config(accountName) 
    dbDetail = common_functions.get_dbdetail(config)
    dbName = dbDetail['dbName']
    host = dbDetail['host']
    user = dbDetail['user']
    password = dbDetail['password']
    port = dbDetail['port']
    schema = dbDetail['schema']    
    accountLogPath = config.get('PathsSection', 'path.log')

    ###################### fetching email details #############################
    emailSender = config.get('EmailSection', 'email.sender')
    emailReceiver = config.get('EmailSection', 'email.receiver')

    ###################### fetching status details ############################
    # closedStatusList = config.get('StatusSection', 'status.closed')
    koStatusList = config.get('StatusSection', 'status.ko')

    ###################### fetching threshold details #########################
    ticketThreshold = config.get('GenericSection', 'max.records.singlethread')

    ### log file creating ###
    LOG_DIR = os.path.join(accountLogPath,accountName,"level3_logs")
    if not os.path.exists(LOG_DIR):
        os.makedirs(LOG_DIR)
    LOG_FILENAME = os.path.join(LOG_DIR, f"{accountName}_Level3_ikon2_logger_{runid}.log")

    print(LOG_FILENAME)
    logger_inc_ko_similarity, log_capture_string  = common_functions.getLogger(LOG_FILENAME,accountName)

    AGfilter = int(config.get('FilterSection', 'filter.AG'))
    ANfilter = int(config.get('FilterSection', 'filter.AN'))

    ## generic section 
    nonciap = int(config.get('GenericSection', 'account.type.nonciap'))   
    batch_size = int(config.get('GenericSection', 'max.train.batch'))
    processGenericKo = int(config.get('GenericSection', 'sap.flag'))


    if processGenericKo == 1: 
        ###################### fetching generic database details #############################
        genericDbName = config.get('DatabaseSection', 'generic_database.dbname')
        genericHost = config.get('DatabaseSection', 'generic_database.host')
        genericUser = config.get('DatabaseSection', 'generic_database.user')
        genericPassword = config.get('DatabaseSection', 'generic_database.password')
        genericPort = config.get('DatabaseSection', 'generic_database.port')
        genericSchema = config.get('DatabaseSection', 'generic_database.schema')                 
    if koStatusList != '':
        koStatusList = koStatusList.split(',')
        
        print('koStatusList: ', koStatusList)
                                                           
    port=int(port)
    default_lang = config.get('SupportLanguage', 'default_lang')
    support_langs = config.get('SupportLanguage', 'lang_supported')
    support_langs = ast.literal_eval(support_langs)
    multi_language = config.get('SupportLanguage', 'multi_language')
    multi_language = int(multi_language)

    ## loading lemma model
    multilingual = multilingual(accountName)
    load_lemma_model = multilingual.load_model(support_langs)

    ## ko creation section
    
    ko_creation = int(config.get('KoCreationSection', 'ko.creation'))
    auto_kostatus = config.get('KoCreationSection', 'auto.kostatus')
    
except Exception as e:
    print ("Error occured while reading the config or setting up logger in inc_ko_similarity: " + str(e))
    print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
    # logger_inc_ko_similarity.error("Exception occured  "+str(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
    sys.exit() 


feed_name = "Incident KO Similarity Process"
sub = "Incident KO Similarity Process"
html = """<br>Summary of Incident KO Similarity Process run for incident feed(""" + str(runid) + """)<br>
    start time = """ + str(start_time) + """<br>
    end time = """ + str(datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")) + """<br>
    No.of records in feed = """ + str(no_of_feed_inc) + """<br>
    No.of incidents for which incident ko similarity is created = """ + str(no_of_inc_ko_sim) + """
    """

data = """{"inc_in_feed": """ + str(no_of_feed_inc) + """,
       "no_of_inc_ko_sim": """ + str(no_of_inc_ko_sim) +"""}"""

logger_inc_ko_similarity.debug("incident ko similarity file run started at "+datetime.strftime(
                start_time, "%Y-%m-%d %H:%M:%S"))

try:
    psql = DatabaseFunctions(host, user, password, port,dbName,schema, config= config) 
except Exception as e:
    print(
        "Could not connect to postgresql in incident ko similarity file and error is--->" +
        str(e))
    logger_inc_ko_similarity.error(
        "Incident ko similarity file process failed due to postgresql connectivity issue\n")
    sys.exit()
else:
    print("Connected successfully!!!")
try:
    if processGenericKo == 1:
        generic_psql = DatabaseFunctions(genericHost, genericUser, genericPassword, genericPort, genericDbName, genericSchema)
    else:
        pass
except Exception as e:
    print(
        "Could not connect to postgresql in incident ko similarity file and error is--->" +
        str(e))
    logger_inc_ko_similarity.error(
        "Incident ko similarity file process failed due to postgresql connectivity issue\n")
    sys.exit()
else:
    print("Connected successfully!!!")

def cosine_similarity(from_df,
                        to_df,
                        from_field,
                        to_field,
                        from_id,
                        to_id,
                        ngram_range=(1,3),

                      nbest: int =10,  #top_n: int = 1
                      min_similarity: float = 0) -> pd.DataFrame:


    from_df[from_field] = from_df[from_field].values.astype('U')
    from_list = from_df[from_field].tolist()

    to_df[to_field] = to_df[to_field].values.astype('U')
    to_list=to_df[to_field].tolist()

    vectorizer = TfidfVectorizer(analyzer='word', ngram_range=ngram_range).fit(to_list + from_list)
    to_vector = vectorizer.transform(to_list)
    from_vector = vectorizer.transform(from_list)

    if int(nbest) >  len(to_list):
        nbest=len(to_list)

    if isinstance(to_vector, np.ndarray):
        to_vector = csr_matrix(to_vector)
    if isinstance(from_vector, np.ndarray):
        from_vector = csr_matrix(from_vector)
        
    from_inc = from_df[from_id].to_list()
    to_inc=to_df[to_id].to_list()   
        
    if int(nbest) <= 1:
        similarity_matrix = awesome_cossim_topn(from_vector, to_vector.T, 2, min_similarity)
        indices = np.array(similarity_matrix.argmax(axis=1).T).flatten()
        similarity = similarity_matrix.max(axis=1).toarray().T.flatten()
        
        matches = [to_list[idx] for idx in indices.flatten()]
        ids = [to_inc[idx] for idx in indices.flatten()]
        matches = pd.DataFrame(np.vstack((from_inc, similarity, ids)).T, columns=["inc_id", "inc_ko_similarity_score","similar_ko"])

    else:
        similarity_matrix = awesome_cossim_topn(from_vector, to_vector.T, nbest, min_similarity)
        similarity = np.flip(np.take_along_axis(similarity_matrix.toarray(), np.argsort(similarity_matrix.toarray(), axis =1), axis=1) [:,-int(nbest):], axis = 1)
        indices = np.flip(np.argsort(np.array(similarity_matrix.toarray()), axis =1)[:,-int(nbest):], axis = 1)
        matches = [np.array([to_list[idx] for idx in l]) for l in indices] ##In progress
        simlarity_list = [ ]
        dict1 ={}
        for sim in similarity:
            simlarity_list.extend(sim)
        ids = [to_inc[idx] for idx in indices.flatten()]
        incidents=[]
        for inc in from_inc:
            incidents.extend([inc for i in range(nbest)])
        dict1['inc_id'] = incidents
        dict1['similar_ko'] = ids
        dict1['inc_ko_similarity_score'] = simlarity_list
        matches = pd.DataFrame(dict1)
    return matches

def batchprocessing(df_open_4, to_df, batch_size, form_text, to_text, from_id, to_id):
    resultdf = pd.DataFrame()
    for i in range(0,to_df.shape[0],batch_size):
        df_part = to_df[i:i+batch_size]
        print("batch length: ", len(df_part))
        
        df_res = cosine_similarity(df_open_4, df_part, form_text, to_text, from_id, to_id, (1,3), 10, 0)
        resultdf = pd.concat([df_res, resultdf])
    
    resultdf = resultdf.sort_values(['test_incid', 'inc_similarity_score'], ascending = False).groupby('test_incid').head(10).reset_index(drop=True)
    return resultdf

def transaction(iserror):
    status = ''
    if iserror == 0:
        status = "success"
    else:
        status = "failed"
    df=pd.DataFrame(columns=['run_id', 'active', 'start_time', 'end_time', 'inc_in_feed','no_of_inc_ko_sim', 'status'])
    df = df.append(pd.Series([runid,0, datetime.strftime(start_time, "%Y-%m-%d %H:%M:%S"),datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S"), no_of_feed_inc,no_of_inc_ko_sim,status], index=df.columns ), ignore_index=True)
    psql.upsert_df(df, 'run_transactions_mongo')


                                ################  *** Main Code Starts ***  ####################

if error_string == '':
    if processGenericKo == 1:
        df_generic_account_ko_mapping = common_functions.read_table_data('generic_account_ko_mapping_mongo',psql)
        if len(df_generic_account_ko_mapping) == 0:
            mapping_df = pd.DataFrame(columns = ['generic_id','acc_ko_id','link_date'])
        else:
            mapping_df = df_generic_account_ko_mapping.copy()
    else:
        mapping_df = pd.DataFrame(columns = ['generic_id','acc_ko_id','link_date'])
    logger_inc_ko_similarity.debug("Reading the contents of ticket_data_inter_staging_mongo table")
    df_inc = common_functions.read_table_data('ticket_data_inter_staging_mongo',psql)
    
    logger_inc_ko_similarity.debug("No of incidents came from staging mongo table are:%s,.Incidents are:\n%s",str(len(df_inc)),df_inc['Incident_id'])
    print("Printing ticket_data_inter_staging_mongo records:\n",df_inc.head())
   
    no_of_feed_inc = len(df_inc)
    print("Length of ticket_data_inter_staging_mongo: ",no_of_feed_inc)

    if len(df_inc) == 0:
        print(error_string)
        logger_inc_ko_similarity.debug(
            "ticket_data_inter_staging_mongo table has no records hence exiting the program")
        mes = ""
        common_functions.send_email(sub, mes, 0, LOG_FILENAME, log_capture_string, html,psql,emailSender,emailReceiver)
        transaction(0)
        sys.exit()

    logger_inc_ko_similarity.debug("Reading the data from ko_detail_history_mongo table")
    df_ko = common_functions.read_table_data('ko_detail_history_mongo',psql)
    print("Printing contents of ko_detail_history_mongo:\n",df_ko)
    logger_inc_ko_similarity.debug("No of entries in ko_detail_history_mongo are:%s,.Kos are:\n%s",str(len(df_ko)),df_ko['Ko_id'])
    

    
    
    
###  Below code is duplicated so commented    
# =============================================================================
#     print('length of df_ko is: ', len(df_ko))
#     df_ko = df_ko[df_ko.Ko_status == "1"]   ##  Read from config file
#     print('length of df_ko is: ', len(df_ko))
#     df_ko = df_ko[df_ko.Publication_status.isin(koStatusList)]
# =============================================================================
    
    print('length of df_ko is: ', len(df_ko))
    if nonciap == 1: 
        df_ko['Module_name'] = ''
        df_generic_ko = pd.DataFrame()
        if processGenericKo == 1:
        
            
            ko_enabled = psql.select_df('account_info_detail')
            ko_enabled_flag = list(ko_enabled['isgeneric'])
            ko_enabled_flag = int(ko_enabled_flag[0])
        
            # account_info_detail['isgeneric']
            if ko_enabled_flag == 2:
                df_generic_ko = common_functions.read_table_data('ko_detail_history_mongo', generic_psql)
                df_ko = pd.concat([df_ko,df_generic_ko])
                logger_inc_ko_similarity.debug("Proposing ko's from both account and generic ko's")
            if ko_enabled_flag == 1:
                df_ko = common_functions.read_table_data('ko_detail_history_mongo', generic_psql)
                print("Length of ko_detail_history_mongo in processGenericKo: ",df_ko)
                logger_inc_ko_similarity.debug("Proposing ko's from only generic ko's")
            #logger_inc_ko_similarity.debug("No of generic kos are "+str(len(df_generic_ko)))
        logger_inc_ko_similarity.debug("No of kos in level 3 from generic database are:%s",str(len(df_ko)))
        

    if (len(df_inc) > 0) and (len(df_ko) > 0):
        try:
            logger_inc_ko_similarity.debug(
                "inc ko similarity level is started on %s"+ str(
                    datetime.now()))
            logger_inc_ko_similarity.debug(
                "No of incidents to process in level 3 "+ str(
                    len(df_inc)))
            print("df_inc is ticket_Data_inter_Staging,No of incidents to process in level 3 :",df_inc.shape)
            print("df_inc is ticket_Data_inter_Staging:",df_inc.columns)

            df_inc = df_inc.rename(columns={"Incident_id": "Incident_ID"})
            df_inc = df_inc.rename(columns = {"Inc_text": "Complete_text",
                                  "Inc_proc_text": "Inc_text"}) 
            
            logger_inc_ko_similarity.debug("Preprocessing done for "+str(len(df_inc)))
            logger_inc_ko_similarity.debug("Preprocessed incidents are:\n%s",df_inc['Incident_ID'])
            print("Printing the preprocessed incidents from staging table: ",df_inc.head())           
    
            if AGfilter==0:
                df_inc = df_inc.dropna(subset=['Inc_text', 'Status'])
                logger_inc_ko_similarity.debug("Incidents from ticket_data_inter_staging_mongo table after removing na values based on Inc_text,Status:\n%s",df_inc['Incident_ID'])
            else:
                df_inc = df_inc.dropna(subset=['Assigned_Group', 'Inc_text', 'Status'])
                logger_inc_ko_similarity.debug("Incidents from ticket_data_inter_staging_mongo table after removing na values based on Assigned_Group,Inc_text,Status:\n%s",df_inc['Incident_ID'])

            
            df_inc['Inc_text'] = df_inc['Inc_text'].str.lower()
            df_open = df_inc.copy()
            print("Copy of df_inc is df_open:",df_open)

            print(df_open.isna().sum())
            print(df_open.shape)

            logger_inc_ko_similarity.debug(
                "Incident Tokenization done from level 3 for: "+ str(
                    len(df_open))+"Incidents")
                             
            df_ko['ko_id'] = df_ko['Ko_id']
            df_ko['KO_text'] = df_ko['Ko_text']
            df_ko['APP_NAME'] = df_ko['App_name']
            df_ko['TICKET_GROUP'] = df_ko['Ticket_group']
            print("Printing the shape of df_ko:",df_ko.shape)
            print(df_ko.isna().sum())
            if nonciap == 1:            
                sap_tcodes_df = common_functions.read_table_data('sap_tcodes_mongo',psql)
                sap_tcodes = sap_tcodes_df['sap_tcodes'].tolist()
                print(sap_tcodes)
                df_ko['matches'] = df_ko['KO_text'].apply(lambda x: [i for i in sap_tcodes if i in x])
                df_ko['tcodes_string'] = df_ko['matches'].agg(lambda x: ' '.join(map(str, x)))       

            if multi_language==1:
                df_ko['language'] = df_ko['KO_text'].apply(multilingual.lang_detection)  
            else:
                df_ko['language'] = default_lang
            
            df_ko["KO_text"] = df_ko.apply(lambda x:multilingual.process_text(config, x.language, x.KO_text), axis=1)
            df_ko["KO_text"] = df_ko.apply(lambda x:multilingual.oneliner_for_processing(load_lemma_model, x.language, x.KO_text),axis=1)
 
            print(df_ko.shape)
            if nonciap == 1:
                for i in df_ko.index:
                    df_ko.at[i,'KO_text'] = df_ko.at[i,'KO_text']+ ' ' +df_ko.at[i,'tcodes_string']
            df_ko['KO_text'] = df_ko['KO_text'].str.lower()
            logger_inc_ko_similarity.debug("Ko details after preprocessing the ko_text:\n%s",df_ko)



            ###  suparation ko data having predraft status
            if ko_creation == 1:
                auto_kostatus = auto_kostatus.split(',')
                ko_draft = df_ko[df_ko.Publication_status.isin(auto_kostatus)]
                print('the length of predranf ko s are: ', len(ko_draft))
                logger_inc_ko_similarity.debug("The length of predraft ko s are:%s,.The details of predraft kos are:\n%s",str(len(ko_draft)),ko_draft)
                

            
            df_ko = df_ko[df_ko.Ko_status == "1"]
            df_ko = df_ko[df_ko.Publication_status.isin(koStatusList)]  
            print("Printing the contents of df_ko after filtering status: ",df_ko)
            logger_inc_ko_similarity.debug("The length of published  ko s are: "+ str(len(df_ko)))
            logger_inc_ko_similarity.debug("Published KO's are:\n%s",df_ko['ko_id'])
            if nonciap == 1:
                df_ko = df_ko.filter(['ko_id', 'KO_text', 'APP_NAME', 'TICKET_GROUP','Module_name'])         
            else:
                df_ko = df_ko.filter(['ko_id', 'KO_text', 'APP_NAME', 'TICKET_GROUP'])

            df_ko.dropna()               

            logger_inc_ko_similarity.debug("Ko data after preprocessing,dropping na values,filtering required columns:\n%s",df_ko)
            print("Printing the df_ko shape after dropping na: ",df_ko.shape)
            print("df_ko.isna().sum(): ",df_ko.isna().sum())
            if nonciap == 1:
                mapping_table = common_functions.read_table_data('application_mapping_mongo',psql)
                mapping_table.applicationName = mapping_table.applicationName.astype(str)
                mapping_table.assignmentGroup = mapping_table.assignmentGroup.astype(str)
                mapping_table.Module_name = mapping_table.Module_name.astype(str)
                mapping_table.Tower = mapping_table.Tower.astype(str)
                mapping_table.CC = mapping_table.CC.astype(str)
                mapping_table.Cluster = mapping_table.Cluster.astype(str)

            ########################## polyfuzz #####################################

            df_inc_ko_similarity_score = pd.DataFrame()
            #All the empty assignment group and application name are treated as 
            df_open['Assigned_Group'].fillna("no_asg", inplace=True)
            df_open['App_Name'].fillna('no_apn', inplace=True)
            df_open_sub = df_open[['Assigned_Group','App_Name']].drop_duplicates()
            print("Printing df_open_sub:\n",df_open_sub)
            logger_inc_ko_similarity.debug("The unique Assignment Group and Application Name combinations in open data(Open data means data from inter staging table) are:\n%s",df_open_sub)

            for y,z in zip(df_open_sub['Assigned_Group'],df_open_sub['App_Name']): 
                from_data = df_open.groupby('App_Name').get_group(z).groupby('Assigned_Group').get_group(y)
                print("Printing the from_Data after grouping with AG and AN:\n",from_data)
                logger_inc_ko_similarity.debug("Printing the contents of from_data which groups the open data together based on AG,AN combination:\n%s",from_data)
                if nonciap == 1:
                    ko = common_functions.getKOIds(y, z, df_ko, AGfilter, ANfilter, nonciap, processGenericKo, mapping_table, mapping_df)
                else:
                    ko = common_functions.getKOIds(y, z, df_ko, AGfilter, ANfilter, nonciap)
                logger_inc_ko_similarity.debug("Fetching the published ko's from ko_detail_history_mongo based on AG,AN and respective filters:\n%s",ko)
                #print('')
                print('ko"s after are filtering: ', ko)
                #print('')
                if len(ko) > 0:
                    to_data = df_ko[df_ko['ko_id'].isin(ko)]
                else:
                    to_data = pd.DataFrame()
                logger_inc_ko_similarity.debug("Printing ko details after fetching published ko from ko_detail_history_mongo and filtering based on AG,AN:\n%s",to_data)
                print('len of to data is: ', len(to_data))
                try:
                    if len(to_data)!= 0:
                        if len(to_data) > batch_size:
                            df1 = batchprocessing(from_data, to_data, batch_size, 'Inc_text','KO_text','Incident_ID','ko_id')
                        else:           
                            df1 = cosine_similarity(from_data, to_data,'Inc_text','KO_text','Incident_ID','ko_id',(1,3),10,0) 
                        df_inc_ko_similarity_score = pd.concat([df_inc_ko_similarity_score, df1], axis=0).reset_index(drop=True)
                        logger_inc_ko_similarity.debug("Printing incident ko similarity scores:\n%s",df_inc_ko_similarity_score)
                except Exception as e:
                    print("cosine_similarity applied on data --->" +str(e))

            print("Printing df_inc_ko_similarity_score:\n",df_inc_ko_similarity_score)
            print("end time for Lv-1 similarity filter is {0}".format(datetime.now()))
            print('df_inc_ko_similarity_score shape: ', df_inc_ko_similarity_score.shape)
            logger_inc_ko_similarity.debug("Incident ko similarity program is ended")



            ####### added predraft ko's propositions  ########
            if ko_creation == 1:
                
                print('================================================')
                print('Going to find simila auto geneated kos')
                logger_inc_ko_similarity.debug("Going to find similar auto geneated kos")
                if len(df_inc_ko_similarity_score) > 0:
                    df_inc_ko_similarity_score['inc_ko_similarity_score'] = df_inc_ko_similarity_score['inc_ko_similarity_score'].astype(float) # .astype(int)
                    df_inc_ko_similarity_score = df_inc_ko_similarity_score[df_inc_ko_similarity_score['inc_ko_similarity_score'] > 0]
                    #We are taking those open incidents which do not have any ko propositions to propose them with a auto ko.
                    df_open_pre_ko = df_open[~df_open.Incident_ID.isin(list(set(list(df_inc_ko_similarity_score['inc_id']))))]
                    logger_inc_ko_similarity.debug("Fetching the incidents that do not have any ko propositions:\n%s",df_open_pre_ko)
                else:
                    df_open_pre_ko = df_open
                    
                if len(df_open_pre_ko) > 0:
                    #df_open_pre_ko = df_open_pre_ko.fillna('')
                    df_open_pre_ko['Assigned_Group'].fillna("no_asg", inplace=True)
                    df_open_pre_ko['App_Name'].fillna('no_apn', inplace=True)
                    df_open_sub = df_open_pre_ko[['Assigned_Group','App_Name']].drop_duplicates()
              
                    for y,z in zip(df_open_sub['Assigned_Group'],df_open_sub['App_Name']): 
                        from_data = df_open_pre_ko.groupby('App_Name').get_group(z).groupby('Assigned_Group').get_group(y)
                        if nonciap == 1:
                            ko = common_functions.getKOIds(y, z, ko_draft, AGfilter, ANfilter, nonciap, processGenericKo, mapping_table, mapping_df)
                        else:
                            ko = common_functions.getKOIds(y, z, ko_draft, AGfilter, ANfilter, nonciap)
        
                        print('')
                        print('looking on predraft kos are: ', ko)
                        print('')
                        if len(ko) > 0:
                            to_data = ko_draft[ko_draft['ko_id'].isin(ko)]
                        else:
                            to_data = pd.DataFrame()
                        print('len of to data is: ', len(to_data))
                        try:
                            if len(to_data)!= 0:
                                if len(to_data) > batch_size:
                                    df1 = batchprocessing(from_data, to_data, batch_size, 'Inc_text','KO_text','Incident_ID','ko_id')
                                else:           
                                    df1 = cosine_similarity(from_data, to_data,'Inc_text','KO_text','Incident_ID','ko_id',(1,3),10,0) 
                                df_inc_ko_similarity_score = pd.concat([df_inc_ko_similarity_score, df1], axis=0).reset_index(drop=True)
                        except Exception as e:
                            print("cosine_similarity applied on data --->" +str(e))
    
                    print("start time for Lv-1 similarity filter is {0}".format(datetime.now()))
                    print('df_inc_ko_similarity_score shape: ', df_inc_ko_similarity_score.shape)


            if len(df_inc_ko_similarity_score) > 0:
                logger_inc_ko_similarity.debug("Inserting the incident_ko_similarity details into inc_ko_similarity_mongo table")
                logger_inc_ko_similarity.debug("incident_ko_similarity scores are:\n%s",df_inc_ko_similarity_score)
                psql.delete_df(df_inc_ko_similarity_score, 'inc_ko_similarity_mongo', {'inc_id'})
                psql.upsert_df(df_inc_ko_similarity_score, 'inc_ko_similarity_mongo')
                logger_inc_ko_similarity.debug(
                    "incident ko similarity is ENDED at "+ str(
                        datetime.now()))

        except Exception as e:
            logger_inc_ko_similarity.error(
                "Exception occured in inc_ko_similarity file and error is---> "+str(e))
            error_string = str(e)
            logger_inc_ko_similarity.debug("Incidents processed from level 3 : 0")
            
            exception_type, exception_object, exception_traceback = sys.exc_info()
            line_number = exception_traceback.tb_lineno
            logger_inc_ko_similarity.error("exception_type for logger_inc_ko_similarity script: "+ str(exception_type))
            logger_inc_ko_similarity.error("line_number for logger_inc_ko_similarity script : "+ str(line_number))  
            
            print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
            mes = 'PFA of log file'
            common_functions.send_email(sub, mes, 1, LOG_FILENAME, log_capture_string, html,psql,emailSender,emailReceiver)
            transaction(1)
            logger_inc_ko_similarity.debug(
                "inc ko similarity run ended with exception at "+datetime.strftime(
                    datetime.now(),
                    "%Y-%m-%d %H:%M:%S"))
            sys.exit()
        else:
            logger_inc_ko_similarity.debug(
                "inc ko similarity run ended at "+ datetime.strftime(
                    datetime.now(),
                    "%Y-%m-%d %H:%M:%S"))
            mes = ''
            common_functions.send_email(sub, mes, 0, LOG_FILENAME, log_capture_string, html,psql,emailSender,emailReceiver)
            transaction(0)

    else:
        df_inc_ko_similarity_score = pd.DataFrame(
            columns=[
                'inc_id',
                'similar_ko',
                'token_score',
                'bigram_score',
                'trigram_score',
                'inc_ko_similarity_score'])
print("End time for incident ko similarity processing is {0}".format(datetime.now()))
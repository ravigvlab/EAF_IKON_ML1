# =========================================================================================================================
# File Name     : auto_ko_creation.py
# -------------------------------------------------------------------------------------------------------------------------
# Purpose       : Purpose of this script is to auto create ko for incident those don't have ko proposition.
# Author        : Harinadh Reddy
# Co-Author     : 
# Creation Date : 30-May-2023 
# Usage         : 'python ' + commonsFolderPath + 'auto_ko_creation.py --accountName ' + accountName
# History       :
# -------------------------------------------------------------------------------------------------------------------------
# Date          | Author                       | Co-Author                    | Remark
# 30-May-2023   | Harinadh Reddy               |                              | Initial Release
# =========================================================================================================================
###########################################################################################################################
# Import required Module / Packages
###########################################################################################################################

import warnings
from datetime import datetime
import sys
import os
import configparser
import common_functions
import pandas as pd
warnings.filterwarnings("ignore")
from DatabaseFunctions import DatabaseFunctions
import re
import ast
from common_functions import multilingual
import numpy as np
import time
import requests
import json

################################ Created Empty strings ##############################
error_string = ''
runid = 0
logger_autoko = ''
runid = datetime.now().strftime('%Y%m%d%H%M%S')


################################ Arguments  ###########################################
argumentList = sys.argv[1:]

args_list = common_functions.get_common_args(argumentList)
accountName = args_list[0]
#accountName = 'CAPRI'
############################### Reading config File  ################################

try:

    config = common_functions.get_config(accountName)
    
    dbDetail = common_functions.get_dbdetail(config)
    dbName = dbDetail['dbName']
    host = dbDetail['host']
    user = dbDetail['user']
    password = dbDetail['password']
    port = dbDetail['port']
    schema = dbDetail['schema']  

    path = config.get('PathsSection', 'path.folder')     

   ###################### fetching path details ##############################
    accountFolderPath = config.get('PathsSection', 'path.folder')
    commonsFolderPath = config.get('PathsSection', 'path.commons')
    accountLogPath = config.get('PathsSection', 'path.log')

    ###################### fetching email details #############################
    emailSender = config.get('EmailSection', 'email.sender')
    emailReceiver = config.get('EmailSection', 'email.receiver')

    # multilingual
    default_lang = config.get('SupportLanguage', 'default_lang')
    support_langs = config.get('SupportLanguage', 'lang_supported')
    support_langs = ast.literal_eval(support_langs)
    multi_language = config.get('SupportLanguage', 'multi_language')
    multi_language = int(multi_language) 

    ## loading lemma model
    multilingual = multilingual(accountName)
    load_lemma_model = multilingual.load_model(support_langs)


    ## Auto Ko Creation

    threshold = float(config.get('KoCreationSection', 'threshold.val'))
    his_data_days = int(config.get('KoCreationSection', 'history.data.threshold'))
    auto_kostatus = config.get('KoCreationSection', 'auto.kostatus')
    kostart = config.get('KoCreationSection', 'ko.start')

    ko_proposal = int(config.get('KoCreationSection', 'ko.proposal'))
    ko_url = config.get('KoCreationSection', 'ko.url')
    tenant_name = config.get('KoCreationSection', 'tenant_name')
    headers = {"Content-Type":"application/json", "tenantId": str(tenant_name)}


    ### log file creating ###
    LOG_DIR = os.path.join(accountLogPath, accountName, "Auto_Ko_creation")
    if not os.path.exists(LOG_DIR):
        os.makedirs(LOG_DIR)
    LOG_FILENAME = os.path.join(LOG_DIR, f"{accountName}_Auto_KOCreation_ikon2_logger_{runid}.log")

    print(LOG_FILENAME)
    logger_inc_score, log_capture_string = common_functions.getLogger(LOG_FILENAME,accountName)

except Exception as e:

    print ("Error occured while reading the config or setting up logger in incident_score: " + str(e))
    print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
    sys.exit()


############################## log file writing  ########################################
def print_log():
    with open(LOG_FILENAME, 'a+') as f:
        f.write(logger_autoko)

############################## Connecting to DB #####################################


########################### required python functions ###################################

def cosine_similarity(x_set, y_set):

    l1 = []
    l2 = []

    x_set = set(x_set)

    y_set = set(y_set)

    rvector = set(x_set).union(set(y_set))
    for w in rvector:
        if w in x_set:
            l1.append(1)  # create a vector
        else:
            l1.append(0)
        if w in y_set:
            l2.append(1)
        else:
            l2.append(0)
    c = 0
    for z in range(len(rvector)):
        c += l1[z] * l2[z]
    cosine = c / float((sum(l1) * sum(l2))**0.5)

    return cosine



def get_similar_ko(apn, asg, ko_auto_suggestion_mongo):
    
    inc_list = []
    
    try:
        if( asg == '' and apn == ''):
            inc_list.append(ko_auto_suggestion_mongo['koid'].tolist())
        else:
            inc_list.append(ko_auto_suggestion_mongo.loc[((asg == '') or (ko_auto_suggestion_mongo['assignmentgroup'] == asg)) 
                                            & 
                                            ((apn == '') or (ko_auto_suggestion_mongo['applicationname'] == apn))]['koid'].tolist())
            
        return inc_list
    except Exception as e:
        print(e)

        return None


def createkoid(max_id):
    
    max_id += 1
    max_koid = kostart + str(max_id)

    
    return max_id, max_koid


                                       
def create_ko(df_not_null, ko_auto_suggestion_mongo, max_id, handling_null = 0, threshold = 0.7):
    j = 0

    new_ko_id =[]
    for i in df_not_null.index:
        j += 1
        apn = df_not_null.at[i, 'applicationname']
        asg = df_not_null.at[i, 'assignmentgroup']
        ticketid = df_not_null.at[i, 'ticketid']
        compare_text = df_not_null.at[i, 'cleaned_summary']
        # resolutionnote = df_not_null.at[i, 'resolutionnote']

        kos = get_similar_ko(apn, asg, ko_auto_suggestion_mongo)
        kos = kos[0]

        if len(kos) > 0:
            to_data = ko_auto_suggestion_mongo[ko_auto_suggestion_mongo['koid'].isin(kos)]
        else:
            to_data = pd.DataFrame()

        max_id, max_koid = createkoid(max_id)
                                        
        if len(to_data) > 0:
                                        
            to_data['relevperc'] = to_data.apply(lambda x: cosine_similarity(compare_text.split(), x.cleaned_summary.split()),axis=1)
            to_data = to_data[to_data['relevperc'] > threshold]
            to_data = to_data.sort_values(by=['relevperc'], ascending=False)
            to_data = to_data.head(1)

            if len(to_data)> 0:
                
                to_data['ticketid'] = ticketid
                #to_data['koid'] = max_koid

            else:
                                        
                if handling_null == 0:
                    to_data = df_not_null[df_not_null['ticketid'] == ticketid]
                    to_data['koid'] = max_koid
                    to_data['relevperc'] = '1'
                    new_ko_id.append(max_koid)
                            
                else:
                            
                    to_data = ticket_data
                    to_data['relevperc'] = to_data.apply(lambda x: cosine_similarity(compare_text.split(), x.cleaned_summary.split()),axis=1)
                    to_data = to_data.sort_values(by=['relevperc'], ascending=False)
                    to_data = to_data.head(1)
                    to_data['koid'] = max_koid
                    new_ko_id.append(max_koid)
                    to_data['ticketid'] = ticketid
                            
        else:
                                        
            if handling_null == 0:
                to_data = df_not_null[df_not_null['ticketid'] == ticketid]
                to_data['koid'] = max_koid
                new_ko_id.append(max_koid)
                to_data['relevperc'] = '1'


            else:

                to_data = ticket_data
                to_data['relevperc'] = to_data.apply(lambda x: cosine_similarity(compare_text.split(), x.cleaned_summary.split()),axis=1)
                to_data = to_data.sort_values(by=['relevperc'], ascending=False)
                to_data = to_data.head(1)
                to_data['koid'] = max_koid
                new_ko_id.append(max_koid)
                to_data['ticketid'] = ticketid

         
        if (j % 200 == 0):
            print('no of incident are processes for ko creation is: ', j)
            break
        ko_auto_suggestion_mongo = pd.concat([ko_auto_suggestion_mongo, to_data], axis=0).reset_index(drop=True)
                        
    return ko_auto_suggestion_mongo, new_ko_id

################################################## Required Function are written #########################################################

try:
    
    psql = DatabaseFunctions(host, user, password, port, dbName, schema, config = config) 

except Exception as e:
    print(
        "Could not connect to postgresql in incident score file and error is--->" +
        str(e))
    logger_inc_score.error(
        "auto ko process failed due to postgresql db connectivity issue")
    print_log()   
    sys.exit()
else:
    print("Connected successfully!!!")

############################ Reading ticket data proposal history ###################
try:

    logger_autoko = logger_autoko+str("Auto KO Creation process run started at")+ datetime.strftime(datetime.now(),"%Y-%m-%d %H:%M:%S")+"\n"

    #account_features['autokoenabled']

    ko_enabled = psql.select_df('account_features')

    ko_enabled_flag = list(ko_enabled['autokoenabled'])
    ko_enabled_flag = int(ko_enabled_flag[0])
    
    if ko_enabled_flag != 1:
        logger_autoko = logger_autoko+str("In account_features table auto flag is zero so run ended at ")+ datetime.strftime(datetime.now(),"%Y-%m-%d %H:%M:%S")+"\n"
        print_log()
        sys.exit()

    ticket_data = psql.select_df('ticket_data_history','status',['Closed','Resolved', 'Open'])
    print('len ticket_data 1: ', len(ticket_data))
    import datetime as th_date
    threshold_date = th_date.datetime.today() - th_date.timedelta(days=his_data_days)
    formatted_date = threshold_date.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    ticket_data = ticket_data[ticket_data['reporteddate'] > formatted_date]
    print('formatted_date: ', formatted_date)
    print('len ticket_data 2: ', len(ticket_data))
    ticket_data  = ticket_data[['ticketid', 'summary', 'notes', 'applicationname', 'assignmentgroup', 'relevperc', 'resolutionnote', 'serialnumber']]
    ticket_data = ticket_data.fillna('')
    filtered_df = ticket_data[ticket_data['relevperc'] == '']
    ko_auto_suggestion_mongo = psql.select_df('ko_auto_suggestion_mongo')
    
    print('len ko_auto_suggestion_mongo is: ', len(ko_auto_suggestion_mongo))
    incident_ko_link_mongo = psql.select_df('incident_ko_link_mongo')
    
    if len(ko_auto_suggestion_mongo) > 0:
        filtered_df = filtered_df[~filtered_df['ticketid'].isin(list(ko_auto_suggestion_mongo['ticketid']))]
        
        if len(incident_ko_link_mongo) > 0:
            filtered_df = filtered_df[~filtered_df['ticketid'].isin(list(incident_ko_link_mongo['incident_id']))]
        
        if len(filtered_df) == 0:
            print('not found any ticket to create new ko')
            logger_autoko = logger_autoko+str("KO send proposal run ENDED at due to no new incident to create ko ")+ datetime.strftime(datetime.now(),"%Y-%m-%d %H:%M:%S")+"\n"
            print_log()
            sys.exit()
    
    if multi_language==1:
        ticket_data['language']=ticket_data['summary'].apply(multilingual.lang_detection)

    else:
        ticket_data['language'] = default_lang



    ticket_data['summary'] = ticket_data.apply(lambda x:multilingual.process_text(config, x.language, x.summary),axis=1)
    ticket_data['notes'] = ticket_data.apply(lambda x:multilingual.process_text(config, x.language, x.notes),axis=1)
    ticket_data['resolutionnote'] = ticket_data.apply(lambda x:multilingual.process_text(config, x.language, x.resolutionnote),axis=1)
    ticket_data['cleaned_summary'] = ticket_data['summary'] + ' ' + ticket_data['notes']
    #ticket_data['cleaned_summary'] = ticket_data.apply(lambda x:multilingual.process_text(config, x.language, x.cleaned_summary),axis=1)
    ticket_data['cleaned_summary'] = ticket_data.apply(lambda x:multilingual.oneliner_for_processing_2(load_lemma_model, x.language, x.cleaned_summary),axis=1)
    
    ## Below three lines are repeted to increse time complexity
    filtered_df = ticket_data[ticket_data['relevperc'] == '']
    if len(ko_auto_suggestion_mongo) > 0:
        filtered_df = filtered_df[~filtered_df['ticketid'].isin(list(ko_auto_suggestion_mongo['ticketid']))]
        if len(incident_ko_link_mongo) > 0:
            filtered_df = filtered_df[~filtered_df['ticketid'].isin(list(incident_ko_link_mongo['incident_id']))]
    ticket_data  = ticket_data[['ticketid', 'summary', 'notes', 'applicationname', 'assignmentgroup', 'cleaned_summary', 'resolutionnote','serialnumber']]
    # ticket_data = ticket_data[['ticketid', 'summary', 'notes', 'applicationname', 'assignmentgroup', 'cleaned_summary']]
    # ticket_data = ticket_data.dropna(subset=ticket_data.columns[ticket_data.eq('').any()])
    
    ticket_data = ticket_data.replace('', np.nan)
    # Drop rows with null values
    ticket_data = ticket_data.dropna()

    if len(ko_auto_suggestion_mongo) > 0:
        ko_auto_suggestion_mongo = ko_auto_suggestion_mongo.fillna('')

        if multi_language==1:
            ko_auto_suggestion_mongo['language']=ko_auto_suggestion_mongo['summary'].apply(multilingual.lang_detection)

        else:
            ko_auto_suggestion_mongo['language'] = default_lang

        total_id = ko_auto_suggestion_mongo['koid'].apply(lambda x: int(re.search(r'\d+', x).group()))
        max_id = max(total_id)
        filtered_df = filtered_df[~filtered_df['ticketid'].isin(list(ko_auto_suggestion_mongo['ticketid']))]

    else:
        ko_auto_suggestion_mongo = pd.DataFrame(columns=['ticketid', 'koid', 'summary', 'notes', 'applicationname', 'assignmentgroup', 'resolutionnote', 'serialnumber'])
        
        ko_format = psql.select_df('ko_format')
        maxid = list(ko_format['koidstart'])
        max_id = int(maxid[0])

    auto_created_ko = pd.DataFrame()
    filtered_df  = filtered_df[['ticketid', 'summary', 'notes', 'applicationname', 'assignmentgroup', 'cleaned_summary', 'resolutionnote', 'serialnumber']]
    df_null = filtered_df[filtered_df.isnull().any(axis=1)]
    df_not_null = filtered_df[~filtered_df.isnull().any(axis=1)]

    df_not_null = df_not_null.reset_index(drop=True)
    df_null = df_null.reset_index(drop=True)


    if len(df_not_null) > 0:
        print('going to create ko function')
        auto_created_ko_1, new_ko_id_1 =  create_ko(df_not_null, ko_auto_suggestion_mongo, max_id, handling_null = 0, threshold = threshold)
        auto_created_ko = auto_created_ko_1.copy()
    else:
        new_ko_id_1 = []
    if len(df_null) > 0:

        auto_created_ko_2, new_ko_id_2 =  create_ko(df_null, ko_auto_suggestion_mongo, max_id, handling_null = 1, threshold = threshold)
        auto_created_ko = pd.concat([auto_created_ko_1, auto_created_ko_2], axis=0).reset_index(drop=True)
    else:
        new_ko_id_2 = []
        
    if len(new_ko_id_2)>0 or len(new_ko_id_1)>0:
        new_ko_id = new_ko_id_2 + new_ko_id_1
    
    if len(auto_created_ko) > 0:
        psql.upsert_df(auto_created_ko, 'ko_auto_suggestion_mongo')
        inc_ko = auto_created_ko[['ticketid', 'koid', 'relevperc']]
        inc_ko['relevperc'] = inc_ko['relevperc'].apply(lambda x: round(float(x) * 100))
        inc_ko['koid'] = inc_ko['koid'].astype(str) + ':' + inc_ko['relevperc'].astype(str)
        inc_ko = inc_ko[['ticketid', 'koid']]
        inc_ko.rename(columns = {'koid':'autocreatedko'}, inplace=True) 
        
        psql.update_df(inc_ko, 'ticket_data_history', {'ticketid'})
        psql.update_df(inc_ko, 'ticket_data', {'ticketid'})

        auto_created_ko = auto_created_ko.drop_duplicates(subset='koid')
        ko_inter = auto_created_ko.copy()
        
        ko_inter.rename(columns = {'koid':'ko_id', 'assignmentgroup':'ticket_group', 'applicationname':'app_name'}, inplace=True)  
        ko_inter['ko_text'] =  ko_inter['summary'] + ' ' + ko_inter['notes']      
        ko_inter['ko_status'] = 1
        ko_inter['publication_status'] = auto_kostatus
        ko_inter = ko_inter[['ko_id', 'ticket_group', 'app_name', 'ko_status', 'publication_status', 'summary', 'ko_text']]
        psql.upsert_df(ko_inter,'ko_detail_inter_mongo')


        ############
        ko_info_his = psql.select_df('ko_info', 'koid', list(set(list(ko_inter['ko_id']))))
        ko_info_new = auto_created_ko[~auto_created_ko['koid'].isin(list(ko_info_his['koid']))]
        ko_info_new_backup = ko_info_new.copy()
        
        if len(ko_info_new) > 0:
            
            ############  Handling ko_info ##########
            ko_info_new.rename(columns = {'summary':'shortdescription', 'notes':'longdescription'}, inplace=True)
            ko_info_new = ko_info_new[['koid', 'shortdescription', 'longdescription','applicationname', 'assignmentgroup']]
            
            ko_info_new_koid = list(set(list(ko_info_new['koid'])))
            accountid = psql.select_df('account_info')
            acc_id = list(accountid['accountid'])
            
            ko_info_new['publicationstatus'] = auto_kostatus
            ko_info_new['accountid'] = int(acc_id[0])
            ko_info_new['createdinikon'] = 2
            ko_info_new['attachmentpresent'] = 1
            ko_info_new['feedid'] = 0
            ko_info_new['assignedforreview'] = 'N'
            ko_info_new['ko_version'] = '1.0'
            psql.insert_df(ko_info_new, 'ko_info')
            
            ############  Handling ko_detail ##########
            ko_info = psql.select_df('ko_info', 'koid', ko_info_new_koid)
        
            ko_detail = ko_info[['koserialno', 'koid', 'ko_version']]

            ko_detail = pd.merge(ko_info[['koserialno', 'koid','ko_version']], ko_info_new_backup[['koid', 'resolutionnote']], on='koid', how='left')
            ko_detail.rename(columns = {'resolutionnote':'resolution'}, inplace=True)
            ko_detail = ko_detail[['koserialno', 'resolution']]  # resolution
            psql.insert_df(ko_detail, 'ko_detail')

            ########### Handling ko_publish_control #########
            ko_publish_control = ko_info[['koserialno', 'applicationname', 'assignmentgroup','ko_version']]
            ko_publish_control.rename(columns = {'applicationname':'app_name', 'assignmentgroup':'ass_group'}, inplace=True)
            psql.insert_df(ko_publish_control, 'ko_publish_control')

            ############ Handling ko_usage_history table  ############
            
            ko_usage = ko_info[['koserialno', 'accountid', 'koid', 'applicationname', 'assignmentgroup','ko_version']]
            ko_usage = pd.merge(ko_info[['koserialno', 'accountid', 'koid', 'applicationname', 'assignmentgroup','ko_version']], ko_info_new_backup[['koid', 'ticketid', 'serialnumber']], on='koid', how='left')
            ko_usage['userid'] = 'ML'
            ko_usage['linkeddate'] = time.strftime("%Y-%m-%d %H:%M:%S")
            ko_usage['feedid'] = 0
            ko_usage['linkedtoko'] = 'N'
            ko_usage['kotype'] = 0
            
            ko_usage = ko_usage[['koserialno', 'serialnumber', 'userid', 'accountid', 'linkeddate','feedid', 'linkedtoko', 'kotype', 'applicationname', 'assignmentgroup','ko_version']]

            account_features = psql.select_df('account_features')
            ko_history = list(account_features['kohistory'])
            ko_history = ko_history[0]
            if ko_history == 1:
                psql.insert_df(ko_usage, 'ko_usage_history')
            else:
                psql.insert_df(ko_usage, 'ko_usage')
            
        if ko_proposal == 1:    
            logger_autoko = logger_autoko+str("started ko payload process")
            if len(new_ko_id) > 0:
                final_payload = new_ko_id
                
                final_payload = json.dumps(final_payload, indent = 4)
                response = requests.post(url = ko_url, headers = headers, data = final_payload)
                logger_autoko = logger_autoko+str("Number of new kos are created is : " + str(len(new_ko_id)))+"\n"
                logger_autoko = logger_autoko+str("Status Code : " + str(response.status_code))+"\n"
                if response.status_code == 200 or response.status_code == 201:
                    logger_autoko = logger_autoko+str("final payload is sucess full and payload is: " + str(final_payload))
                else:
                    logger_autoko = logger_autoko+str("final payload is failed and payload is: " + str(final_payload))

            
            
except Exception as e: 
    logger_autoko = logger_autoko+str(["Error ocurred in script",
                            "Line No: " + str(sys.exc_info()[2].tb_lineno),
                            "Exception type: " + str(sys.exc_info()[0]),
                            "Error: " + str(e)])+"\n"
    error_string = error_string + str(e)
    logger_autoko = logger_autoko+str("KO send proposal run ended at ")+ datetime.strftime(datetime.now(),"%Y-%m-%d %H:%M:%S")+"\n"
    print_log()
    sys.exit()

else:
    logger_autoko = logger_autoko+str("KO send proposal run ENDED at ")+ datetime.strftime(datetime.now(),"%Y-%m-%d %H:%M:%S")+"\n"
    print_log()



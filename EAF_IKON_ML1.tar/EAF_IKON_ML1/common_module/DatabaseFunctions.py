import sqlalchemy as sqla
from sqlalchemy.orm import sessionmaker
import pandas as pd
import time
import os
from sqlalchemy.engine import reflection
import configparser
# config = configparser.RawConfigParser()
# config_path = os.path.join(os.getcwd(), 'conf', 'CommonConfigFile.properties')
# config.read(config_path) 


class DatabaseFunctions:
    # if "sql.type" in config["GenericSection"]:
        # sql_type = int(config.get('GenericSection', 'sql.type'))
        # print('==============  sql_type  ==============: ', sql_type)
    # else:
        # sql_type = 1
    # audit_flag = int(config.get('AuditFlag', 'audit.flag'))
    # table_list = config.get('AuditFlag', 'audit.tables').split(',')
    
    
    def __init__(self, host_name,user_id,pwd,port_no,db_name,schema="", config=""):

        """
            This __init__ function is like a constructor and it initializes variables for class

            Parameters:
                account_name (string): this is the folder name in which the config files are present

            Returns:
                Null

        """
        try:
            self.db_name = db_name
            self.host_name = host_name
            self.user_id = user_id
            self.pwd = pwd
            self.port_no = str(port_no)
            
            if schema != "":
                self.schema = schema
            
            if config != "":
                if 'DatabaseSection' in config:
                    print('DatabaseSection is in config')
            
                if "database.type" in config["DatabaseSection"]:
                    self.sql_type = int(config.get('DatabaseSection', 'database.type'))
                    
                    print('==============  sql_type  ==============: ', self.sql_type)
                else:
                    self.sql_type = 1
                    
                if 'AuditFlag' in config:
                    self.audit_flag = int(config.get('AuditFlag', 'audit.flag'))
                    self.table_list = config.get('AuditFlag', 'audit.tables').split(',')
                    
                else:
                    print('AuditFlag not present in config')
                    self.audit_flag = 0

            else:
                config = configparser.RawConfigParser()
                config_path = os.path.join(os.getcwd(), 'conf', 'CommonConfigFile.properties')
                config.read(config_path) 

                if "database.type" in config["DatabaseSection"]:
                    self.sql_type = int(config.get('DatabaseSection', 'database.type'))
                    print('==============  sql_type  ==============: ', self.sql_type)
                else:
                    self.sql_type = 1
                if 'AuditFlag' in config:
                    self.audit_flag = int(config.get('AuditFlag', 'audit.flag'))
                    self.table_list = config.get('AuditFlag', 'audit.tables').split(',')
                else:
                    print('AuditFlag not present')
                    self.audit_flag = 0
            
            
            
        except Exception as e:
            print(e)

    def mysql_create_connection(self):
        """
            This mysql_create_connection function creates the database connection variables.

            Parameters:
                Null

            Returns:
                Null

        """
        try:
        
            if self.sql_type == 1:
                self.engine = sqla.create_engine('postgresql+psycopg2://'+self.user_id+':'+self.pwd+'@'+self.host_name+':'+self.port_no+'/'+self.db_name,connect_args={'options': '-csearch_path={}'.format(self.schema)})
            else:
                self.engine = sqla.create_engine('mysql+pymysql://'+self.user_id+':'+self.pwd+'@'+self.host_name+':'+self.port_no+'/'+self.db_name)                                 
            self.metadata = sqla.MetaData(bind=self.engine)
            self.insp = reflection.Inspector.from_engine(self.engine)
            self.connection = self.engine.connect()
        except Exception as e:
            print(e)

    def mysql_close_connection(self):
        """
            This mysql_close_connection function closes the database connection variables.

            Parameters:
                Null

            Returns:
                Null

        """
        try:
            self.connection.close()
            self.engine.dispose()
        except Exception as e:
            print(e)

    def get_table_names(self):
        """
            Returns the table names in the database

            Parameters:
                Null

            Returns:
                tables (List) : list of tables in the database

        """
        try:
            self.mysql_create_connection()
            tables = self.insp.get_table_names()

            return tables
        except Exception as e:
            print(e)
        finally:
            self.mysql_close_connection()

    def get_where_query(self, data_table, query, where_vals):
        """
            Creates the where query from the given values

            Parameters:
                data_table (Table): sqla Table variable
                query (Query): Table query
                where_vals (dict): where clauses(condition values)

            Returns:
                Query with where statement

           """
        try:
            for k, v in where_vals.items():
                field = k.split(":", 2)
                if( len(field) > 1 ):
                    if( field[1] == ">" ):
                        query = query.where(getattr(data_table.c, field[0]) > v)
                    elif( field[1] == ">=" ):
                        query = query.where(getattr(data_table.c, field[0]) >= v)
                    elif( field[1] == "<" ):
                        query = query.where(getattr(data_table.c, field[0]) < v)
                    elif( field[1] == "<=" ):
                        query = query.where(getattr(data_table.c, field[0]) <= v)
                    elif( field[1] == "<>" ):
                        query = query.where(getattr(data_table.c, field[0]) != v)
                    elif( field[1] == "like" ): # NOT fully supported
                        query = query.where(getattr(data_table.c, field[0]).like(v))
                    elif( field[1] == "in" ): # NOT fully supported
                        if( type(v) is list or type(v) is tuple  or type(v) is set):
                            query = query.where(getattr(data_table.c, field[0]).in_(tuple(v)))
                        elif( type(v) is dict):
                            query = query.where(getattr(data_table.c, field[0]).in_(tuple([value for key, value in v.items()])))
                        else:
                            query = query.where(getattr(data_table.c, field[0]) == v)
                    else:
                        query = query.where(getattr(data_table.c, field[0]) == v)
                else:
                    query = query.where(getattr(data_table.c, field[0]) == v)
        except Exception as e:
            print(str(e))
        return query

    def select_df(self,table,in_list_key=None,in_list_values=None, where_vals={}, return_list=[] ):
        """
            Returns the data of the requested table as dataframe

            Parameters:
                table (string): Table name from which the data is to be fetched
                in_list_key (string): column name based on which the data should be retrieved (Default= None)
                in_list_values (list): list of values for filtering the data (Default= None)

            Returns:
                dataframe: Fetched Data as dataframe

        """
        try:
            self.mysql_create_connection()
            self.datatable = sqla.Table(table, self.metadata, autoload=True)

            select_columns = []
            if( type(return_list) is not list or len(return_list) == 0 ):
                select_columns.append(self.datatable)
            else:
                for column in self.datatable.c:
                    if( column.name in return_list):
                        select_columns.append(column)

                if len(select_columns) == 0 : select_columns.append(self.datatable)

            if in_list_key!=None and in_list_values!=None:
                stmt = sqla.select(select_columns).where(self.datatable.c[in_list_key].in_(tuple(in_list_values)))
            elif where_vals != None and len(where_vals) > 0:
                stmt = self.get_where_query(self.datatable, sqla.select(select_columns), where_vals)
            elif( type(return_list) is list and len(return_list) != 0 ):
                stmt = sqla.select(select_columns)
            else:
                stmt = self.datatable.select()

            results = self.connection.execute(stmt).fetchall()

            return_columns = []
            if( type(return_list) is not list or len(return_list) == 0 ):
                return_columns = self.metadata.tables[table].columns.keys()
            else:
                for column in self.metadata.tables[table].columns.keys():
                    if( column in return_list):
                        return_columns.append(column)

                if len(return_columns) == 0 : return_columns = self.metadata.tables[table].columns.keys()

            df = pd.DataFrame(columns = return_columns, data = results)
            return df
        except Exception as e:
            print(e)
        finally:
            self.mysql_close_connection()

    @staticmethod
    def Audit_insert(audit_table):
        audit_table['createdby']='SYSTEM'
        audit_table['createddate']=time.strftime("%Y-%m-%d %H:%M:%S")
        audit_table['modifiedby']='ML'
        audit_table['modifieddate']=time.strftime("%Y-%m-%d %H:%M:%S")
        return audit_table
    @staticmethod
    def Audit_update(audit_table):
        audit_table['modifiedby']='ML'
        audit_table['modifieddate']=time.strftime("%Y-%m-%d %H:%M:%S")
        return audit_table
        
    def insert_df(self,df,table):
        """
            Inserts data into the requested table

            Parameters:
                df (dataframe): dataframe of values which needs to be inserted
                table (string): Table name into which the data is to be inserted

            Returns:
                Null

        """
        try:
            self.mysql_create_connection()
            sm = sessionmaker(bind=self.engine)
            session = sm()

            datatable = sqla.Table(table, self.metadata, autoload=True)

            for ind, row in df.iterrows():
                try:
                    insert_vals = dict(row)
                    if self.audit_flag == 1:
                        if table in self.table_list:
                            insert_vals=DatabaseFunctions.Audit_insert(insert_vals)
                    session.execute(datatable.insert(),insert_vals)
                except Exception as e:
                    print(e)
                else:
                    session.flush()
                    session.commit()

        except Exception as e:
            print(e)
        finally:
            self.mysql_close_connection()

    def get_update_query(self,data_table, where_vals, update_vals):
       """
            Creates the update query from the given values

            Parameters:
                data_table (Table): sqla Table variable
                where_vals (dict): where clauses(condition values)
                update_vals (dict): set clauses(values to be updated)

            Returns:
                update statement

       """
       query = data_table.update()
       for k, v in where_vals.items():
         query = query.where(getattr(data_table.c, k) == v)
       return query.values(**update_vals)

    def get_insert_query(self,data_table, where_vals, insert_vals):
       """
            Creates the update query from the given values

            Parameters:
                data_table (Table): sqla Table variable
                where_vals (dict): where clauses(condition values)
                update_vals (dict): set clauses(values to be updated)

            Returns:
                update statement

       """
       query = data_table.insert()
       for k, v in where_vals.items():
         query = query.where(getattr(data_table.c, k) == v)
       return query.values(**insert_vals)

    def update_df(self,df,table,update_where):
        """
            updates data into the requested table

            Parameters:
                df (dataframe): dataframe of values which needs to be updated
                table (string): Table name into which the data is to be updated
                update_where (dict) : conditional columns

            Returns:
                Null

        """
        try:
            self.mysql_create_connection()
            sm = sessionmaker(bind=self.engine)
            session = sm()

            datatable = sqla.Table(table, self.metadata, autoload=True)
            for ind, row in df.iterrows():
                try:
                    where_vals = {}
                    for i in update_where:
                        where_vals[i] = row.pop(i)

                    update_vals = dict(row)
                    
                    if self.audit_flag == 1:
                        if table in self.table_list:
                            update_vals=DatabaseFunctions.Audit_update(update_vals)
                        
                    stmt = self.get_update_query(datatable, where_vals, update_vals)
                    session.execute(stmt)
                except Exception as e:
                   print(e)
                else:
                    session.flush()
                    session.commit()

        except Exception as e:
            print(e)
        finally:
            self.mysql_close_connection()

    def upsert_df(self,df,table):
        """
            Inserts data or updates data on duplicate keys into the requested table

            Parameters:
                df (dataframe): dataframe of values which needs to be inserted/updated
                table (string): Table name into which the data is to be inserted/updated

            Returns:
                Null

        """
        data=[]
        try:
            self.mysql_create_connection()
            sm = sessionmaker(bind=self.engine,autocommit=False)
            session = sm()

            datatable = sqla.Table(table, self.metadata, autoload=True)

            for ind, row in df.iterrows():
                try:
                    insert_vals = dict(row)
                    if self.audit_flag == 1:
                        if table in self.table_list:
                            insert_vals=DatabaseFunctions.Audit_insert(insert_vals)
                    session.execute(datatable.insert(),insert_vals)

                except Exception as e:
                    if 'IntegrityError' in str(e.with_traceback):
                        data.append(row)
                finally:
                    session.flush()
                    session.commit()

        except Exception as e:
            print(e)
        else:
            self.mysql_close_connection()
            if len(data)>0:
                df_row = pd.DataFrame(columns = df.columns,data = data)
                self.update_df(df_row,table,update_where = [c.name for c in datatable.primary_key])
        finally:
            self.mysql_close_connection()



    
    def insert_update_df(self, df, table, columns_to_update, key):
        """
            Inserts data or updates data on duplicate keys into the requested table

            Parameters:
                df (dataframe): dataframe of values which needs to be inserted/updated
                table (string): Table name into which the data is to be inserted/updated

            Returns:
                Null

        """
        print("started")
        data = []
        try:
            self.mysql_create_connection()
            sm = sessionmaker(bind=self.engine, autocommit=False)
            session = sm()

            datatable = sqla.Table(table, self.metadata, autoload=True)

            for ind, row in df.iterrows():
                try:
                    print(ind)
                    insert_vals = dict(row)
                    if self.audit_flag == 1:
                        if table in self.table_list:
                            insert_vals=self.Audit_insert(insert_vals)
                    session.execute(datatable.insert(), insert_vals)

                except Exception as e:
                    print(str(e))
                    print(str(e.with_traceback))
                #if 'IntegrityError' in str(e.with_traceback):
                    print(row)
                    var1 = row[0]
                    var2 = row[2]
                    data.append([var1,var2])
                finally:
                    session.flush()
                    session.commit()

        except Exception as e:
            print("here")
            print(str(e))
        else:
            self.mysql_close_connection()
            if len(data) > 0:
                print(data)
                df_row = pd.DataFrame(columns=columns_to_update, data=data)
                self.update_df(df_row, table, {key}) #{'groupid'}


    def get_delete_query(self,data_table, where_vals):
        """
            Creates the delete query from the given values

            Parameters:
                data_table (Table): sqla Table variable
                where_vals (dict): where clauses(condition values)

            Returns:
                Delete statement

           """
        query = data_table.delete()
        query = self.get_where_query(data_table, query, where_vals)

        return query

    def delete_df(self,df,table,delete_where):
        """
            Deletes the given data from the table

            Parameters:
                df (dataframe): dataframe of values which needs to be deleted
                table (string): Table name from which the data is to be deleted
                delete_where (dict) : conditional columns

            Returns:
                Null

        """
        try:
            self.mysql_create_connection()
            sm = sessionmaker(bind=self.engine)
            session = sm()

            datatable = sqla.Table(table, self.metadata, autoload=True)
            
            for ind, row in df.iterrows():
                try:
                    where_vals = {}

                    for i in delete_where:
                        field = i.split(":", 2)
                        where_vals[i] = row.pop(field[0])

                    session.execute(self.get_delete_query(datatable, where_vals))
                except:
                    session.rollback()
                else:
                    session.flush()
                    session.commit()

        except Exception as e:
            print(e)
        finally:
            self.mysql_close_connection()

    def delete_sql(self,table,delete_where):
        """
            Deletes the given data from the table

            Parameters:
                df (dataframe): dataframe of values which needs to be deleted
                table (string): Table name from which the data is to be deleted
                delete_where (dict) : conditional columns

            Returns:
                Null

        """
        try:
            self.mysql_create_connection()
            sm = sessionmaker(bind=self.engine)
            session = sm()

            datatable = sqla.Table(table, self.metadata, autoload=True)

            try:
                session.execute(self.get_delete_query(datatable, delete_where))
            except:
                session.rollback()
            else:
                session.flush()
                session.commit()

        except Exception as e:
            print(e)
        finally:
            self.mysql_close_connection()

    def truncate_table(self,table):
        """
            Truncates the data from the table

            Parameters:
                table (string): Table name from which the data is to be truncated

            Returns:
                Null

        """
        try:
            self.mysql_create_connection()
            sm = sessionmaker(bind=self.engine)
            session = sm()

            datatable = sqla.Table(table, self.metadata, autoload=True)

            try:
                session.execute(datatable.delete())
            except:
                session.rollback()
            else:
                session.flush()
                session.commit()

        except Exception as e:
            print(e)
        finally:
            self.mysql_close_connection()


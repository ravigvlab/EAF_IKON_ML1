# =========================================================================================================================
# File Name     : inc_ko_link_common.py
# -------------------------------------------------------------------------------------------------------------------------
# Purpose       : Purpose of this script is to find most similar incidents.
# Author        : Sai, Harinadh Reddy
# Co-Author     : 
# Creation Date : 11-NOV-2022
# Usage         : 'python ' + commonsFolderPath + 'inc_ko_link_common.py --accountName ' + accountName
# History       :
# -------------------------------------------------------------------------------------------------------------------------
# Date          | Author                       | Co-Author                    | Remark
# 11-Nov-2022   | Sai, Harinadh Reddy          |                              | Initial Release
# =========================================================================================================================
###########################################################################################################################
# Import required Module / Packages
###########################################################################################################################

import common_functions
import sys,getopt
from datetime import datetime
import pandas as pd
import os
import threading
from DatabaseFunctions import DatabaseFunctions 
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sparse_dot_topn import awesome_cossim_topn
from scipy.sparse import csr_matrix
import warnings
warnings.filterwarnings("ignore")

error_string = ''
logger_inc_ko_link = ''
runid = 0
no_of_feed_inc = 0
no_of_inc_similar = 0
start_time = datetime.now()
runid = datetime.now().strftime('%Y%m%d%H%M%S')  # + str(uuid4())
print("run id from inc ko link is"+ runid)

# Arguments
argumentList = sys.argv[1:]
args_list = common_functions.get_common_args(argumentList)
accountName = args_list[0]

try:
    config = common_functions.get_config(accountName)  
    dbDetail = common_functions.get_dbdetail(config)
    dbName = dbDetail['dbName']
    host = dbDetail['host']
    user = dbDetail['user']
    password = dbDetail['password']
    port = dbDetail['port']
    schema = dbDetail['schema']
    accountLogPath = config.get('PathsSection', 'path.log')

    ###################### fetching email details #############################
    emailSender = config.get('EmailSection', 'email.sender')
    emailReceiver = config.get('EmailSection', 'email.receiver')
    
    ###################### fetching status details ############################
    closedStatusList = config.get('StatusSection', 'status.closed')
    if closedStatusList != '':
        closedStatusList = closedStatusList.split(',')                                                            
    koStatusList = config.get('StatusSection', 'status.ko').split(',')

    ###################### fetching threshold details #########################
    ticketThreshold = int(config.get('GenericSection', 'max.records.singlethread'))
    AGfilter = int(config.get('FilterSection', 'filter.AG'))
    ANfilter = int(config.get('FilterSection', 'filter.AN'))
    ### log file creating ###
    LOG_DIR = os.path.join(accountLogPath,accountName,"level1_logs")
    if not os.path.exists(LOG_DIR):
        os.makedirs(LOG_DIR)
    LOG_FILENAME = os.path.join(LOG_DIR, f"{accountName}_Level1_ikon2_logger_{runid}.log")

    print(LOG_FILENAME)
    logger_inc_ko_link, log_capture_string = common_functions.getLogger(LOG_FILENAME,accountName)

    port=int(port)

    ## generic section 
    nonciap = int(config.get('GenericSection', 'account.type.nonciap'))   
    batch_size = int(config.get('GenericSection', 'max.train.batch'))
    
except Exception as e:
    print ("Error occured while reading the config or setting up logger in inc_ko_link: " + str(e))
    sys.exit() 


def transaction(iserror):
    status = ''
    if iserror == 0:
        status = "success"
    else:
        status = "failed"
    df=pd.DataFrame(columns=['run_id', 'active', 'start_time', 'end_time', 'inc_in_feed','no_of_inc_similar', 'status'])
    df = df.append(pd.Series([runid,0, datetime.strftime(start_time, "%Y-%m-%d %H:%M:%S"),datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S"), no_of_feed_inc,no_of_inc_similar,status], index=df.columns ), ignore_index=True)
    psql.upsert_df(df, 'run_transactions_mongo')   

feed_name = "Incident KO Link Process"
sub = "Incident KO Link Process"
html = """<br>Summary of Incident KO Link Process run for incident feed(""" + str(runid) + """)<br>
    start time = """ + str(start_time) + """<br>
    end time = """ + str(datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")) + """<br>
    No.of records in feed = """ + str(no_of_feed_inc) + """<br>
    No.of incidents for which incident tags are created = """ + str(no_of_inc_similar) + """
    """

data = """{"inc_in_feed": """ + str(no_of_feed_inc) + """,
       "no_of_inc_similar": """ + str(no_of_inc_similar) +"""}"""

logger_inc_ko_link.debug("incident ko link file run started at "+datetime.strftime(start_time,"%Y-%m-%d %H:%M:%S"))

try:
    psql = DatabaseFunctions(host, user, password, port,dbName,schema, config= config) 
except Exception as e:
    print(
        "Could not connect to postgresql in incident ko link file and error is--->" +
        str(e))
    logger_inc_ko_link.error(
        "Incident ko link process failed due to postgresql connectivity issue")
    sys.exit()
else:
    print("Connected successfully!!!")

df=pd.DataFrame(columns=['run_id', 'active', 'feed name'])
df = df.append(pd.Series([runid,1, 'incident ko link'], index=df.columns ), ignore_index=True)
psql.upsert_df(df, 'run_transactions_mongo')
#################################################cosine similarity ###############################

from typing import List
    
def cosine_similarity(from_df,
                        to_df,
                        from_field,
                        to_field,
                        from_id,
                        to_id,
                        ngram_range=(1,3),
                      nbest: int =10,  #top_n: int = 1
                      min_similarity: float = 0) -> pd.DataFrame:


    from_df[from_field] = from_df[from_field].values.astype('U')
    from_list = from_df[from_field].tolist()

    to_df[to_field] = to_df[to_field].values.astype('U')
    to_list=to_df[to_field].tolist()

    vectorizer = TfidfVectorizer(analyzer='word', ngram_range=ngram_range).fit(to_list + from_list)
    to_vector = vectorizer.transform(to_list)
    from_vector = vectorizer.transform(from_list)

    if int(nbest) >  len(to_list):
        nbest = len(to_list)
    
    if isinstance(to_vector, np.ndarray):
        to_vector = csr_matrix(to_vector)
    if isinstance(from_vector, np.ndarray):
        from_vector = csr_matrix(from_vector)
        
    from_inc = from_df[from_id].to_list()
    to_inc=to_df[to_id].to_list()   
        
    if int(nbest) <= 1:
        similarity_matrix = awesome_cossim_topn(from_vector, to_vector.T, 2, min_similarity)
        indices = np.array(similarity_matrix.argmax(axis=1).T).flatten()
        similarity = similarity_matrix.max(axis=1).toarray().T.flatten()
        matches = [to_list[idx] for idx in indices.flatten()]
        ids = [to_inc[idx] for idx in indices.flatten()]
        matches = pd.DataFrame(np.vstack((from_inc, similarity, ids)).T, columns=["test_incid", "inc_similarity_score","train_incid"])
    else:
        similarity_matrix = awesome_cossim_topn(from_vector, to_vector.T, nbest, min_similarity)
        similarity = np.flip(np.take_along_axis(similarity_matrix.toarray(), np.argsort(similarity_matrix.toarray(), axis =1), axis=1) [:,-int(nbest):], axis = 1)
        indices = np.flip(np.argsort(np.array(similarity_matrix.toarray()), axis =1)[:,-int(nbest):], axis = 1)
        matches = [np.array([to_list[idx] for idx in l]) for l in indices] ##In progress
       
        simlarity_list = [ ]
        dict1 ={}

        for sim in similarity:
            simlarity_list.extend(sim)
        ids = [to_inc[idx] for idx in indices.flatten()]
        incidents=[]
        for inc in from_inc:
            incidents.extend([inc for i in range(nbest)])
        dict1['test_incid'] = incidents
        dict1['train_incid'] = ids
        dict1['inc_similarity_score'] = simlarity_list
        matches = pd.DataFrame(dict1)
        
    return matches
def batchprocessing(df_open_4, to_df, batch_size, form_text, to_text, from_id, to_id):

    resultdf = pd.DataFrame()
    for i in range(0,to_df.shape[0],batch_size):
        df_part = to_df[i:i+batch_size]
        print("batch length: ", len(df_part))


        df_res = cosine_similarity(df_open_4, df_part, form_text, to_text, from_id, to_id, (1,3), 10, 0)
        resultdf = pd.concat([df_res, resultdf])
    
    resultdf = resultdf.sort_values(['test_incid', 'inc_similarity_score'], ascending = False).groupby('test_incid').head(10).reset_index(drop=True)
    return resultdf
 #################################################################################################################

def finding_most_similar_inc(df_open_4) :
    global logger_inc_ko_link
    #################################  app and assignment group similarity start ##################################################
    print("start time for Lv-1 similarity filter is {0}".format(datetime.now()))
    print("shape of df_open is  {0}".format(len(df_open_4)))
    print("shape of df_closed is  {0}".format(len(df_closed)))

    logger_inc_ko_link.debug("Going to find similar incidents in level 1")
    

    #########################################polyfuzz################################################   
    try:
        print("Entered into try block for finding similar incidents")
        df_inc_similarity_score = pd.DataFrame(columns=['test_incid','train_incid','inc_similarity_score'])
        
        print('open data columns : ', df_open_4.columns)
        print('df_closed data columns : ',df_closed.columns)
        
        #df_open_4['Assigned_Group'].fillna("no_asg", inplace=True)
        #df_open_4['App_Name'].fillna('no_apn', inplace=True)
        df_open_sub = df_open_4[['Assigned_Group', 'App_Name']].drop_duplicates()
        print("df_open_Sub:\n",df_open_sub)
        logger_inc_ko_link.debug("The unique Assignment Group and Application Name combinations in open data(Open data means data from inter staging table) are:\n%s",df_open_sub)
        for y,z in zip(df_open_sub['Assigned_Group'], df_open_sub['App_Name']):                
            from_data = df_open_4.groupby('App_Name').get_group(z).groupby('Assigned_Group').get_group(y)
            logger_inc_ko_link.debug("Printing the contents of from_data which groups the open data together based on AG,AN combination:\n%s",from_data)
            print("Printing the from data:\n",from_data)
            inc = common_functions.get_inc_ids(y, z, df_closed, AGfilter, ANfilter, nonciap)
            logger_inc_ko_link.debug("Printing the incidents filtered using get_inc_ids function from closed data based on AG,AN and respective filters:\n%s",inc)
            
            to_data = df_closed[df_closed['incident_id'].isin(inc)]      ## for caip df_closed column name is Incident_id
            logger_inc_ko_link.debug("Printing the contents of to_data(from closed data if we filter those incidents which we got from get_inc_ids):\n%s",to_data)
            if len(to_data) != 0: 
                if len(to_data) > batch_size:
                    df1 = batchprocessing(from_data, to_data, batch_size, 'Inc_text', 'Inc_text', 'incident_id', 'incident_id')  
                else:
                    df1 = cosine_similarity(from_data,to_data,'Inc_text','Inc_text','incident_id','incident_id',(1,3),10,0)        
                df_inc_similarity_score = pd.concat([df_inc_similarity_score, df1], axis=0).reset_index(drop=True)
                logger_inc_ko_link.debug("Printing the contents of incident similarity score dataframe:\n%s",df_inc_similarity_score)
    except Exception as e:
        logger_inc_ko_link.error("Exception occured in level1 similarity for ticket data and error is--->"+ str(e))

    logger_inc_ko_link.debug("Finding similar incidents in level 1 completed")
    print("end time for Lv-2 similarity filter is {0}".format(datetime.now()))

   ####for most sim inc ########
   
    df_inc_similarity_score['inc_similarity_score'] = df_inc_similarity_score['inc_similarity_score'].astype(float)
    df_inc_similarity_score = df_inc_similarity_score[df_inc_similarity_score['inc_similarity_score'] > 0.05]
    most_sim_inc = df_inc_similarity_score.filter(['test_incid','train_incid'])  
    most_sim_inc = most_sim_inc.rename(columns={'test_incid':'incident_id','train_incid':'most_similar_inc'})
    logger_inc_ko_link.debug("Most similar incidents found to the open incidents are:\n%s",most_sim_inc)
    logger_inc_ko_link.debug(str("No of most similar incidents found are ")+ str(len(most_sim_inc))+"\n")

    most_sim_inc = most_sim_inc.groupby(['incident_id'])['most_similar_inc'].apply(','.join).reset_index()
    
    logger_inc_ko_link.debug("Updating most similar incidents to ticket_data and ticket_data_history tables")   #most_sim_inc.to_excel("polyfuzz_most_sim_inc_lvl1_1.xlsx")

    common_functions.update_mysql("ticket_data_history", most_sim_inc, psql)
    common_functions.update_mysql("ticket_data", most_sim_inc, psql)
     
    print("end time for Lv-2 similarity filter is {0}".format(datetime.now()))
    logger_inc_ko_link.debug("Finding most similar incidents and updating into ticket_data and ticket_data_history tables is done.")

############### second #################
    inter_df = df_inc_ko.copy()
    if len(inter_df)>0:
        logger_inc_ko_link.debug("Reading the contents of ko_detail_history_mongo table.")
        ko_detail_history = common_functions.read_table_data('ko_detail_history_mongo',psql)
        if len(ko_detail_history) > 0:
            ko_detail_history = ko_detail_history[ko_detail_history.Ko_status == "1"]
            ko_detail_history = ko_detail_history[ko_detail_history.Publication_status.isin(koStatusList)]              
            ko_list = ko_detail_history['Ko_id'].unique().tolist()
            logger_inc_ko_link.debug("Printing the KO's those are filtered based on ko status 1 and publication status from ko_detail_history_mongo table:\n%s",ko_list)
            inter_df = inter_df[inter_df['ko_id'].isin(ko_list)]
            logger_inc_ko_link.debug("Getting all the ko details from incident_ko_link_mongo table those are present in ko_detail_history_mongo:\n%s",inter_df)
    inter_df = inter_df.rename(columns={"incident_id": "most_similar_incident","ko_id": "lv1_ko_id"})
    logger_inc_ko_link.debug("Printing the contents of incident_ko_link dataframe after filtering from ko_detail_history_mongo and renaming some columns:\n%s",inter_df)
    to_data_lvl1 = df_closed[df_closed['incident_id'].isin(inter_df['most_similar_incident'])]
    logger_inc_ko_link.debug("Level1 data->Retrieving closed tickets from ticket_data_history_mongo which have ko linkage from incident_ko_link_mongo:\n%s",to_data_lvl1)
############ polyfuzz code starts ######################3
    try:
        matches = pd.DataFrame(columns=['test_incid','train_incid','inc_similarity_score'])
        
        #df_open_4['Assigned_Group'].fillna("no_asg", inplace=True)
        #df_open_4['App_Name'].fillna('no_apn', inplace=True)
        df_open_sub = df_open_4[['Assigned_Group', 'App_Name']].drop_duplicates()

        logger_inc_ko_link.debug("The unique Assignment Group and Application Name combinations in open data(Open data means data from inter staging table) are:\n%s",df_open_sub)
        for y,z in zip(df_open_sub['Assigned_Group'],df_open_sub['App_Name']):            
            from_data = df_open_4.groupby('App_Name').get_group(z).groupby('Assigned_Group').get_group(y)
            logger_inc_ko_link.debug("Printing the contents of from_data which groups the open data together based on AG,AN combination:\n%s",from_data)
            inc = common_functions.get_inc_ids(y, z, to_data_lvl1, AGfilter, ANfilter, nonciap)
            logger_inc_ko_link.debug("Printing the incidents filtered using get_inc_ids function from Level 1 data based on AG,AN and respective filters:\n%s",inc)

            to_data = to_data_lvl1[to_data_lvl1['incident_id'].isin(inc)]
            logger_inc_ko_link.debug("Printing the contents of to_data(from Level1 data if we filter those incidents which we got from get_inc_ids):\n%s",to_data)
            if len(to_data) != 0:

                if len(to_data) > batch_size:
                    df1 = batchprocessing(from_data, to_data, batch_size, 'Inc_text', 'Inc_text', 'incident_id', 'incident_id')       
                else:
                    df1 = cosine_similarity(from_data,to_data,'Inc_text','Inc_text','incident_id','incident_id',(1,3),10,0)      
                matches= pd.concat([matches, df1], axis=0).reset_index(drop=True)
                logger_inc_ko_link.debug("Printing the contents of data after finding the cosine similarity:\n%s",matches)

    except Exception as e:
        logger_inc_ko_link.error("Exception occured in similarity for final level1 and error is--->"+ str(e))

    print("end time for Lv-2 similarity filter is {0}".format(datetime.now()))

    matches = matches.rename(columns={'test_incid':'incident_id', 'train_incid':'most_similar_incident'})
    
    final_inc_lv1ko_df = pd.merge(matches, inter_df[['most_similar_incident', 'lv1_ko_id']], on='most_similar_incident', how='left')
    logger_inc_ko_link.debug("Final Level 1 data:\n%s",final_inc_lv1ko_df)

    print('final_inc_lv1ko_df:',final_inc_lv1ko_df.shape)

    print("Assignment Group check for KO begins")
    df_tkt_all = df_inc_all.copy()
    print(df_tkt_all.columns)
    
    df_ko_all = common_functions.read_table_data('ko_detail_history_mongo',psql)
    df_ko_all['Ticket_group'].fillna("no_asg", inplace=True)
    df_ko_all['App_name'].fillna("no_apn", inplace=True)
    print(df_ko_all.columns)
    final_inc_lv1ko_df['ticket_ag'] = final_inc_lv1ko_df.incident_id.map(df_tkt_all.set_index('Incident_id')['Assigned_Group'].to_dict())
    logger_inc_ko_link.debug("List of Assignment groups of incidents:\n%s",final_inc_lv1ko_df['ticket_ag'])
    final_inc_lv1ko_df['ko_ag'] = final_inc_lv1ko_df.lv1_ko_id.map(df_ko_all.set_index('Ko_id')['Ticket_group'].to_dict())
    logger_inc_ko_link.debug("List of KO assignment groups:\n%s",final_inc_lv1ko_df['ko_ag'])
    print(final_inc_lv1ko_df.shape)
    print("final_inc_lv1ko_df:\n",final_inc_lv1ko_df)
    print(final_inc_lv1ko_df['ticket_ag'] == final_inc_lv1ko_df['ko_ag'])
    final_inc_lv1ko_df = final_inc_lv1ko_df[final_inc_lv1ko_df['ticket_ag'] == final_inc_lv1ko_df['ko_ag']]
    print("final_inc_lv1ko_df:\n",final_inc_lv1ko_df)
    print(final_inc_lv1ko_df.shape)
    print("Assignment Group check for KO ends")
    final_inc_lv1ko_df = final_inc_lv1ko_df.reset_index(drop=True)

    if nonciap == 1:                  
        df_generic_account_ko_mapping = common_functions.read_table_data('generic_account_ko_mapping_mongo',psql)
        if len(df_generic_account_ko_mapping) == 0:
            df_generic_account_ko_mapping = pd.DataFrame(columns = ['generic_id','acc_ko_id','link_date'])

        for i in final_inc_lv1ko_df.index:
            if len(df_generic_account_ko_mapping.loc[df_generic_account_ko_mapping['generic_id'] == final_inc_lv1ko_df.at[i,'lv1_ko_id']]) > 0:
                final_inc_lv1ko_df.at[i,'lv1_ko_id'] = df_generic_account_ko_mapping.loc[df_generic_account_ko_mapping['generic_id'] == final_inc_lv1ko_df.at[i,'lv1_ko_id']]['acc_ko_id'].tolist()[0]
    logger_inc_ko_link.debug("replaced cloned kos")
    print('final_inc_lv1ko_df')
    print(final_inc_lv1ko_df.shape)
    logger_inc_ko_link.debug("Upserting the similarity score data into inc_similarity_scores_ko_mongo table.The data is:\n%s",final_inc_lv1ko_df)
    psql.delete_df(final_inc_lv1ko_df,'inc_similarity_scores_ko_mongo',{'incident_id'})
    psql.upsert_df(final_inc_lv1ko_df,'inc_similarity_scores_ko_mongo')

#################################  function declarations end ##################


final_inc_lv1ko_df = pd.DataFrame()

if error_string == '':
    #################################  db data retrieval and text processing s
    print(
        "start time for data retrieval and preprocessing is {0}".format(
            datetime.now()))
    logger_inc_ko_link.debug("incident ko link level is started on "+ str(datetime.now()))

    try:
        logger_inc_ko_link.debug("Reading the contents of ticket_data_history_mongo table")
        df_inc_all = common_functions.read_table_data('ticket_data_history_mongo',psql)
        df_inc_all['Assigned_Group'].fillna('no_asg',inplace=True)
        df_inc_all['App_Name'].fillna('no_apn', inplace=True)
        
        df_inc = df_inc_all.copy()
        logger_inc_ko_link.debug("No of incidents read from ticket_data_history_mongo table are:%s,.The incidents are:\n%s",str(len(df_inc)),df_inc['Incident_id'])
        logger_inc_ko_link.debug("Going to read the contents of ticket_data_inter_staging_mongo table")
        df_open = common_functions.read_table_data('ticket_data_inter_staging_mongo',psql)
        df_open['Assigned_Group'].fillna('no_asg',inplace=True)
        df_open['App_Name'].fillna('no_apn', inplace=True)
        
        logger_inc_ko_link.debug("No of incidents read from ticket_data_inter_staging_mongo table are:%s.Incidents are:\n%s",str(len(df_open)),df_open['Incident_id'])
        no_of_feed_inc = len(df_open)
        if len(df_open) == 0:
            print(error_string)
            logger_inc_ko_link.debug("ticket_data_inter_staging table has no records hence exiting the program.")
            mes = ""
            common_functions.send_email(sub, mes, 0, LOG_FILENAME, log_capture_string, html,psql,emailSender,emailReceiver)
            transaction(0)
            sys.exit()

        print("Shape of inter table data: ",df_open.shape)
        print("Columns present in inter table: ",df_open.columns)
        
        no_of_feed_inc = len(df_inc)
        
        ####################################

        
        
        
        if len(df_inc) > 0:
            #df_inc['incident_id'] = df_inc['Incident_id']
            df_inc.rename(columns={"Incident_id": "incident_id"},inplace=True)  # in CIAP
            
        else:
            df_inc = pd.DataFrame(columns = ['incident_id','App_Name','Assigned_Group','Inc_proc_text','Inc_text','Status','Summary'])
        print("*********************")
        print(df_open.columns)
        if len(df_open) > 0:
            df_open.rename(columns={"Incident_id": "incident_id"},inplace=True)
           # df_open['incident_id'] = df_open['Incident_id']
        print("###########################")
        logger_inc_ko_link.debug("Reading the contents of incident_ko_link_mongo table")
        df_inc_ko = common_functions.read_table_data('incident_ko_link_mongo',psql)
        
        logger_inc_ko_link.debug("The incident id and ko id from the link table are:\n%s",df_inc_ko[['incident_id','ko_id']])
        if len(df_inc_ko) > 0:
            if nonciap == 1:
                df_inc_ko.drop(columns=['arch_flag', 'user_id', 'link_date'], inplace=True, axis=1)
            else:
                df_inc_ko.drop(columns=['arch_flag', 'User_Id', 'link_date'], inplace=True, axis=1)

            print("Printing no of null values present in link table: ",df_inc_ko.isna().sum())

        else:
            df_inc_ko = pd.DataFrame(
                columns=[
                    'incident_id',
                    'ko_id',
                    'link_date',
                    'User_Id',
                    'arch_flag'])

        print("Printing the shape of ticket_data_hisory table: ",df_inc.shape)
        print("Printing the columns of ticket_data_hisory table: ",df_inc.columns)

        print("Printing the shape of incident_ko_link table:",df_inc_ko.shape)
        print("Printing the columns of incident_ko_link table:",df_inc_ko.columns)

        df_inc = df_inc.rename(columns = {"Inc_text": "Complete_text",
                                  "Inc_proc_text": "Inc_text"}) 
        df_open = df_open.rename(columns = {"Inc_text": "Complete_text",
                                  "Inc_proc_text": "Inc_text"}) 

        logger_inc_ko_link.debug("Preprocessing of incident text done.")
        print("Shape of ticket_data_history table contents before dropping na values")
        logger_inc_ko_link.debug("Shape of ticket_data_history table contents before dropping na values:%s, incidents are:\n%s",df_inc.shape,df_inc['incident_id'].tolist())
        print(df_inc.shape)
        if AGfilter==0:
            df_inc = df_inc.dropna(subset=['Inc_text', 'Status'])
        else:
            df_inc = df_inc.dropna(subset=['Assigned_Group','Inc_text', 'Status'])
        

        print('Shape of ticket_data_history table after dropping na values')
        logger_inc_ko_link.debug("Shape of ticket_data_history table contents after dropping na values:%s,incidents are:\n%s",df_inc.shape,df_inc['incident_id'].tolist())
        print(df_inc.shape)

        print('Shape of ticket_data_inter_staging_mongo table before dropping na values: ',df_open.shape)
        logger_inc_ko_link.debug("Shape of ticket_data_inter_staging_mongo table before dropping na values:%s,Incidents are:\n%s",df_open.shape,df_open['incident_id'].tolist())
        if AGfilter==0:
            df_open = df_open.dropna(subset=['Inc_text', 'Status'])
        else:
            df_open = df_open.dropna(subset=['Assigned_Group', 'Inc_text', 'Status'])

        print('Shape of ticket_data_inter_staging_mongo table before dropping na values: ',df_open.shape)
        logger_inc_ko_link.debug("Shape of ticket_data_inter_staging_mongo table after dropping na values:%s ,Incidents are:\n%s",df_open.shape,df_open['incident_id'].tolist())
        print(
            "end time for data retrieval and preprocessing is {0}".format(
                datetime.now()))
        ###  db data retrieval and text processing end #######

        #print("start time for tokenization is {0}".format(datetime.now()))
        df_inc = df_inc[df_inc.Status.isin(closedStatusList)] ## NONCIAP
        logger_inc_ko_link.debug("Getting Closed data->Filter all the closed status incidents from ticket_data_history_mongo table.No of incidents are:%s,The incidents are:\n%s",str(len(df_inc)),df_inc['incident_id'])
        df_closed = df_inc.copy()  ## CIAP
        print(df_closed.shape)
        #print("end time for tokenization is {0}".format(datetime.now()))


        if len(df_closed) > 100000:
            no_of_inc = int(len(df_closed)/2)
            df_closed_v1 = df_closed.head(no_of_inc)
            df_closed = df_closed_v1

        print("shape of closed df is {0}".format(df_closed.shape))
        print("shape of open df is {0}".format(df_open.shape))
        print("end time for segregation is {0}".format(datetime.now()))

        ##### comparing open and closed incidents start #########
        if len(df_open) < ticketThreshold :
            ####  app and assignment group similarity start #############
            print("start time for Lv-1 similarity filter is {0}".format(datetime.now()))   
            finding_most_similar_inc(df_open)
    
            ################# merging inc- ko to dataframe end ####################
        else:
            open_count = len(df_open)

            count = int(open_count/3)
    
            df_open_1 = df_open[:count]
            df_open_2 = df_open[count:count+count]
            df_open_3 = df_open[count+count:]
            
    
            t1 = threading.Thread(target=finding_most_similar_inc, args=(df_open_1,)) 
            t2 = threading.Thread(target=finding_most_similar_inc, args=(df_open_2,)) 
            t3 = threading.Thread(target=finding_most_similar_inc, args=(df_open_3,))
     
    
            # starting thread 1 
            t1.start() 
            # starting thread 2 
            t2.start() 
            # starting thread 3 
            t3.start()
    
    
            # wait until thread 1 is completely executed 
            t1.join() 
            # wait until thread 2 is completely executed 
            t2.join() 
            # wait until thread 3 is completely executed
            t3.join()
             

    except Exception as e:
        logger_inc_ko_link.error("Exception occured in inc_ko_link file(Level-1) and error is--->"+ str(e))
        logger_inc_ko_link.debug("Exception occurred in level 1 so processed incidents are : 0")
        print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
        error_string = str(e)
        
        exception_type, exception_object, exception_traceback = sys.exc_info()
        line_number = exception_traceback.tb_lineno
        logger_inc_ko_link.error("exception_type for Incident ko link script: "+ str(exception_type))
        logger_inc_ko_link.error("line_number for Incident ko link script : "+ str(line_number))        
        
        
        mes = 'PFA of log file'
        common_functions.send_email(sub, mes, 1, LOG_FILENAME, log_capture_string, html,psql,emailSender,emailReceiver)
        transaction(1)
        logger_inc_ko_link.debug("inc ko link run ended at "+ datetime.strftime(datetime.now(),"%Y-%m-%d %H:%M:%S"))
        sys.exit()
        
    else:
        logger_inc_ko_link.debug("inc ko link run ENDED at "+ datetime.strftime(datetime.now(),"%Y-%m-%d %H:%M:%S"))
        mes = ''
        common_functions.send_email(sub, mes, 0, LOG_FILENAME, log_capture_string, html,psql,emailSender,emailReceiver)
        transaction(0)
print("End time for incident ko link processing is {0}".format(datetime.now()))
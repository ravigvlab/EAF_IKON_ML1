# =========================================================================================================================
# File Name     : inc_send_ko_proposal_common.py
# -------------------------------------------------------------------------------------------------------------------------
# Purpose       : Purpose of this script is to send similar ko's and incident's to Data Lake.
# Author        : Harinadh Reddy
# Co-Author     : 
# Creation Date : 11-NOV-2022
# Usage         : 'python ' + commonsFolderPath + 'inc_send_ko_proposal_common.py --accountName ' + accountName
# History       :
# -------------------------------------------------------------------------------------------------------------------------
# Date          | Author                       | Co-Author                    | Remark
# 11-Nov-2022   | Harinadh Reddy               |                              | Initial Release
# =========================================================================================================================
###########################################################################################################################
# Import required Module / Packages
###########################################################################################################################

import warnings
from datetime import datetime
import sys
import os
import requests
import json
import configparser
import time
import common_functions
import pandas as pd
warnings.filterwarnings("ignore")
from DatabaseFunctions import DatabaseFunctions


################################ Created Empty strings ##############################
error_string = ''
runid = 0
logger_datalake = ''
runid = datetime.now().strftime('%Y%m%d%H%M%S')


################################ Arguments  ###########################################
argumentList = sys.argv[1:]

args_list = common_functions.get_common_args(argumentList)
accountName = args_list[0]

############################### Reading config File  ################################

try:

    config = common_functions.get_config(accountName)
    
    dbDetail = common_functions.get_dbdetail(config)
    dbName = dbDetail['dbName']
    host = dbDetail['host']
    user = dbDetail['user']
    password = dbDetail['password']
    port = dbDetail['port']
    schema = dbDetail['schema']  

    path = config.get('PathsSection', 'path.folder')     
    url = config.get('DatalakeSection', 'datalake.proposal.url')
    token = config.get('DatalakeSection', 'datalake.proposal.token')
    ko_category = config.get('DatalakeSection', 'ko.categoryName')
    inc_category = config.get('DatalakeSection', 'inc.categoryName')
    #payload_header = {"Content-Type":"application/json", "Authorization": "Bearer "+str(token)}

    # tenant_name = Capgemini Test 1

    tenant_name = config.get('DatalakeSection', 'tenant_name')

    params = {"tenant_name": "Capgemini Test 1"}

    headers = {"Content-Type":"application/json", "Authorization": "Bearer "+str(token), "tenant_name": str(tenant_name)}
    #headers = {"Content-Type":"application/json", "tenant_name": str(tenant_name), "Authorization": "Bearer "+str(token)}


   ###################### fetching path details ##############################
    accountFolderPath = config.get('PathsSection', 'path.folder')
    commonsFolderPath = config.get('PathsSection', 'path.commons')
    accountLogPath = config.get('PathsSection', 'path.log')

    ###################### fetching email details #############################
    emailSender = config.get('EmailSection', 'email.sender')
    emailReceiver = config.get('EmailSection', 'email.receiver')

    ### log file creating ###
    LOG_DIR = os.path.join(accountLogPath, accountName, "inc_send_ko_proposal_logs")
    if not os.path.exists(LOG_DIR):
        os.makedirs(LOG_DIR)
    LOG_FILENAME = os.path.join(LOG_DIR, f"{accountName}_inc_send_ko_proposal_ikon2_logger_{runid}.log")

    print(LOG_FILENAME)
    logger_inc_score, log_capture_string = common_functions.getLogger(LOG_FILENAME,accountName)

except Exception as e:
    print ("Error occured while reading the config or setting up logger in incident_score: " + str(e))
    

    print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)


    sys.exit()


############################## log file writing  ########################################
def print_log():
    with open(LOG_FILENAME, 'a+') as f:
        f.write(logger_datalake)

############################## Connecting to DB #####################################
try:  
    psql = DatabaseFunctions(host, user, password, port,dbName,schema, config= config) 
    #account_processes_db = common_functions.database_account_process()  ############ Need to check
except Exception as e:
    print(
        "Could not connect to postgresql in incident score file and error is--->" +
        str(e))
    logger_inc_score.error(
        "Incident score process failed due to postgresql db connectivity issue")
    sys.exit()
else:
    print("Connected successfully!!!")

############################ Reading ticket data proposal history ###################
try:
    logger_datalake = logger_datalake+str("payload header detail : ")+ str(headers)+"\n"
    logger_datalake = logger_datalake+str("KO send proposal run started at")+ datetime.strftime(datetime.now(),"%Y-%m-%d %H:%M:%S")+"\n"
    proposal_data = psql.select_df('ticket_data_proposal_history')
    proposal_data = proposal_data.filter(['ticketid','sendattempts','proposalsenddate', 'proposalsendstatus', 'sys_id'])
    proposal_data['sendattempts'] = proposal_data['sendattempts'].fillna(0)
    proposal_data = proposal_data.loc[(proposal_data['sendattempts'] < 3) & (proposal_data['proposalsendstatus'] != 1)]
    proposal_data = proposal_data.reset_index(drop=True)
    proposal_inc_list = proposal_data['ticketid'].to_list()
    total_his_data = psql.select_df('ticket_data_history','ticketid',proposal_inc_list)
    total_his_data = total_his_data.filter(['ticketid', 'relevperc', 'usageperc', 'similarincidents', 'servicetype', 'sys_id'])
    logger_datalake = logger_datalake+str("Total proposal records : ")+ str(len(proposal_data))+"\n"
    
    for i in range(len(proposal_data)):
        inc = proposal_data.at[i,'ticketid']
        logger_datalake = logger_datalake + str("Preparing data for : ") + inc + "\n"
        his_data = total_his_data[total_his_data['ticketid'] == inc]
        his_data = his_data.reset_index(drop=True)

        if len(his_data) > 0:

            ############################## Handling Incidents ###################################
            his_inc = his_data[['ticketid', 'similarincidents']]
            his_inc = his_inc.dropna(subset = ['similarincidents']).reset_index(drop=True)
            
            try:
                if len(his_inc) > 0:
                    his_inc = common_functions.explode(his_inc.assign(similarincidents=his_inc.similarincidents.str.split(',')),'similarincidents')
                    his_inc = his_inc[his_inc['similarincidents'] != inc]
                    his_inc = his_inc.head(3)
                    his_inc_list = his_inc['similarincidents'].to_list()

                    his_inc_data = psql.select_df('ticket_data_history','ticketid',his_inc_list)
                    his_inc_data = his_inc_data.filter(['ticketid', 'summary', 'notes', 'resolutionnote', 'category', 'sys_id'])
                    his_inc_data['categoryName'] = inc_category  ## get it from config
                    his_inc_data = his_inc_data.rename(columns={"ticketid":"solutionnumber",
                                                                "summary":"goal",
                                                                "notes":"problemDetail",
                                                                "resolutionnote":"solutionText",
                                                                "sys_id":"sysId"})
                    his_inc_data['description'] = ''
                    his_inc_data['score'] = ''
                    his_inc_data['userScore'] = ''
                    
                    his_inc_dict = his_inc_data.to_dict('records')
                    
                else:
                    his_inc_dict =[]

            except Exception as e:
                his_inc_dict =[]
                logger_datalake = logger_datalake+str("Exception occured while processing similar incidents and exception is : ")+ str(e)+"\n"

            ################################# Handling Ko's #####################################
            try:
                his_ko = his_data[['ticketid','relevperc','usageperc','sys_id']]
                his_ko = his_ko.dropna(subset = ['relevperc', 'usageperc'],how='all').reset_index(drop=True)
                
                if len(his_ko) > 0:
                    his_ko = common_functions.explode(his_ko.assign(relevperc=his_ko.relevperc.str.split(';')),'relevperc')
                    his_ko = common_functions.explode(his_ko.assign(usageperc=his_ko.usageperc.str.split(';')),'usageperc')
                    his_ko[['ko_id_rel','relevperc']] = his_ko.relevperc.str.split(":",expand=True)
                    his_ko[['ko_id_usg','usageperc']] = his_ko.usageperc.str.split(":",expand=True)
                    his_ko = his_ko[his_ko['ko_id_rel'] == his_ko['ko_id_usg']]
                    his_ko['relevperc'] = his_ko['relevperc'].astype(int)
                    his_ko['usageperc'] = his_ko['usageperc'].astype(int)
                    his_ko = his_ko.drop_duplicates(subset =['ticketid', 'relevperc', 'usageperc', 'ko_id_rel', 'ko_id_usg'], keep='first')
                    his_ko = his_ko.sort_values(by = ['relevperc', 'usageperc', 'ko_id_rel'], ascending = [False, False, False], na_position = 'first')
                    his_ko = his_ko.head(3)
                    sim_ko_id = his_ko['ko_id_rel'].to_list()

                    ko_info_data = psql.select_df('ko_info', 'koid', sim_ko_id)
                    his_ko_data = pd.merge(his_ko, ko_info_data[['koid', 'shortdescription', 'longdescription']], how ="left", left_on='ko_id_rel', right_on='koid')
                    his_ko_data = his_ko_data.filter(['koid', 'relevperc', 'usageperc', 'shortdescription', 'longdescription'])
                    his_ko_data = his_ko_data.rename(columns={  "koid":"solutionnumber",
                                                                "longdescription":"goal",
                                                                "shortdescription":"description",
                                                                "relevperc":"score",
                                                                "usageperc":"userScore"})
                    his_ko_data['categoryName'] = ko_category 
                    his_ko_data['solutiontext'] = ''
                    his_ko_data = his_ko_data.reset_index(drop=True)
                    his_ko_data['rank'] = his_ko_data.index + 1

                    his_ko_dict = his_ko_data.to_dict('records')
                    
                else:
                    his_ko_dict = []

            except Exception as e:
                his_ko_dict =[]
                logger_datalake = logger_datalake+str("Exception occured while processing similar ko's and exception is : ")+ str(e)+"\n"
            
            his_final_dict = his_inc_dict + his_ko_dict

            ############################# Final json file #######################################
            if len(his_final_dict) > 0:
                final_payload = {
                    "sys_id":his_data['sys_id'][0],
                    "incident_type":his_data['servicetype'][0],
                    "data":his_final_dict
                }
                
                final_payload = json.dumps(final_payload, indent = 4)
                
                ########################### Posting json file to url ################################
                response = requests.post(url = url, headers = headers, data = final_payload) #, params= params)  #headers = token,
                logger_datalake = logger_datalake + str("Status Code : ") + str(response.status_code) + "\n"

                if response.status_code == 200 or response.status_code == 201:
                    proposal_data.at[i,'proposalsendstatus'] = 1
                else:
                    proposal_data.at[i,'proposalsendstatus'] = 0
                    logger_datalake = logger_datalake + str("Failed to send data for : ") + inc + "\n"
                    logger_datalake = logger_datalake + str("final payload is: ") + str(final_payload) + "\n"


                proposal_data.at[i,'sendattempts'] = proposal_data.at[i,'sendattempts'] + 1
                proposal_data.at[i,'sys_id'] = his_data['sys_id'][0]
                proposal_data.at[i,'proposalsenddate'] = pd.datetime.now()
                
            else:
                proposal_data.at[i,'proposalsendstatus'] = 0
                proposal_data.at[i,'sendattempts'] = proposal_data.at[i,'sendattempts'] + 1
                proposal_data.at[i,'sys_id'] = his_data['sys_id'][0]
                proposal_data.at[i,'proposalsenddate'] = pd.datetime.now()
                
        else:
            proposal_data.at[i,'proposalsendstatus'] = 0
            proposal_data.at[i,'sendattempts'] = proposal_data.at[i,'sendattempts'] + 1
            proposal_data.at[i,'proposalsenddate'] = pd.datetime.now()

    if( len(proposal_data) > 0 ):
        psql.update_df(proposal_data,'ticket_data_proposal_history',{'ticketid'})
        
    logger_datalake = logger_datalake+str("KO send proposal run ended Successfully at")+ datetime.strftime(datetime.now(),"%Y-%m-%d %H:%M:%S")+"\n"

except Exception as e: 
    logger_datalake = logger_datalake+str(["Error ocurred in script",
                            "Line No: " + str(sys.exc_info()[2].tb_lineno),
                            "Exception type: " + str(sys.exc_info()[0]),
                            "Error: " + str(e)])+"\n"
    error_string = error_string + str(e)
    logger_datalake = logger_datalake+str("KO send proposal run ended at ")+ datetime.strftime(datetime.now(),"%Y-%m-%d %H:%M:%S")+"\n"
    print_log()
    sys.exit()

else:
    logger_datalake = logger_datalake+str("KO send proposal run ENDED at ")+ datetime.strftime(datetime.now(),"%Y-%m-%d %H:%M:%S")+"\n"
    print_log()

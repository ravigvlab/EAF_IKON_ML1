####################### import section start ##################################
import pandas as pd
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import nltk
import re
import truecase
from stop_words import get_stop_words

from fast_autocomplete import AutoComplete

from flask import Flask, render_template, request
from flask_request_params import bind_request_params
from flask_cors import CORS
import json
from urllib.parse import unquote


from nltk.util import ngrams
from collections import Counter
from datetime import datetime
import os
import configparser

from DatabaseFunctions import DatabaseFunctions 
import sys, getopt
import telnetlib
from urllib.parse import urlsplit
import time
#from waitress import serve

######################### import section end ##################################

############### fetching command  line arguments section start ################

# Arguments
argumentList = sys.argv[1:]
 
# Options
short_options = ""
 
# Long options
long_options = ["folderPath=","port="]
 
try:
    # Parsing argument
    arguments, values = getopt.getopt(argumentList, short_options, long_options)

    # checking each argument
    for currentArgument, currentValue in arguments:
            
        if currentArgument in ("--folderPath"):
            print ("folderPath: ", currentValue)
            folderPath=currentValue
#        elif currentArgument in ("--host"):
#            print ("host: ", currentValue)
#            host=currentValue
        elif currentArgument in ("--port"):
            print ("port: ", currentValue)
            port=int(currentValue)
        
except getopt.error as err:
    # output error, and return with an error code
    print (str(err))
    sys.exit()


############### fetching command  line arguments section end ################

################## global initializations for preprocessing start #############
stop_words = list(get_stop_words('en'))  # About 900 stopwords
nltk_words = list(stopwords.words('english'))  # About 150 stopwords
stop_words.extend(nltk_words)  # Combining both of the stop word list
stop_words.extend(['system'])

lemmatizer = WordNetLemmatizer()

accounts = {}
################## global initializations for preprocessing end ###############


######################### Connection to Postgresql DB Start ########################
#db_name = 'ikon2'
#host_name = 'inblrvm05585155'
#user_id = 'ikon_natools'
#pwd = 'ikon_natools'
#port_no = 5432
#schema = 'ikon_natools'
#
#psql = DatabaseFunctions(host_name, user_id, pwd, port_no,db_name,schema)
######################### Connection to Postgresql DB End ##########################

 
######################## Flask Application initialization start ###############
app = Flask(__name__)
CORS(app)
app.before_request(bind_request_params)

# Get the process ID of 
# the current process 
pid = os.getpid() 
  
# Print the process ID of 
# the current process 
print(pid)  
######################## Flask Application initialization end #################


@app.after_request
def after_request(response):
  response.headers.add('Access-Control-Allow-Origin', '*')
  response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
  response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
  return response

# Also change the account in html template
@app.route("/")
def home():
    return render_template("home.html")

# These are test funcs and need to be deleted later. Also the above func mapping needs to be changed.
@app.route("/demo")
def home_demo():
    return render_template("home_demo.html")
    
@app.route("/search")
def search():

    print(type(request.args.keys()))
    print(list(request.args.keys()))                                   
    accountName=request.args.get('account')
    if( accountName == None ):
        accountName=request.args.get('accountName')
        if( accountName == None ):
            accountName= list(request.args.keys())[1]
            
    #accountName=request.args.get('account')
    search_str = request.args.get('search_str')
    
    search_str = process_text(search_str)
    search_str = oneliner_for_processing(search_str)
    
    autocomplete = accounts[accountName]    
    res=autocomplete.search(word=search_str, max_cost=3, size=5)
    restuple = tuple(x[0] for x in res)
    jsonStr = json.dumps(restuple)
    print(jsonStr)
    return jsonStr


def train(accountName):
    
    global accounts
    
    psql = getDb(accountName)
    
    df_token = psql.select_df('tokens_freq_mongo')
    df_bigram= psql.select_df('bigram_freq_mongo')
    df_trigram = psql.select_df('trigram_freq_mongo')
    
    df_search_token = psql.select_df('search_tokens_freq_mongo')
    df_search_bigram= psql.select_df('search_bigram_freq_mongo')
    df_search_trigram = psql.select_df('search_trigram_freq_mongo')
    
    df_ko_token = psql.select_df('ko_tokens_freq_mongo')
    df_ko_bigram= psql.select_df('ko_bigram_freq_mongo')
    df_ko_trigram = psql.select_df('ko_trigram_freq_mongo')

      
    words={}
    
    for i in df_token.index:
        words[df_token.at[i,'tokens']]={}
        
    for i in df_bigram.index:
        words[df_bigram.at[i,'bigram']]={}
        
    for i in df_trigram.index:
        words[df_trigram.at[i,'trigram']]={}
        
    for i in df_search_token.index:
        words[df_search_token.at[i,'tokens']]={}
        
    for i in df_search_bigram.index:
        words[df_search_bigram.at[i,'bigram']]={}
        
    for i in df_search_trigram.index:
        words[df_search_trigram.at[i,'trigram']]={}
        
    for i in df_ko_token.index:
        words[df_ko_token.at[i,'tokens']]={}
        
    for i in df_ko_bigram.index:
        words[df_ko_bigram.at[i,'bigram']]={}
        
    for i in df_ko_trigram.index:
        words[df_ko_trigram.at[i,'trigram']]={}       
    
    autocomplete = AutoComplete(words=words)
        
    for i in df_token.index:
        autocomplete.update_count_of_word(word=df_token.at[i,'tokens'], count=df_token.at[i,'freq']) 
        
    for i in df_bigram.index:
        autocomplete.update_count_of_word(word=df_bigram.at[i,'bigram'], count=df_bigram.at[i,'freq'])  
        
    for i in df_trigram.index:
        autocomplete.update_count_of_word(word=df_trigram.at[i,'trigram'], count=df_trigram.at[i,'freq'])  
    
    for i in df_search_token.index:
        autocomplete.update_count_of_word(word=df_search_token.at[i,'tokens'], count=df_search_token.at[i,'freq']) 
        
    for i in df_search_bigram.index:
        autocomplete.update_count_of_word(word=df_search_bigram.at[i,'bigram'], count=df_search_bigram.at[i,'freq'])  
        
    for i in df_search_trigram.index:
        autocomplete.update_count_of_word(word=df_search_trigram.at[i,'trigram'], count=df_search_trigram.at[i,'freq'])
        
    for i in df_ko_token.index:
        autocomplete.update_count_of_word(word=df_ko_token.at[i,'tokens'], count=df_ko_token.at[i,'freq']) 
        
    for i in df_ko_bigram.index:
        autocomplete.update_count_of_word(word=df_ko_bigram.at[i,'bigram'], count=df_ko_bigram.at[i,'freq'])  
        
    for i in df_ko_trigram.index:
        autocomplete.update_count_of_word(word=df_ko_trigram.at[i,'trigram'], count=df_ko_trigram.at[i,'freq'])

    accounts[accountName] = autocomplete

    return "done training"


@app.route("/train")
def train_api():
    accountName=request.args.get('account')    
    return train(accountName)

    
@app.route("/save")
def preprocess_save():
    
    start_time=datetime.now()
    
    original=unquote(request.args.get('train_str'))
    accountName=request.args.get('account')
    if( accountName == None ):
        accountName=request.args.get('accountName')
        if( accountName == None ):
            accountName= list(request.args.keys())[1]

    #accountName=request.args.get('account')
    
    print(original)
      
    dummy = original
    temp = dummy[0].lower() + dummy[1:]
    proc_str = process_text(temp)
    proc_str = oneliner_for_processing(proc_str)
    proc_str = proc_str.lower()
    search_key = {
       "original":original,
       "processed" : proc_str
       }
    jsonStr = json.dumps(search_key)
    print(jsonStr)
     
    psql = getDb(accountName)
    
    if proc_str!=None: 
        save_search_tokens(proc_str,psql)
        save_search_bigrams(proc_str,psql)
        save_search_trigrams(proc_str,psql)
        #train_scentence(str)
        
    end_time=datetime.now()
    print(start_time-end_time)
    return jsonStr


def save_search_trigrams(text,psql):
       
    tokens = nltk.word_tokenize(text)
    trigrams = ngrams(tokens,3)

    insert_list=[]
    tri=Counter(trigrams)
    print(tri)
    for key in tri:
        print(key)
        insert_list.append([' '.join(key),tri[key]])


    trigram_freq_table = pd.DataFrame(insert_list, columns=['trigram', 'freq']).sort_values(by='freq', ascending=False)
    print(trigram_freq_table.head())
           
    for i in trigram_freq_table.index:
        tri_df = psql.select_df('search_trigram_freq_mongo','trigram',[trigram_freq_table.at[i,'trigram']])
        print(tri_df)
        if tri_df.empty:
            df = pd.DataFrame({"trigram":[trigram_freq_table.at[i,'trigram']],"freq":[1]})
            psql.insert_df(df,'search_trigram_freq_mongo')
        else:
            df = pd.DataFrame({"trigram":[trigram_freq_table.at[i,'trigram']],"freq":[int(str(tri_df.loc[0,'freq']+ trigram_freq_table.at[i,'freq']))]})
            psql.update_df(df,'search_trigram_freq_mongo',{'trigram'})


def save_search_bigrams(text,psql):
        
    tokens = nltk.word_tokenize(text)
    bigrams = ngrams(tokens,2)
   

    #print(Counter(bigrams))
    insert_list=[]
    bi=Counter(bigrams)
    print(bi)
    for key in bi:
        print(key)
        insert_list.append([' '.join(key),bi[key]])


    bigram_freq_table = pd.DataFrame(insert_list, columns=['bigram', 'freq']).sort_values(by='freq', ascending=False)
    print(bigram_freq_table.head())

    for i in bigram_freq_table.index:
        bi_df = psql.select_df('search_bigram_freq_mongo','bigram',[bigram_freq_table.at[i,'bigram']])
        print(bi_df)
        if bi_df.empty:
            df = pd.DataFrame({"bigram":[bigram_freq_table.at[i,'bigram']],"freq":[1]})
            psql.insert_df(df,'search_bigram_freq_mongo')
        else:
            df = pd.DataFrame({"bigram":[bigram_freq_table.at[i,'bigram']],"freq":[int(str(bi_df.loc[0,'freq']+ bigram_freq_table.at[i,'freq']))]})
            psql.update_df(df,'search_bigram_freq_mongo',{'bigram'})


def save_search_tokens(text,psql):
       
    count = 0
    tokens_list = []
    tokens_list = text.split(' ')

    while "" in tokens_list:
        tokens_list.remove("")

    count = len(set(tokens_list))
    print(count)

    token_freq_dict = dict(Counter(tokens_list))
    print(token_freq_dict)

    tokens_freq_table = pd.DataFrame(
        list(
            token_freq_dict.items()),
        columns=[
            'token',
            'freq']).sort_values(
        by='freq',
        ascending=False)

    print(tokens_freq_table.head())
       
    for i in tokens_freq_table.index:
        token_df = psql.select_df('search_tokens_freq_mongo','tokens',[tokens_freq_table.at[i,'token']])
        print(token_df)
        if token_df.empty:
            df = pd.DataFrame({"tokens":[tokens_freq_table.at[i,'token']],"freq":[1]})
            psql.insert_df(df,'search_tokens_freq_mongo')
        else:
            df = pd.DataFrame({"tokens":[tokens_freq_table.at[i,'token']],"freq":[int(str(token_df.loc[0,'freq']+ tokens_freq_table.at[i,'freq']))]})
            psql.update_df(df,'search_tokens_freq_mongo',{'tokens'})
            
            
# This function tokenizes, removes the proper nouns, removes stopwords,
# lemmitize and lowercasing in order
def oneliner_for_processing(sentence):
    sentence = str(sentence).strip()
    if len(sentence) != 0:
        final_array = [
            lemmatizer.lemmatize(
                word.lower(), pos='v') for word, tag in nltk.tag.pos_tag(
                word_tokenize(sentence)) if tag != 'NNP' and tag != 'NNPS' and word not in stop_words]
        return " ".join(final_array)
    return ""

 


# function to remove stop words and lemmatize
def stem_sentence(sentence):
    token_words = word_tokenize(sentence)
    token_words = [word for word in token_words if word not in stop_words]
    stem_sentence = []
    for word in token_words:
        stem_sentence.append(lemmatizer.lemmatize(word))
    return " ".join(stem_sentence)

 
def process_text(text):
    #text = text.encode('ascii', errors='ignore').decode()
    text = str(text)
    #text = text.lower()
    text = re.sub(r'^From.*\n?', '', text, flags=re.MULTILINE)
    text = re.sub(r'^Sent.*\n?', '', text, flags=re.MULTILINE)
    text = re.sub(r'^To.*\n?', '', text, flags=re.MULTILINE)
    text = re.sub(r'^Cc.*\n?', '', text, flags=re.MULTILINE)
    text = text.replace("Work notes", "")
    text = text.replace("additional comments", "")
    text = re.sub(r'\d{4}-\d{2}-\d{2}', ' ', text)
    text = re.sub(r'\d{2}:\d{2}:\d{2}', ' ', text)
    text = re.sub(r'http\S+', ' ', text)
    text = re.sub(r'#+', ' ', text)
    text = re.sub(r'_', ' ', text)
    text = re.sub(r'\S+@\S+', ' ', text)
    text = re.sub(r"([A-Za-z]+)'s", r"\1 is", text)
    #text = re.sub(r"\'s", " ", text)
    text = re.sub(r"\'ve", " have ", text)
    text = re.sub(r"won't", "will not ", text)
    text = re.sub(r"isn't", "is not ", text)
    text = re.sub(r"can't", "can not ", text)
    text = re.sub(r"n't", " not ", text)
    text = re.sub(r"i'm", "i am ", text)
    text = re.sub(r"\'re", " are ", text)
    text = re.sub(r"\'d", " would ", text)
    text = re.sub(r"\'ll", " will ", text)
    text = re.sub(r'\W', ' ', text)
    text = re.sub(r'\d+', ' ', text)
    text = re.sub(r'\s+', ' ', text)
    text = re.sub(r'\b\w{1,2}\b', '', text)
    return text


def truecasing(text):
    return truecase.get_true_case(text)

def getDb(accountName):
    config = configparser.RawConfigParser()
    
    config.read(folderPath+'\\'+accountName+'\\ConfigFile.properties')
    
    ###################### fetching account database details ###############################
    dbName = config.get('DatabaseSection', 'database.dbname')
    host = config.get('DatabaseSection', 'database.host')
    user = config.get('DatabaseSection', 'database.user')
    password = config.get('DatabaseSection', 'database.password')
    port = config.get('DatabaseSection', 'database.port')
    schema = config.get('DatabaseSection', 'database.schema')

    psql = DatabaseFunctions(host, user, password, port,dbName,schema, config = config)
    
    return psql

def verify_service(endpoint):

    netloc = "{0.netloc}".format(urlsplit(endpoint))
    scheme = "{0.scheme}".format(urlsplit(endpoint))

    if netloc == '':
        return False

    p = netloc.split(":")

    if len(p) == 2:
        host = p[0]
        port = p[1]
    else:
        host = p[0]
        port = 80 if scheme == "http" else "443"

    try:
        telnetlib.Telnet(host,port)
        time.sleep(1)
    except:
        return False

    return True
                
if __name__ == "__main__":
    
#    path = "D:\\IKON\\generic_postgresql\\ML\\"

    folderList = []
    for x in os.walk(folderPath):
        folderList = x[1]
        break
    
    if 'CommonConfigFile.properties' in folderList:
        folderList.remove('CommonConfigFile.properties')
    
    
    print(folderList)
     
    
    try:
        res = verify_service('http://localhost:'+str(port)+'/')
        try:
            for accountName in folderList:
                try:
                    train(accountName)                    
                    print('Training done for {0} account '.format(accountName))
                    
                except Exception as e:
                    print('while Training getting error --> ',str(e))
                    # pass
            if not res:
                app.run(host = '0.0.0.0',port = port)
        except Exception as e:
            print('App could not start beacuse of ',str(e))  
    except Exception as e:
        print('Exception while verifying service ',str(e))
    

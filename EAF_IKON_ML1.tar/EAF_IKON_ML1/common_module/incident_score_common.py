# =========================================================================================================================
# File Name     : incident_score_common.py
# -------------------------------------------------------------------------------------------------------------------------
# Purpose       : Purpose of this script is to genarate incident tags.
# Author        : Sai, Harinadh Reddy
# Co-Author     : 
# Creation Date : 11-NOV-2022
# Usage         : 'python ' + commonsFolderPath + 'incident_score_common.py --accountName ' + accountName
# History       :
# -------------------------------------------------------------------------------------------------------------------------
# Date          | Author                       | Co-Author                    | Remark
# 11-Nov-2022   | Sai, Harinadh Reddy          |                              | Initial Release
# =========================================================================================================================
###########################################################################################################################
# Import required Module / Packages
###########################################################################################################################

import common_functions
from datetime import datetime
import pandas as pd
import numpy as np
import sys,getopt
import nltk
import itertools
from collections import Counter
import os
from DatabaseFunctions import DatabaseFunctions
from common_functions import multilingual
import configparser
import ast

error_string = ''
runid = 0
logger_inc_score = ''
no_of_feed_inc = 0
no_of_inc_tags = 0
df_inc_score = pd.DataFrame()
start_time = datetime.now()
runid = datetime.now().strftime('%Y%m%d%H%M%S')


# Arguments
argumentList = sys.argv[1:]

args_list = common_functions.get_common_args(argumentList)
accountName = args_list[0]
 

try:
    
    print('Going to Read config files')
    config = common_functions.get_config(accountName)
    print('Completed to Reading config files')
    
    ###################### fetching path details ##############################
    accountFolderPath = config.get('PathsSection', 'path.folder')
    commonsFolderPath = config.get('PathsSection', 'path.commons')
    accountLogPath = config.get('PathsSection', 'path.log')
    print(' ================ commonsFolderPath =================: ', commonsFolderPath)
    
    
    dbDetail = common_functions.get_dbdetail(config)
    print('DB Details is: ',dbDetail) 
    dbName = dbDetail['dbName']
    host = dbDetail['host']
    user = dbDetail['user']
    password = dbDetail['password']
    port = dbDetail['port']
    schema = dbDetail['schema']    



    ###################### fetching path details ##############################
    accountFolderPath = config.get('PathsSection', 'path.folder')
    commonsFolderPath = config.get('PathsSection', 'path.commons')
    accountLogPath = config.get('PathsSection', 'path.log')

    ###################### fetching email details #############################
    emailSender = config.get('EmailSection', 'email.sender')
    emailReceiver = config.get('EmailSection', 'email.receiver')
    
    hour_step = int(config.get('Multitanancy', 'hour.step'))
    min_step = int(config.get('Multitanancy', 'min.step'))
    volume_threshold = int(config.get('Multitanancy', 'volume.threshold'))
    
    
    ###################### fetching status details ############################
    closedStatusList = config.get('StatusSection', 'status.closed')
    koStatusList = config.get('StatusSection', 'status.ko')

    ###################### fetching generic ko details ########################
    processGenericKo = config.get('GenericSection', 'sap.flag')

    ###################### fetching AG and AN filter details #########################
    # ticketThreshold = config.get('ThresholdSection', 'threshold.ticket')
    AGfilter = int(config.get('FilterSection', 'filter.AG'))

    ### log file creating ###
    LOG_DIR = os.path.join(accountLogPath,accountName,"inc_score_logs")
    if not os.path.exists(LOG_DIR):
        os.makedirs(LOG_DIR)
    LOG_FILENAME = os.path.join(LOG_DIR, f"{accountName}_incidentScore_ikon2_logger_{runid}.log")

    print(LOG_FILENAME)
    logger_inc_score, log_capture_string = common_functions.getLogger(LOG_FILENAME,accountName)


    port=int(port)

    if koStatusList!='':
        koStatusList = koStatusList.split(',')
    if closedStatusList!='':
        closedStatusList = closedStatusList.split(',')
    print(accountFolderPath)

    # multilingual
    default_lang = config.get('SupportLanguage', 'default_lang')
    support_langs = config.get('SupportLanguage', 'lang_supported')
    support_langs = ast.literal_eval(support_langs)
    multi_language = config.get('SupportLanguage', 'multi_language')
    multi_language = int(multi_language) 

    ## loading lemma model
    multilingual = multilingual(accountName)
    load_lemma_model = multilingual.load_model(support_langs)

    ## generic section 
    nonciap = int(config.get('GenericSection', 'account.type.nonciap'))   
    batch_size = int(config.get('GenericSection', 'max.train.batch'))
    max_records = int(config.get('GenericSection','max.records.toprocess'))

except Exception as e:
    print ("Error occured while reading the config or setting up logger in incident_score: " + str(e))
    sys.exit() 


feed_name = "Incident Tags Process"
sub = "Incident Tags Process"
html = """<br>Summary of relevancy run for incident feed(""" + str(runid) + """)<br>
    start time = """ + str(start_time) + """<br>
    end time = """ + str(datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")) + """<br>
    No.of records in feed = """ + str(no_of_feed_inc) + """<br>
    No.of incidents for which incident tags are created = """ + str(no_of_inc_tags) + """
    """
    
data = """{"inc_in_feed": """ + str(no_of_feed_inc) + """,
       "no_of_inc_tags": """ + str(no_of_inc_tags) +"""}"""
  

def transaction(iserror):
    status = ''
    if iserror == 0:
        status = "success"
    else:
        status = "failed"
        
    df=pd.DataFrame(columns=['run_id', 'active', 'start_time', 'end_time', 'inc_in_feed','no_of_inc_tags', 'status'])
    df = df.append(pd.Series([runid,0, datetime.strftime(start_time, "%Y-%m-%d %H:%M:%S"),datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S"), no_of_feed_inc,no_of_inc_tags,status], index=df.columns ), ignore_index=True)
    psql.upsert_df(df, 'run_transactions_mongo')


logger_inc_score.debug("incident score file run started at "+ datetime.strftime(
        start_time,"%Y-%m-%d %H:%M:%S"))

   
try:
    psql = DatabaseFunctions(host, user, password, port,dbName,schema, config= config) 
    # account_processes_db = common_functions.database_account_process()
except Exception as e:
    print(
        "Could not connect to postgresql in incident score file and error is--->" +
        str(e))
    logger_inc_score.error(
        "Incident score process failed due to postgresql database connectivity issue")
    sys.exit()
else:
    print("Connected successfully!!!")

def read_mongo():
    """ Read from Mongo and Store into DataFrame """
    logger_inc_score.info("Going to read the ticket_data_inter_mongo table")
    df_inc = psql.select_df('ticket_data_inter_mongo')
    if nonciap == 1:
        inc_list = df_inc['incident_id'].to_list()
    else:
        inc_list = df_inc['Incident_id'].to_list()
    logger_inc_score.info("Reading the ticket_data_inter_mongo table is done. The incidents are:\n%s",df_inc['Incident_id'])
    
    logger_inc_score.info("Going to select the tickets from ticket_data_history table which are present in ticket_data_inter_mongo table")
    his_data = psql.select_df('ticket_data_history', 'ticketid', inc_list)
    inter_section_inc = his_data['ticketid'].to_list()
    logger_inc_score.info("Fetching the tickets from ticket_data_history table is done.Tickets are:\n%s",inter_section_inc)
    
    if nonciap == 1:
        df = df_inc[df_inc.incident_id.isin(inter_section_inc)]
    else:   
        df = df_inc[df_inc.Incident_id.isin(inter_section_inc)]
    
    return df

df=pd.DataFrame(columns=['run_id', 'active', 'feed name'])
df = df.append(pd.Series([runid,1, 'incident score'], index=df.columns ), ignore_index=True)
psql.upsert_df(df, 'run_transactions_mongo')

if error_string == '':
##  db data retrieval and text processing start ######
    print("start time for data retrieval and preprocessing is {0}".format(datetime.now()))
    logger_inc_score.debug("incident score is started on "+str(datetime.now()))
    # inter_df = common_functions.read_table_data('ticket_data_inter_mongo',psql)
    inter_df = read_mongo()
    
    if nonciap == 1:
        print('inter_df:',inter_df.shape)       # comment after testing
        inter_df.rename(columns = {'incident_id':'Incident_id','assigned_group':'Assigned_Group',
                                   'app_name':'App_Name','status':'Status','summary':'Summary','inc_text':'Inc_text'},inplace=True)

    logger_inc_score.debug("No of incidents in inter table(feed) in main file: "+str(len(inter_df)))
    logger_inc_score.debug("List of incidents successfully processed from inter table are:\n%s",inter_df['Incident_id'])
    no_of_feed_inc = len(inter_df)
    
    if len(inter_df) == 0:
        print(error_string)
        logger_inc_score.debug("ticket_data_inter_mongo table has no records hence exiting the program.")        
        mes = ""
        common_functions.send_email(sub, mes, 0, LOG_FILENAME, log_capture_string, html,psql,emailSender,emailReceiver)
        transaction(0)
        sys.exit()
        
    
    current_time = datetime.now()
    current_hour = current_time.hour
    current_min = current_time.minute        
        
    if not (len(inter_df) >= volume_threshold or (current_hour in range(0,24,hour_step) and current_min in range(0, min_step, 1))): 
    
        print(error_string)
        logger_inc_score.debug("ticket_data_inter_mongo table has less records than volume threshold set hence exiting the program.")
        sub=""
        mes = ""
        common_functions.send_email(sub, mes, 0, LOG_FILENAME, log_capture_string, html,psql,emailSender,emailReceiver)
        transaction(0)
        sys.exit()       


    if len(inter_df) > 0:  
        inder_df_temp = inter_df.head(max_records)
        inter_df = inder_df_temp
        
        print('data inserting into intermediate tables. Length of data is: ', len(inter_df))
        print('===========================================================')
        print(inter_df.columns)
        logger_inc_score.debug("Inserting the data into intermediate tables -> ticket_data_inter_staging_mongo,ticket_data_staging_mongo")
        logger_inc_score.debug("Tickets inserted into inter tables are:\n%s", inter_df['Incident_id'])
        psql.upsert_df(inter_df, 'ticket_data_inter_staging_mongo')
        psql.upsert_df(inter_df, 'ticket_data_staging_mongo')

        if nonciap == 1:
            temp = inter_df.rename(columns = {'Incident_id':'incident_id'})
            psql.delete_df(temp,'ticket_data_inter_mongo',{'incident_id'})
        else:
            psql.delete_df(inter_df,'ticket_data_inter_mongo',{'Incident_id'})
        logger_inc_score.debug("Data is moved to inter tables hence cleaned it up in ticket_data_inter_mongo table")
    try:
        logger_inc_score.debug("Reading the data from ticket_data_inter_staging_mongo for further process")
        inter_df = common_functions.read_table_data('ticket_data_inter_staging_mongo', psql)
        df_inc = inter_df.copy()
        
        logger_inc_score.debug("Total no of incidents for tag processing : "+ str(len(df_inc)))
        logger_inc_score.debug("List of incidents selected for tag processing:\n%s",df_inc['Incident_id'])
        no_of_feed_inc = len(df_inc)
        if len(df_inc) > 0:
            df_inc['incident_id'] = df_inc['Incident_id']
            del df_inc['Incident_id']

        print(df_inc.shape)
        print(df_inc.columns)
        logger_inc_score.debug("Names of Columns present in inter staging mongo table:%s",df_inc.columns.to_list())
        if nonciap == 1:
        
            sap_tcodes_df = common_functions.read_table_data('sap_tcodes_mongo',psql)
            sap_tcodes = sap_tcodes_df['sap_tcodes'].tolist()
            
            df_inc['matches'] = df_inc['Summary'].apply(lambda x: [i for i in sap_tcodes if i in x])
            df_inc['tcodes_string'] = df_inc['matches'].agg(lambda x: ' '.join(map(str, x)))
                           
        if multi_language==1:
            df_inc['language']=df_inc['Summary'].apply(multilingual.lang_detection)

        else:
            df_inc['language'] = default_lang
        df_inc["Summary"] = df_inc.apply(lambda x:multilingual.process_text(config,x.language, x.Summary),axis=1)

        df_inc["Summary"] = df_inc.apply(lambda x:multilingual.oneliner_for_processing(load_lemma_model,x.language, x.Summary),axis=1)
        print(df_inc.isna().sum())
            
        logger_inc_score.debug("Preprocessing done for incident tags. Preprocessed summary text is:\n%s",df_inc["Summary"])

        if AGfilter ==0:
            df_inc = df_inc.dropna(
            subset=[
                'Summary',
                'Status'])
        else:   
            df_inc = df_inc.dropna(
                subset=[
                    'Assigned_Group',  # commented in CIAP
                    'Summary',
                    'Status'])
            
        print(df_inc.shape)
        
        if nonciap == 1:
            for i in df_inc.index:
                df_inc.at[i,'Summary'] = str(df_inc.at[i,'Summary'])+ ' ' +str(df_inc.at[i,'tcodes_string'])
        
        df_inc['Summary'] = df_inc['Summary'].str.lower()
        

        print(
            "end time for data retrieval and preprocessing is {0}".format(
                datetime.now()))
        logger_inc_score.debug("End time for data retrieval and preprocessing is {0}".format(datetime.now))
        ######  db data retrieval and text processing end ###############

        #### weightage calc with frequency tables for tokens start ############

        df_inc_summary = df_inc.filter(['incident_id', 'Summary'])

        summ_text_train = df_inc_summary['Summary']

        gen_summ = [[w.lower() for w in nltk.word_tokenize(text)]
                    for text in summ_text_train]

        bigram_measures = nltk.collocations.BigramAssocMeasures()

        bigram_finder_inc_summ = nltk.collocations.BigramCollocationFinder.from_documents(gen_summ)

        bigram_freq_inc_summ = bigram_finder_inc_summ.ngram_fd.items()

        bigram_freq_table = pd.DataFrame(
            list(bigram_freq_inc_summ), columns=[
                'bigram', 'freq']).sort_values(
            by='freq', ascending=False)

        bigram_freq_table.head()
        for x in bigram_freq_table.index:
            bigram_freq_table.at[x, 'bigram'] = ' '.join(
                bigram_freq_table.at[x, 'bigram'])

        bigram_tokens = [*bigram_freq_table['bigram']]
        print(len(set(bigram_tokens)))
        bigram_freq_table.sort_values(by='freq', ascending=True)
        bigram_freq_table.reset_index(inplace=True, drop=True)
        logger_inc_score.debug("Generated bigrams for the summary column are:\n%s",bigram_freq_table)

        trigram_measures = nltk.collocations.TrigramAssocMeasures()

        trigram_finder_inc_summ = nltk.collocations.TrigramCollocationFinder.from_documents(
            gen_summ)

        trigram_freq_inc_summ = trigram_finder_inc_summ.ngram_fd.items()

        trigram_freq_table = pd.DataFrame(
            list(trigram_freq_inc_summ), columns=[
                'trigram', 'freq']).sort_values(
            by='freq', ascending=False)

        trigram_freq_table.head()

        for x in trigram_freq_table.index:
            trigram_freq_table.at[x, 'trigram'] = ' '.join(
                trigram_freq_table.at[x, 'trigram'])

        trigram_tokens = [*trigram_freq_table['trigram']]
        print(len(set(trigram_tokens)))
        trigram_freq_table.sort_values(by='freq', ascending=True)
        trigram_freq_table.reset_index(inplace=True, drop=True)
        logger_inc_score.debug("Generated trigrams for the summary column are:\n%s",trigram_freq_table)

        count = 0
        tokens_list = []

        tokens_list = list(itertools.chain.from_iterable(gen_summ))
        count = len(set(tokens_list))
        print(count)

        token_freq_dict = dict(Counter(tokens_list))

        tokens_freq_table = pd.DataFrame(
            list(
                token_freq_dict.items()),
            columns=[
                'tokens',
                'freq']).sort_values(
            by='freq',
            ascending=False)

        print("Printing the contents of tokens_freq dataframe")
        tokens_freq_table.head()
        logger_inc_score.debug("Generated single tokens for the summary column are:\n%s",tokens_freq_table)

        st_col_exists = 'tokens_freq_mongo' in psql.get_table_names()
        print ("'collection tokens_freq_mongo' exists:", st_col_exists) # will print True or False
        # use the database_name.some_collection.drop() method call if True
        if st_col_exists == True:        
            tokens_freq = psql.select_df('tokens_freq_mongo')
        else:
            tokens_freq = pd.DataFrame(columns=['tokens','freq'])
        bg_col_exists = 'bigram_freq_mongo' in psql.get_table_names()
        print ("'collection bigram_freq' exists:", bg_col_exists) # will print True or False
        # use the database_name.some_collection.drop() method call if True
        if bg_col_exists == True:
            bigram_freq = psql.select_df('bigram_freq_mongo')
        else:
            bigram_freq = pd.DataFrame(columns=['bigram','freq'])
        tg_col_exists = 'trigram_freq_mongo' in psql.get_table_names()
        print ("'collection trigram_freq' exists:", tg_col_exists) # will print True or False
        # use the database_name.some_collection.drop() method call if True
        if tg_col_exists == True:
            trigram_freq = psql.select_df('trigram_freq_mongo')
        else:
            trigram_freq = pd.DataFrame(columns=['trigram','freq'])
        

        final_st_freq = pd.merge(tokens_freq, tokens_freq_table, on='tokens', how='outer')
        final_st_freq.dropna(subset=['freq_y'], inplace=True)
        final_st_freq['freq_y'] = final_st_freq['freq_y'].replace(np.NaN, 0.0)
        final_st_freq['freq_x'] = final_st_freq['freq_x'].replace(np.NaN, 0.0)
        final_st_freq['freq_x'] = final_st_freq['freq_x']+ final_st_freq['freq_y']
        del final_st_freq['freq_y']
        final_st_freq['freq_x'] = final_st_freq['freq_x'].astype(int)
        final_st_freq = final_st_freq.rename(columns={"freq_x": "freq"})
        logger_inc_score.debug("Printing the head of contents of single tokens table before merging:\n%s",final_st_freq.head())
        print("Printing the head of contents of single tokens table before merging:",final_st_freq.head())

        st_col_exists = 'tokens_freq_mongo' in psql.get_table_names()
        print ("'collection tokens_freq' exists:", st_col_exists) # will print True or False

        if len(final_st_freq) > 0:
            psql.upsert_df(final_st_freq,'tokens_freq_mongo')

        final_bg_freq = pd.merge(bigram_freq, bigram_freq_table, on='bigram', how='outer')
        final_bg_freq.dropna(subset=['freq_y'], inplace=True)
        final_bg_freq['freq_y'] = final_bg_freq['freq_y'].replace(np.NaN, 0.0)
        final_bg_freq['freq_x'] = final_bg_freq['freq_x'].replace(np.NaN, 0.0)
        final_bg_freq['freq_x'] = final_bg_freq['freq_x']+ final_bg_freq['freq_y']
        del final_bg_freq['freq_y']
        final_bg_freq['freq_x'] = final_bg_freq['freq_x'].astype(int)
        final_bg_freq = final_bg_freq.rename(columns={"freq_x": "freq"})
        logger_inc_score.debug("Printing the head of contents of bigrams table before merging:\n%s",final_bg_freq.head())
        print("Printing the head of contents of bigrams table before merging:",final_bg_freq.head())

        bg_col_exists = 'bigram_freq_mongo' in psql.get_table_names()
        print ("'collection bigram_freq' exists:", bg_col_exists) # will print True or False

        if len(final_bg_freq) > 0:
            psql.upsert_df(final_bg_freq,'bigram_freq_mongo')

        final_tg_freq = pd.merge(trigram_freq, trigram_freq_table, on='trigram', how='outer')
        final_tg_freq.dropna(subset=['freq_y'], inplace=True)
        final_tg_freq['freq_y'] = final_tg_freq['freq_y'].replace(np.NaN, 0.0)
        final_tg_freq['freq_x'] = final_tg_freq['freq_x'].replace(np.NaN, 0.0)
        final_tg_freq['freq_x'] = final_tg_freq['freq_x']+ final_tg_freq['freq_y']
        del final_tg_freq['freq_y']
        final_tg_freq['freq_x'] = final_tg_freq['freq_x'].astype(int)
        final_tg_freq = final_tg_freq.rename(columns={"freq_x": "freq"})
        logger_inc_score.debug("Printing the head of contents of trigrams table before merging:\n%s",final_bg_freq.head())
        print("Printing the head of contents of trigrams table before merging:",final_tg_freq.head())
   
        ##dropping existing collection
        ## check if a collection exists

        tg_col_exists = 'trigram_freq_mongo' in psql.get_table_names()
        print ("'collection trigram_freq' exists:", tg_col_exists) 

        #insert final records to the collection
        if len(final_tg_freq) > 0:
            psql.upsert_df(final_tg_freq,'trigram_freq_mongo')


        ##tokens, bigrams and trigrams for inc data start #######

        df_inc['bigram_token'] = df_inc['Summary'].apply(
            lambda x: [
                ' '.join(
                    (a, b)) for a, b in nltk.bigrams(
                    nltk.word_tokenize(x))])
        df_inc['trigram_token'] = df_inc['Summary'].apply(
            lambda x: [
                ' '.join(
                    (a, b, c)) for a, b, c in nltk.trigrams(
                    nltk.word_tokenize(x))])
        df_inc['single_tokens'] = df_inc['Summary'].apply(
            lambda x: nltk.word_tokenize(x))


#        ##### calculating inc score for inc data start ##
#
        df_inc['st_tags'] = ''
        df_inc['bigram_tags'] = ''
        df_inc['trigram_tags'] = ''

        for i in df_inc.index:
            print(i)
            tokens_freq = 0
            count_tokens_freq = 0
            tokens_avg = 0
            bigrams_freq = 0
            count_bigrams_freq = 0
            bigrams_avg = 0
            trigrams_freq = 0
            count_trigrams_freq = 0
            trigrams_avg = 0

            tokens_list = df_inc.at[i, 'single_tokens']
            bigrams_list = df_inc.at[i, 'bigram_token']
            trigrams_list = df_inc.at[i, 'trigram_token']
#
#            ##################for tokens#########################
#
            st_dict = dict()
            for j in tokens_list:
           
                st_token_score = 0
                count_tokens_freq = count_tokens_freq + 1
              
                st_token_score = final_st_freq.loc[final_st_freq['tokens'] == j]['freq'].tolist()[
                    0]
                tokens_freq = tokens_freq + st_token_score
                st_dict[j] = st_token_score
            if not count_tokens_freq == 0:
                tokens_avg = tokens_freq / count_tokens_freq
            else:
                tokens_avg = 0
         
#
#            #####################for bigram#########################
#
            bi_dict = dict()
            for j in bigrams_list:
               
                bigram_token_score = 0
                count_bigrams_freq = count_bigrams_freq + 1
               
                bigram_token_score = final_bg_freq.loc[final_bg_freq['bigram'] == j]['freq'].tolist()[0]
                bigrams_freq = bigrams_freq + bigram_token_score
                bi_dict[j] = bigram_token_score
            if not count_bigrams_freq == 0:
                bigrams_avg = bigrams_freq / count_bigrams_freq
            else:
                bigrams_avg = 0
            
            #####################for trigram#########################

            tri_dict = dict()
            for j in trigrams_list:
              
                trigram_token_score = 0
                count_trigrams_freq = count_trigrams_freq + 1
                
                trigram_token_score = final_tg_freq.loc[final_tg_freq['trigram'] == j]['freq'].tolist()[0]
                trigrams_freq = trigrams_freq + trigram_token_score
                tri_dict[j] = trigram_token_score
            if not count_trigrams_freq == 0:
                trigrams_avg = trigrams_freq / count_trigrams_freq
            else:
                trigrams_avg = 0
            

            sorted_st_tags = {
                k: v for k,
                v in sorted(
                    st_dict.items(),
                    key=lambda item: item[1],
                    reverse=True)}
            sorted_bigram_tags = {
                k: v for k,
                v in sorted(
                    bi_dict.items(),
                    key=lambda item: item[1],
                    reverse=True)}
            sorted_trigram_tags = {
                k: v for k,
                v in sorted(
                    tri_dict.items(),
                    key=lambda item: item[1],
                    reverse=True)}

            df_inc.at[i, 'st_tags'] = sorted_st_tags.keys()
            df_inc.at[i, 'bigram_tags'] = sorted_bigram_tags.keys()
            df_inc.at[i, 'trigram_tags'] = sorted_trigram_tags.keys()
            df_inc.at[i, 'inc_score'] = round(
                (tokens_avg + bigrams_avg + trigrams_avg) / 3, 2)

        logger_inc_score.debug("Incident Scores done for: "+str(len(df_inc))+"Incidents")
        logger_inc_score.debug("List of incidents and their scores are:\n%s",df_inc)
        df_inc_score = df_inc.copy()
        

        #######calculating inc score for inc data end ###############
        df_inc['st_tags'] = df_inc['st_tags'].apply(
            lambda x: ','.join([str(elem) for elem in x]))
        df_inc['bigram_tags'] = df_inc['bigram_tags'].apply(
            lambda x: ','.join([str(elem) for elem in x]))
        df_inc['trigram_tags'] = df_inc['trigram_tags'].apply(
            lambda x: ','.join([str(elem) for elem in x]))

        df_inc['TicketID'] = df_inc['incident_id']

        df_inc['INCSingleTags'] = df_inc['st_tags']
        df_inc['INCBigramTags'] = df_inc['bigram_tags']
        df_inc['INCTrigramTags'] = df_inc['trigram_tags']

        df_inc = df_inc.filter(
            ['TicketID', 'INCSingleTags', 'INCBigramTags', 'INCTrigramTags'])

        
        df_dummy = df_inc.copy()
        df_dummy.columns = df_dummy.columns.map(str.lower)
        print(df_inc.head())

        logger_inc_score.debug("Inserting the generated tags to incident_tags table")
   
        psql.upsert_df(df_dummy,'incident_tags')
        logger_inc_score.debug("Sorted and Inserted tags for incidents to incident_tags table. Lenght of table is: "+str(len(df_inc))+"Contents of table are:\n%s",df_dummy)
        no_of_inc_tags = len(df_inc)
        logger_inc_score.debug("incident score is done on "+str(datetime.now()))

           
        print(
            "start time for data preprocessing is {0}".format(
                datetime.now()))
        
        if nonciap ==1:
            sap_tcodes_df = psql.select_df('sap_tcodes_mongo')
            sap_tcodes = sap_tcodes_df['sap_tcodes'].tolist()
            print(sap_tcodes)
        if len(inter_df) > 0:

            if nonciap == 1:
                inter_df['matches'] = inter_df['Summary'].apply(lambda x: [i for i in sap_tcodes if i in x])
                inter_df['tcodes_string'] = inter_df['matches'].agg(lambda x: ' '.join(map(str, x)))
                
            if multi_language==1:                  
                inter_df['language'] = inter_df['Summary'].apply(multilingual.lang_detection)
            else:
                inter_df['language'] = default_lang
                                   
            inter_df["Inc_proc_text"] = inter_df.apply(lambda x:multilingual.process_text(config, x.language, x.Summary),axis=1)                        
            inter_df["Inc_proc_text"] = inter_df.apply(lambda x:multilingual.oneliner_for_processing(load_lemma_model, x.language, x.Inc_proc_text),axis=1)
             
            if AGfilter ==0:
                inter_df = inter_df.dropna(
                subset=[
                    'Inc_proc_text',
                    'Status'])
            else:
                inter_df = inter_df.dropna(
                subset=[
                    'Assigned_Group',  #'App_Name',   # commented in CIAP
                    'Inc_proc_text',
                    'Status'])
            print(inter_df.shape)
            if nonciap == 1:
                
                for i in inter_df.index:
                    inter_df.at[i,'Inc_proc_text'] = inter_df.at[i,'Inc_proc_text']+ ' ' +inter_df.at[i,'tcodes_string']
            inter_df['Inc_proc_text'] = inter_df['Inc_proc_text'].str.lower()
            
        print(
            "end time for data preprocessing is {0}".format(
                datetime.now()))

        if len(inter_df) > 0:
            inter_df = inter_df.filter(
               ['Incident_id', 'Inc_text', 'App_Name', 'Assigned_Group', 'Status','Summary','Inc_proc_text'])
            psql.upsert_df(inter_df,'ticket_data_inter_staging_mongo')

            print('++++++++++++ printing inter table status ++++++++++++++++++++++')
            
            print(inter_df['Status'],'closed status ', closedStatusList)
            closed_df = inter_df[inter_df.Status.isin(closedStatusList)]

            closed_df = closed_df.filter(
               ['Incident_id', 'Inc_text', 'App_Name', 'Assigned_Group', 'Status', 'Summary', 'Inc_proc_text'])
            psql.upsert_df(closed_df, 'ticket_data_history_mongo')

            if nonciap == 1:
                print('========== closed_df length ==================: ',len(closed_df))
                psql.delete_df(closed_df, 'ticket_data_inter_staging_mongo', {'Incident_id'})

    except Exception as e:
        logger_inc_score.debug("Exception occured in incident score tags processing and error is---> "+ str(e))
        error_string = str(e)
        logger_inc_score.debug("We have encountered an exception so,incidents processed for finding incident tags : 0 ")
        print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
        
        exception_type, exception_object, exception_traceback = sys.exc_info()
        line_number = exception_traceback.tb_lineno
        logger_inc_score.error("exception_type for Incident score: "+ str(exception_type))
        logger_inc_score.error("line_number for Incident score : "+ str(line_number))
        
        mes = 'PFA of log file'
        common_functions.send_email(sub, mes, 1, LOG_FILENAME, log_capture_string, html,psql,emailSender,emailReceiver)
        logger_inc_score.debug("incident score run ended with exception at "+ str(datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")))
        transaction(1)
        sys.exit()
    else:
        logger_inc_score.debug("incident score run ended at "+ str(datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")))
        mes = ''
        common_functions.send_email(sub, mes, 0, LOG_FILENAME, log_capture_string, html,psql,emailSender,emailReceiver)
        transaction(0)
print("end time for incident score preprocessing is {0}".format(datetime.now()))

# =========================================================================================================================
# File Name     : relevancy_main_common.py
# -------------------------------------------------------------------------------------------------------------------------
# Purpose       : Purpose of this script is to order top 5 similar incidents & Ko's based on relevancy & usage persentage.
# Author        : Sai, Harinadh Reddy
# Co-Author     : 
# Creation Date : 11-NOV-2022
# Usage         : 'python ' + commonsFolderPath + 'relevancy_main_common.py --accountName ' + accountName
# History       :
# -------------------------------------------------------------------------------------------------------------------------
# Date          | Author                       | Co-Author                    | Remark
# 11-Nov-2022   | Sai, Harinadh Reddy          |                              | Initial Release
# =========================================================================================================================
###########################################################################################################################
# Import required Module / Packages
###########################################################################################################################
import common_functions
import sys,getopt
from datetime import datetime
import pandas as pd
import os
import numpy as np
import threading
import time
from DatabaseFunctions import DatabaseFunctions
import requests
import json

error_string = ''
runid = 0
logger_rel_main = ''
similar_ko_df = pd.DataFrame()
ko_score_df = pd.DataFrame()
final_inc_lv1ko = pd.DataFrame()
similar_inc_ko_df = pd.DataFrame()
ko_similarity = pd.DataFrame()
score_incident = pd.DataFrame()
run_details = pd.DataFrame()

inc_score_error = ''
ko_processing_error = ''
inc_ko_sim_error = ''
inc_ko_link_error = ''

no_of_feed_inc = 0
no_of_inc_ko_prop = 0
no_of_no_change_inc = 0
no_of_new_inc = 0
no_of_updated_inc = 0

start_time=datetime.now()
runid = datetime.now().strftime('%Y%m%d%H%M%S') 

# Arguments
argumentList = sys.argv[1:]
args_list = common_functions.get_common_args(argumentList)

accountName = args_list[0]

try:
    config = common_functions.get_config(accountName)  
    dbDetail = common_functions.get_dbdetail(config)
    dbName = dbDetail['dbName']
    host = dbDetail['host']
    user = dbDetail['user']
    password = dbDetail['password']
    port = dbDetail['port']
    schema = dbDetail['schema']    
    accountLogPath = config.get('PathsSection', 'path.log')

    ###################### fetching email details #############################
    emailSender = config.get('EmailSection', 'email.sender')
    emailReceiver = config.get('EmailSection', 'email.receiver')

    ###################### fetching status details ############################
    closedStatusList = config.get('StatusSection', 'status.closed')

    ### log file creating ###
    LOG_DIR = os.path.join(accountLogPath, accountName, "main_logs")
    if not os.path.exists(LOG_DIR):
        os.makedirs(LOG_DIR)
    LOG_FILENAME = os.path.join(LOG_DIR, f"{accountName}_Main_ikon2_logger_{runid}.log")

    logger_rel_main, log_capture_string = common_functions.getLogger(LOG_FILENAME,accountName)

    port=int(port)
    if closedStatusList != '':
        closedStatusList = closedStatusList.split(',')
        
    ## generic section 
    ko_version_flag = int(config.get('GenericSection', 'ko.version.feature'))                 
    nonciap = int(config.get('GenericSection', 'account.type.nonciap'))   
    batch_size = int(config.get('GenericSection', 'max.train.batch'))
    processGenericKo = int(config.get('GenericSection', 'sap.flag'))
    includeLevel2 = int(config.get('FileSection', 'file.level2'))

    ## Data lake section 
    send_proposal = int(config.get('DatalakeSection', 'send.proposal'))
    send_updated_proposal = int(config.get('DatalakeSection', 'send.updated.proposal'))
    rank = int(config.get('RankSection', 'ko.rank'))
    
    ## incident pay load config details 
    incident_proposal = int(config.get('IncidentPayloadSection', 'Incident.proposal'))
    incident_url = config.get('IncidentPayloadSection', 'Incident.url')
    tenant_name = config.get('IncidentPayloadSection', 'tenant_name')
    headers = {"Content-Type":"application/json", "tenantId": str(tenant_name)}
    incident_genai = int(config.get('IncidentPayloadSection', 'genai.proposal'))
    gen_url = config.get('IncidentPayloadSection', 'genAI.url')

    ## Ko ratings
    final_ko_flag = int(config.get('RelevSection', 'final_ko.flag'))
    relev_perc = int(config.get('RelevSection', 'relev.perc'))
    usage_perc = int(config.get('RelevSection', 'usage.perc'))
    rating_perc = int(config.get('RelevSection', 'rating.perc'))

    if processGenericKo == 1: 
        ###################### fetching generic database details #############################
        genericDbName = config.get('DatabaseSection', 'generic_database.dbname')
        genericHost = config.get('DatabaseSection', 'generic_database.host')
        genericUser = config.get('DatabaseSection', 'generic_database.user')
        genericPassword = config.get('DatabaseSection', 'generic_database.password')
        genericPort = config.get('DatabaseSection', 'generic_database.port')
        genericSchema = config.get('DatabaseSection', 'generic_database.schema')
    
except Exception as e:
    print ("Error occured while reading the config or setting up logger in relevancy main: " + str(e))
    sys.exit() 
  
feed_name = "Relevancy Main Process"
sub = "Relevancy Main Process"
html = """<br>Summary of Relevancy Main Process run for incident feed(""" + str(runid) + """)<br>
    start time = """ + str(start_time) + """<br>
    end time = """ + str(datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")) + """<br>
    No.of incidents for which kos are proposed = """ + str(no_of_inc_ko_prop) + """
    """

data = """{"inc_in_feed": """ + str(no_of_feed_inc) + """,
       "no_of_inc_ko_prop": """ + str(no_of_inc_ko_prop) +"""}"""

logger_rel_main.debug(
        "incident ko similarity file run started at "+datetime.strftime(
                start_time, "%Y-%m-%d %H:%M:%S"))

try:
    psql = DatabaseFunctions(host, user, password, port,dbName,schema, config= config)
except Exception as e:
    print("Could not connect to postgresql in main file and error is--->" + str(e))
    logger_rel_main.error(
        "relevancy main file process failed due to postgresql database connectivity issue\n")
    sys.exit()
else:
    print("Connected successfully!!!")

try:
    if processGenericKo == 1:
        generic_psql = DatabaseFunctions(genericHost, genericUser, genericPassword, genericPort, genericDbName, genericSchema)
    else:
        pass 
except Exception as e:
    print("Could not connect to Postgresql in main file and error is--->" + str(e))
    logger_rel_main.error(
        "relevancy main file process failed due to postgresql connectivity issue\n")
    sys.exit()
else:
    print("Connected successfully!!!")

start_time = datetime.now()
logger_rel_main.debug("relevancy run started at "+ datetime.strftime(start_time,"%Y-%m-%d %H:%M:%S"))

def update_to_mysql(tableName, df_sorted):
    df_sorted.rename(columns = {'incident_id':'ticketid', 'ko_rel':'relevperc', 'ko_usage':'usageperc'}, inplace=True)   
    

    df_sorted = df_sorted.filter(['ticketid', 'relevperc', 'usageperc'])
        
    df_sorted.columns = df_sorted.columns.map(str.lower)
    psql.update_df(df_sorted, tableName, {'ticketid'})

def ko_processed():
    global similar_ko_df
    global ko_score_df
    global ko_processing_error
    global logger_rel_main

    try:      
        print('ko_score')
        ko_score_df = psql.select_df('ko_info_mongo')
        logger_rel_main.debug("Printing the ko_info_mongo details during ko processing:\n%s",ko_score_df)
        if includeLevel2==1:
            generic_ko_score_df = generic_psql.select_df('ko_info_mongo')
            print(generic_ko_score_df.shape)
            print('gene ko_score ended')
            
            ko_score_df = pd.concat([ko_score_df,generic_ko_score_df])
        print(ko_score_df.shape)
        if len(ko_score_df) == 0:
            ko_score_df = pd.DataFrame(
                columns=[
                    'ko_id',
                    'ko_single_tokens',
                    'ko_bigram_token',
                    'ko_trigram_token',
                    'ko_score'])
        similar_ko_df = pd.DataFrame()
        if similar_ko_df.empty:
            similar_ko_df = pd.DataFrame(
                columns=[
                    'ko_id',
                    'similar_ko',
                    'token_score',
                    'bigram_score',
                    'trigram_score',
                    'ko_similarity_score'])
        
    except Exception as e:
        ko_processing_error = str(e)
        logger_rel_main.debug(
            "An error occured while fetching ko's from database--> "+str(e))


def inc_processed():
    global final_inc_lv1ko
    global inc_ko_link_error
    global logger_rel_main

    try:
        print("inside inc_processed")

        test = psql.select_df('ticket_data_inter_staging_mongo')
        logger_rel_main.debug("Fetching details of ticket_data_inter_staging_mongo for level1:\n%s",test)

        print("****************")
        open_inc_list = []
        if not test.empty:
            status_ignore = closedStatusList
            test = test[~test.Status.isin(status_ignore)]
            open_inc_list = test['Incident_id'].to_list()
            print("********************")
            print(open_inc_list)
        final_inc_lv1ko = psql.select_df('inc_similarity_scores_ko_mongo','incident_id',open_inc_list)
        logger_rel_main.debug("Filtering only open tickets in staging mongo and checking for them in inc_similarity_scores_ko_mongo:\n%s",final_inc_lv1ko)

        print("*****************")
        print(final_inc_lv1ko.head())
        if final_inc_lv1ko.empty:
            final_inc_lv1ko = pd.DataFrame(
                columns=[
                    'incident_id',
                    'most_similar_incident',
                    'tokens_score',
                    'bigrams_score',
                    'trigrams_score',
                    'inc_similarity_score',
                    'lv1_ko_id'])
    except Exception as e:
        inc_ko_link_error = str(e)
        logger_rel_main.debug("An error occured while fetching level1 from database--> "+ str(e))


def inc_ko_similarity_processed():
    global similar_inc_ko_df
    global inc_ko_sim_error
    global logger_rel_main

    try:
        print("inside inc_ko_similarity_processed")
        test = psql.select_df('ticket_data_inter_staging_mongo')
        logger_rel_main.debug("Fetching details of ticket_data_inter_staging_mongo for level3:\n%s",test)
        open_inc_list = []
        if not test.empty:
            status_ignore = closedStatusList
            test = test[~test.Status.isin(status_ignore)]
            open_inc_list = test['Incident_id'].to_list()
            print(open_inc_list)
        similar_inc_ko_df = psql.select_df('inc_ko_similarity_mongo','inc_id',open_inc_list)
        logger_rel_main.debug("Filtering only open tickets in staging mongo and checking for them in inc_ko_similarity_mongo:\n%s",similar_inc_ko_df)
        print("###############")
        print(similar_inc_ko_df.head())
        if similar_inc_ko_df.empty:
            similar_inc_ko_df = pd.DataFrame(
                columns=[
                    'inc_id',
                    'similar_ko',
                    'token_score',
                    'bigram_score',
                    'trigram_score',
                    'inc_ko_similarity_score'])
        print("this is inside function {0}".format(similar_inc_ko_df))
    except Exception as e:
        inc_ko_sim_error = str(e)
        logger_rel_main.debug(
            "An error occured while fetching level3 from database--> "+str(e))

def transaction(iserror):
    status = ''
    if iserror == 0:
        status = "success"
    else:
        status = "failed"

    df=pd.DataFrame(columns=['run_id', 'active', 'start_time', 'end_time', 'inc_in_feed','new_incidents', 'updated_incidents', 'proposed_inc_count', 'status'])
    df = df.append(pd.Series([runid,0, datetime.strftime(start_time, "%Y-%m-%d %H:%M:%S"),datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S"), no_of_feed_inc,no_of_new_inc,no_of_updated_inc,no_of_inc_ko_prop,status], index=df.columns ), ignore_index=True)
    psql.upsert_df(df, 'run_transactions_mongo')
      
try:
    logger_rel_main.debug("Starting level 1 thread")
    inc_processed()
    logger_rel_main.debug("Starting level 2 thread")
    ko_processed()
    logger_rel_main.debug("Starting level 3 thread")
    inc_ko_similarity_processed()

    if not inc_ko_link_error == '':
        print("there is an exception in inc_ko_link file ")
        logger_rel_main.debug("there is an exception in inc_ko_link file.")
        sub = 'Incident Relevancy Process'
        mes = 'PFA of log file'
        common_functions.send_email(sub, mes, 1, LOG_FILENAME, log_capture_string, html,psql,emailSender,emailReceiver)
        transaction(1)
        sys.exit()

    if not inc_ko_sim_error == '':
        print("there is an exception in inc_ko_similarity file ")
        logger_rel_main.debug("there is an exception in inc_ko_similarity file.")
        sub = 'Incident Relevancy Process'
        mes = 'PFA of log file'
        common_functions.send_email(sub, mes, 1, LOG_FILENAME, log_capture_string, html,psql,emailSender,emailReceiver)
        transaction(1)
        sys.exit()

    if not ko_processing_error == '':
        print("there is an exception in ko_processing file ")
        logger_rel_main.debug("there is an exception in ko_processing file.")
        sub = 'Incident Relevancy Process'
        mes = 'PFA of log file'
        common_functions.send_email(sub, mes, 1, LOG_FILENAME, log_capture_string, html,psql,emailSender,emailReceiver)
        transaction(1)
        sys.exit()

    print("this is similar_ko_df {0}".format(similar_ko_df))
    print("this is final_inc_lv1ko {0}".format(final_inc_lv1ko))
    print("this is similar_inc_ko_df {0}".format(similar_inc_ko_df))
    print("this is ko_score_df {0}".format(ko_score_df))

    # both threads completely executed
    print("Execution is Done!")
    logger_rel_main.debug("Individual threads execution completed")

    final_inc_lv1ko['lv1_ko'] = final_inc_lv1ko['lv1_ko_id'] + \
        '_' + final_inc_lv1ko['inc_similarity_score'].astype(str)
    similar_ko_df['lv2_ko'] = similar_ko_df['similar_ko'] + \
        '_' + similar_ko_df['ko_similarity_score'].astype(str)
    similar_inc_ko_df['lv3_ko'] = similar_inc_ko_df['similar_ko'] + \
        '_' + similar_inc_ko_df['inc_ko_similarity_score'].astype(str)

    print(final_inc_lv1ko.head())
    print(similar_ko_df.head())
    print(similar_inc_ko_df.head())

    ## after reading level1 and 3
    similar_inc_ko_df['incident_id'] = similar_inc_ko_df['inc_id']
    similar_inc_ko_df = similar_inc_ko_df.filter(['incident_id', 'lv3_ko'])
    level2_ko = final_inc_lv1ko.copy()
    level2_ko['ko_id'] = level2_ko['lv1_ko_id']
    level2_ko = level2_ko.filter(['incident_id', 'ko_id', 'lv1_ko'])
    similar_ko_df = similar_ko_df.filter(['ko_id', 'lv2_ko'])
    ko_score_df['final_kos'] = ko_score_df['ko_id']
    ko_score_df = ko_score_df.filter(['final_kos', 'ko_score'])
    level2_ko.replace(np.nan, '', regex=True, inplace=True)
    similar_ko_df = similar_ko_df.groupby(
        ['ko_id'])['lv2_ko'].apply(
        ','.join).reset_index()
    similar_inc_ko_df = similar_inc_ko_df.groupby(
        ['incident_id'])['lv3_ko'].apply(
        ','.join).reset_index()

    level2_ko = pd.merge(level2_ko, similar_ko_df, how='left', on='ko_id')

    level2_ko.replace(np.nan, '', regex=True, inplace=True)

    level2_ko = level2_ko.groupby(['incident_id'], as_index=False).agg(
        {'lv1_ko': ','.join, 'lv2_ko': ','.join})

    df_lv1_lv2_lv3 = pd.merge(
        level2_ko,
        similar_inc_ko_df,
        how='outer',
        on='incident_id')

    df_lv1_lv2_lv3.replace(np.nan, '', regex=True, inplace=True)
 
    df_lv1_lv2_lv3['lv1_ko'] = df_lv1_lv2_lv3['lv1_ko'].apply(
        lambda x: set(x.split(',')))
    df_lv1_lv2_lv3['lv2_ko'] = df_lv1_lv2_lv3['lv2_ko'].apply(
        lambda x: set(x.split(',')))
    df_lv1_lv2_lv3['lv3_ko'] = df_lv1_lv2_lv3['lv3_ko'].apply(
        lambda x: set(x.split(',')))


    df_lv1_lv2_lv3['final_kos'] = ''
    for i in df_lv1_lv2_lv3.index:
        if includeLevel2 == 0:
            df_lv1_lv2_lv3.at[i, 'final_kos'] =  (df_lv1_lv2_lv3.at[i,'lv1_ko']).union(df_lv1_lv2_lv3.at[i,'lv3_ko'])
        else:
            df_lv1_lv2_lv3.at[i, 'final_kos'] = (
                df_lv1_lv2_lv3.at[i, 'lv1_ko']).union(df_lv1_lv2_lv3.at[i,'lv2_ko']).union(df_lv1_lv2_lv3.at[i, 'lv3_ko'])


    df_lv1_lv2_lv3 = df_lv1_lv2_lv3.filter(['incident_id', 'final_kos'])

    df_lv1_lv2_lv3['final_kos'] = df_lv1_lv2_lv3['final_kos'].apply(
        lambda x: ','.join(x))
    logger_rel_main.debug("Printing the final incident's and ko proposals merged in three levels:\n%s",df_lv1_lv2_lv3)
    print(df_lv1_lv2_lv3.shape)
    print(df_lv1_lv2_lv3.head())

    if len(df_lv1_lv2_lv3) == 0:
        print('len is zero')
        #truncating inter table ####################################3
        logger_rel_main.debug("Reading the contents of ticket_data_inter_staging_mongo table")
        inter_df = common_functions.read_table_data('ticket_data_inter_staging_mongo',psql)
        logger_rel_main.debug("The incident details of ticket_data_inter_Staging_mongo are:\n%s",inter_df)
        if len(inter_df) > 0:
           inter_df = inter_df.filter(
               ['Incident_id', 'Inc_text', 'App_Name', 'Assigned_Group', 'Status', 'Summary', 'Inc_proc_text'])
        ################### Pushing incidents pay genAI ###########################

        account_features = psql.select_df('account_features')
        logger_rel_main.debug("Printing the data of account_features table:\n%s",account_features)
        
        print('account_features: ', account_features)
        genai_flag = list(account_features['koextrlinkenbled'])
        genai_flag = int(genai_flag[0])
        
        if genai_flag == 1:
            logger_rel_main.debug("started incident proposal process using GENAI")

            inter_stading_list = inter_df['Incident_id'].to_list()
            gen_inc = inter_stading_list
            print('incidnets pay load: ', gen_inc)
            gen_inc = json.dumps(gen_inc, indent = 4)
            response = requests.post(url = gen_url, headers = headers, data = gen_inc)
            logger_rel_main.debug("Status Code genai: " + str(response.status_code))
            if response.status_code == 200 or response.status_code == 201:
                # df_relevancy_usage['status'] = 'Successful'
                logger_rel_main.debug("genAI payload is: " + str(gen_inc))
            else:
                logger_rel_main.debug("genAI payload is: " + str(gen_inc))
                # df_relevancy_usage['status'] = 'Failed'



            # update closed old inc in history table
            logger_rel_main.debug("Updating the incidents from ticket_data_inter_staging_mongo into ticket_data_history_mongo and deleting it from inter staging mongo ")
            logger_rel_main.debug("The incident details are:\n%s",inter_df)
            psql.upsert_df(inter_df, 'ticket_data_history_mongo')
            psql.delete_df(inter_df, 'ticket_data_inter_staging_mongo', {'Incident_id'})

        logger_rel_main.debug(
            "exiting the program because no record is present in levels-1,2,3 and Ticket_data_inter table is truncated")
        sub = "Incident Relevancy Process"                    
        mes = ''
        common_functions.send_email(sub, mes, 0, LOG_FILENAME, log_capture_string, html,psql,emailSender,emailReceiver)
        transaction(0)
        sys.exit()

    final_lv1_lv2_lv3 = common_functions.explode(
        df_lv1_lv2_lv3.assign(
            final_kos=df_lv1_lv2_lv3.final_kos.str.split(',')),
        'final_kos')

    final_lv1_lv2_lv3[['final_kos', 'ko_sim_score']
                      ] = final_lv1_lv2_lv3.final_kos.str.split('_', expand=True)
    final_lv1_lv2_lv3['ko_sim_score']=final_lv1_lv2_lv3['ko_sim_score'].replace('NaN',np.NaN)
    final_lv1_lv2_lv3.dropna(inplace=True)
    final_lv1_lv2_lv3['ko_sim_score'] = final_lv1_lv2_lv3['ko_sim_score'].apply(
        lambda x: round(float(x) * 100))

    final_lv1_lv2_lv3 = final_lv1_lv2_lv3[final_lv1_lv2_lv3['ko_sim_score'] > 0]
    print('merging started')
    final_lv1_lv2_lv3_copy = pd.merge(
        final_lv1_lv2_lv3, ko_score_df, on='final_kos', how='left')

    final_lv1_lv2_lv3_copy.head(15)

    final_lv1_lv2_lv3_copy = final_lv1_lv2_lv3_copy.sort_values(
        ['incident_id', 'ko_sim_score', 'ko_score'], ascending=False)

    final_lv1_lv2_lv3_copy.drop_duplicates(
        subset=[
            'incident_id',
            'final_kos'],
        keep='first',
        inplace=True)

    final_lv1_lv2_lv3_copy = final_lv1_lv2_lv3_copy.groupby(
        'incident_id').head(10)

    final_lv1_lv2_lv3_copy.head(10)


    final_lv1_lv2_lv3_copy.head()
    logger_rel_main.debug("Fetching all the data by merging three levels and processing by removing na values and filtering required columns:\n%s",final_lv1_lv2_lv3_copy)

########################## Usage Calculation starts ######################
    df_rel = final_lv1_lv2_lv3_copy.copy()
    df_inc_ko = psql.select_df('incident_ko_link_mongo')
    logger_rel_main.debug("Details of incident_ko_link_mongo table:\n%s",df_inc_ko)

    # convert entire collection to Pandas dataframe
    if df_inc_ko.empty:

        if nonciap == 1:
            df_inc_ko = pd.DataFrame(columns=['incident_id', 'ko_id', 'link_date', 'user_id', 'arch_flag'])  ## for nonciap user_id                 
        else:
            df_inc_ko = pd.DataFrame(columns=['incident_id', 'ko_id', 'link_date', 'User_Id', 'arch_flag'])

    df_inc_ko.dropna(subset=['incident_id','ko_id'],inplace=True)
    #We get how many incidents are linked to that KO
    df_inc_ko['linked_count'] = df_inc_ko.groupby(['ko_id'])['ko_id'].transform('count')    
    df_inc_ko['final_kos'] = df_inc_ko['ko_id']

    if nonciap == 1: 
        df_inc_ko.drop(['ko_id', 'incident_id', 'user_id', 'arch_flag', 'link_date'], inplace=True, axis=1) ## for nonciap user_id
    else:
        df_inc_ko.drop(['ko_id', 'incident_id', 'User_Id', 'arch_flag', 'link_date'], inplace=True, axis=1) ## for nonciap user_id

    df_inc_ko.drop_duplicates(['final_kos'], inplace=True, keep='last')
    df_inc_ko = df_inc_ko.reset_index(drop=True)

    df_rel = df_rel.groupby('incident_id').head(10)

    # df_inc_ko.head()
    df_rel = pd.merge(df_rel, df_inc_ko, on='final_kos', how='left')
    df_rel['linked_count'] = df_rel['linked_count'].replace(np.NaN, 0)

    df_temp = df_rel.copy()
    df_temp.drop(['ko_score'], inplace=True, axis=1)
    print(df_temp.head())
    df_temp["linked_count"] = pd.to_numeric(
        df_temp.linked_count, errors='coerce')

    df_temp = df_temp.fillna(0)
    df_temp['usage'] = ''

    for i in df_temp.index:
        try:
            if df_temp.at[i, 'linked_count'] > 0:
                df_temp.at[i, 'usage'] = int(round(((df_temp.at[i, 'linked_count']) / (df_temp.groupby(
                    'incident_id').get_group(df_temp.at[i, 'incident_id'])['linked_count'].sum())) * 100, 0))
            else:
                df_temp.at[i, 'usage'] = 0
        except Exception as e:
            logger_rel_main.debug("error in for loop "+ str(e))



    if ko_version_flag == 1:
        
        df_ko_version = psql.select_df('ko_detail_history_mongo', 'Ko_id', list(df_temp['final_kos']))
        if 'ko_version' in df_ko_version.columns:
            df_ko_version = df_ko_version[['Ko_id', 'ko_version']]
            df_ko_version['ko_version'] = df_ko_version['ko_version'].replace('', '1.0')
            df_ko_version = df_ko_version.fillna('1.0')
            df_ko_version.set_index('Ko_id',inplace=True)
            ko_version_dict = df_ko_version.to_dict()['ko_version']
        else:
            df_ko_version['ko_version'] = '1.0'
            ko_version_dict = df_ko_version.to_dict()['ko_version']





    ############################  Adding updated usage calculation    ####################################  

    if final_ko_flag == 1:
        print(df_temp.head())
        df_relevancy_usage = df_temp.copy() #pd.merge(df_relev, df_temp, on=['incident_id','final_kos'], how='left')
        df_relevancy_usage = df_relevancy_usage.drop_duplicates(subset = ['incident_id', 'final_kos'],keep = 'first').reset_index(drop = True)
    
        if 'ko_feedback' in psql.get_table_names():
            ko_feedback = psql.select_df('ko_feedback', 'koid', list(set(df_relevancy_usage['final_kos'].to_list())))
            ko_feedback = ko_feedback[['koserialno', 'koid']]
            ko_feedback['koserialno'] = ko_feedback['koserialno'].astype(str)
        else:
            ko_feedback = pd.DataFrame(
                columns=[
                    'feedback_id',
                    'koserialno',
                    'koid',
                    'userid',
                    'comments',
                    'created_by',
                    'createddate',
                    'modified_by'
                    'modifieddate'])
            ko_feedback=ko_feedback[['koserialno','koid']]
        if 'ko_ratings' in psql.get_table_names():
            ko_ratings = psql.select_df('ko_ratings', 'koserialno', list(set(ko_feedback['koserialno'].to_list())))
            ko_ratings = ko_ratings[['koserialno', 'rating']]
            ko_ratings['koserialno'] = ko_ratings['koserialno'].astype(str)
        else:
            ko_ratings = pd.DataFrame(
                columns=[
                    'id',
                    'feedback_id',
                    'userid',
                    'koserialno',
                    'qst_id',
                    'rating',
                    'created_by',
                    'createddate',
                    'modified_by'
                    'modifieddate'])
            ko_ratings=ko_ratings[['koserialno','rating']]
        koid_rank = pd.merge(ko_ratings, ko_feedback, on ='koserialno', how='left')
        koid_rank['rating'] = koid_rank['rating'].astype(float).fillna(0)
        koid_rank['final_kos'] = koid_rank['koid']
        koid_rank = koid_rank.groupby('final_kos')['rating'].mean() 
            

        if len(koid_rank) > 0:
        
            print('df_relevancy_usage: ', df_relevancy_usage.columns)
            # sys.exit()
            df_relevancy_usage = pd.merge(df_relevancy_usage, koid_rank, on ='final_kos', how='left')
            df_relevancy_usage['rating'] = df_relevancy_usage['rating'].fillna(0)
            
        else:
            df_relevancy_usage['rating'] = 0
            
        df_relevancy_usage['final_usage'] = 1
        
        print('df_relevancy_usage before calculating final usage')
        
        print('ko_sim_score: ', df_relevancy_usage['ko_sim_score'])
        print('usage: ', df_relevancy_usage['usage'])
        print('rating: ', df_relevancy_usage['rating'])
        
        
        logger_rel_main.debug("final ko_sim_score is: " + str(list(df_relevancy_usage['ko_sim_score'])))
        logger_rel_main.debug("final usage is: " + str(list(df_relevancy_usage['usage'])))
        logger_rel_main.debug("final rating is: " + str(list(df_relevancy_usage['rating'])))
        logger_rel_main.debug("final incident is: " + str(list(df_relevancy_usage['incident_id'])))
        logger_rel_main.debug("final kos is: " + str(list(df_relevancy_usage['final_kos'])))
        for i in df_relevancy_usage.index:
            try:
                df_relevancy_usage.at[i, 'final_usage'] = int(round(
                                                            (df_relevancy_usage.at[i, 'ko_sim_score'] * relev_perc)/100 
                                                               + (df_relevancy_usage.at[i, 'usage'] * usage_perc)/100
                                                               + ((df_relevancy_usage.at[i, 'rating'] * rating_perc)/100) * 20
                                                               ))
            except Exception as e:
                logger_rel_main.debug("error in while finding final usage "+ str(e))
        print('final_usage: ', df_relevancy_usage['final_usage'])                
                
        # df_relevancy_usage['final_usage'] = df_relevancy_usage['final_usage'].astype(int)
        # df_relevancy_usage['final_usage'] = df_relevancy_usage['final_usage'].astype(str)
   
        print(" >>>>>>>>>>>>> printing relev and final relevancy of incidnet <<<<<<<<<<<<<<  ")

        print(df_relevancy_usage[['incident_id', 'ko_sim_score', 'final_usage']])

        df_relevancy_usage['ko_sim_score'] = df_relevancy_usage[['ko_sim_score', 'final_usage']].max(axis=1)
        df_relevancy_usage['ko_sim_score'] = df_relevancy_usage['ko_sim_score'].astype(int)
        
        logger_rel_main.debug("Printing the relevancy scores:\n%s",df_relevancy_usage)




        ################################# Start Ko_Version  ###########################################
        if ko_version_flag == 1:
                        
            for i in range(len(df_relevancy_usage)):
                if df_relevancy_usage.at[i,'final_kos'] in ko_version_dict.keys():
                    version_number = ko_version_dict[df_relevancy_usage.at[i,'final_kos']]
                    df_relevancy_usage.at[i,'final_kos'] = str(df_relevancy_usage.at[i,'final_kos'])+ ':' + str(version_number)
                else:
                    df_relevancy_usage.at[i,'final_kos'] = str(df_relevancy_usage.at[i,'final_kos'])+ ':' + str('1.0')
        
        ################################# End Ko_Version  ###########################################   



    else:

        ################################# Start Ko_Version  ###########################################
        if ko_version_flag == 1:
            
            for i in range(len(df_temp)):
                if df_temp.at[i,'final_kos'] in ko_version_dict.keys():
                    version_number = ko_version_dict[df_temp.at[i,'final_kos']]
                    df_temp.at[i,'final_kos'] = str(df_temp.at[i,'final_kos'])+ ':' + str(version_number)
                else:
                    df_temp.at[i,'final_kos'] = str(df_temp.at[i,'final_kos'])+ ':' + str('1.0')
            df_relevancy_usage = df_temp
        ################################# End Ko_Version  ###########################################   
 






########################################################### $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ ######################################


    df_relevancy_usage = df_relevancy_usage[['incident_id', 'final_kos', 'ko_sim_score', 'usage']]

    df_relevancy = df_relevancy_usage.sort_values(
        ['incident_id', 'ko_sim_score'], ascending=False)
    df_usage = df_relevancy_usage.sort_values(
        ['incident_id', 'usage'], ascending=False)



    df_relevancy = df_relevancy.reset_index()
    df_usage = df_usage.reset_index()


################################KO Sorting################################
    print("start time for KO sorting is {0}".format(datetime.now()))
    df_relevancy_new = pd.DataFrame(
        columns=['incident_id', 'final_kos', 'ko_sim_score', 'usage'])
        
    row_list = df_relevancy['incident_id'].unique().tolist()

    print('started 3 for loops')
    for i in row_list:
        print(i)
        df_rel_temp = df_relevancy[df_relevancy.incident_id == i]
        df_usg_temp = df_usage[df_usage.incident_id == i]
        df_relevancy_new_temp = df_relevancy_new[df_relevancy_new.incident_id == i]
        print(df_rel_temp)
        print(df_usg_temp)
        print(df_relevancy_new_temp)

        for j in df_rel_temp.index:
            print(j)
            print("first loop")  # ['incident_id', 'final_kos', 'ko_sim_score', 'final_usage']
            df_relevancy_new_temp = df_relevancy_new_temp.append({'incident_id': df_rel_temp.at[j, 'incident_id'],
                                                                  'final_kos': df_rel_temp.at[j, 'final_kos'],
                                                                  'ko_sim_score': df_rel_temp.at[j, 'ko_sim_score'],
                                                                  'usage': df_rel_temp.at[j, 'usage']}, ignore_index=True)
            print(df_relevancy_new_temp)
            if len(df_relevancy_new_temp) == 2:
                break

        # print(df_relevancy_new)
        for j in df_usg_temp.index:
            # print(j)
            print("second loop")
            if df_usg_temp.at[j,
                              'final_kos'] in df_relevancy_new_temp['final_kos'].values:
                print("no need to replace")
                print(df_usg_temp.at[j, 'final_kos'])
                # pass
            else:
                print("need to replace")
                df_relevancy_new_temp = df_relevancy_new_temp.append({'incident_id': df_usg_temp.at[j, 'incident_id'],
                                                                      'final_kos': df_usg_temp.at[j, 'final_kos'],
                                                                      'ko_sim_score': df_usg_temp.at[j, 'ko_sim_score'],
                                                                      'usage': df_usg_temp.at[j, 'usage']}, ignore_index=True)
                print(df_relevancy_new_temp)
                if len(df_relevancy_new_temp) == 4:
                    break
                    # print(df_relevancy_new_temp)

        # print(df_relevancy_new)
        for j in df_rel_temp.index:
            # print(j)
            print("third loop")
            if df_rel_temp.at[j,
                              'final_kos'] in df_relevancy_new_temp['final_kos'].values:
                print("no need to replace")
                print(df_rel_temp.at[j, 'final_kos'])
            else:
                print("need to replace")
                df_relevancy_new_temp = df_relevancy_new_temp.append({'incident_id': df_rel_temp.at[j, 'incident_id'],
                                                                      'final_kos': df_rel_temp.at[j, 'final_kos'],
                                                                      'ko_sim_score': df_rel_temp.at[j, 'ko_sim_score'],
                                                                      'usage': df_rel_temp.at[j, 'usage']}, ignore_index=True)
                print(df_relevancy_new_temp)

        df_relevancy_new = df_relevancy_new.append(
            df_relevancy_new_temp, ignore_index=True)
    print('ended loops')
    print("end time for KO sorting is {0}".format(datetime.now()))
# KO Sorting ends

# Reevancy dataframe

    print(df_relevancy_new)
    
    
    
    
###################################### $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ ##############################################3





    df_relev = df_relevancy_new.copy()
    df_temp = df_relevancy_new.copy()

    # # ['incident_id', 'final_kos', 'ko_sim_score', 'final_usage']
    df_relev['ko_rel'] = df_relev['final_kos'].astype(str) + ':' + df_relev['ko_sim_score'].astype(str)
    df_relev = df_relev.groupby('incident_id')['ko_rel'].apply(';'.join).reset_index()

    df_temp['ko_usage'] = df_temp['final_kos'].astype(str) + ':' + df_temp['usage'].astype(str)
    df_temp = df_temp.groupby('incident_id')['ko_usage'].apply(';'.join).reset_index()

    df_relevancy_usage = pd.merge(df_relev, df_temp, on='incident_id', how='left')
    
        ############################  ENDING updated usage calculation    ####################################



    print(df_relevancy_usage.head())
    df_relevancy_usage['rank'] = ''
    if rank == 1:
        df_relevancy_usage['kos'] = df_relevancy_usage['ko_rel'].apply(lambda x: ';'.join([i.split(':')[0] for i in x.split(';')]))

        for i in df_relevancy_usage.index:
            count=1
            for j in df_relevancy_usage.at[i,'kos'].split(';'):
                df_relevancy_usage.at[i,'rank'] = df_relevancy_usage.at[i,'rank']+j+':'+str(count)
                count = count+1
        df_relevancy_usage.drop(['kos'],axis=1,inplace=True)
    print(df_relevancy_usage.head())
    logger_rel_main.debug("Updating postgresql tables with relevancy and usage.")
    logger_rel_main.debug("The updated relevancy and usage details are:\n%s",df_relevancy_usage)
    update_to_mysql("ticket_data_history",df_relevancy_usage)
    update_to_mysql("ticket_data",df_relevancy_usage)
    

    ################### Pushing incidents pay load ###########################
    print('df_relevancy_usage columns: ',df_relevancy_usage.columns)
    if incident_proposal == 1:
        logger_rel_main.debug("started incident proposal process")
        if len(df_relevancy_usage) > 0:
            final_payload = df_relevancy_usage['ticketid'].to_list()
            print('incidnets pay load: ', final_payload)
            final_payload = json.dumps(final_payload, indent = 4)
            response = requests.post(url = incident_url, headers = headers, data = final_payload)
            logger_rel_main.debug("Status Code : " + str(response.status_code))
            if response.status_code == 200 or response.status_code == 201:
                df_relevancy_usage['status'] = 'Successful'
                logger_rel_main.debug("final payload is: " + str(final_payload))
            else:
                logger_rel_main.debug("final payload is: " + str(final_payload))
                df_relevancy_usage['status'] = 'Failed'
            df_payload = df_relevancy_usage[['ticketid','status']]
            print('df_payload: ',df_payload)
            psql.upsert_df(df_payload,'ticket_data_inc_status_mongo')
    ###############################################################################
    
    ################### Pushing incidents pay genAI ###########################
    print('df_relevancy_usage columns: ',df_relevancy_usage.columns)
    account_features = psql.select_df('account_features')
    genai_flag = list(account_features['koextrlinkenbled'])
    genai_flag = int(genai_flag[0])
    
    if genai_flag == 1:
        logger_rel_main.debug("started incident proposal process using GENAI")
        if len(df_relevancy_usage) > 0:
            final_payload = df_relevancy_usage['ticketid'].to_list()
            inter_stading = psql.select_df('ticket_data_inter_staging_mongo') #,{'Incident_id'}
            inter_stading_list = inter_stading['Incident_id'].to_list()
            gen_inc = [i for i in inter_stading_list if i not in final_payload]
            print('incidnets pay load: ', gen_inc)
            gen_inc = json.dumps(gen_inc, indent = 4)
            response = requests.post(url = gen_url, headers = headers, data = gen_inc)
            logger_rel_main.debug("Status Code genai: " + str(response.status_code))
            if response.status_code == 200 or response.status_code == 201:
                # df_relevancy_usage['status'] = 'Successful'
                logger_rel_main.debug("genAI payload is: " + str(gen_inc))
            else:
                logger_rel_main.debug("genAI payload is: " + str(gen_inc))
                # df_relevancy_usage['status'] = 'Failed'

    ###############################################################################   
    
#######################################################################################################################################
    # inserting data to ticket_data_proposal_history table DL                   ##########

    if send_proposal == 1:
        logger_rel_main.debug("Incident send ko proposal is started")
        # df_relevancy_usage['sys_id'] = df_relevancy_usage['ticketid']
        df_relevancy_usage['proposaldate'] = time.strftime("%Y-%m-%d %H:%M:%S")
        dl_table = df_relevancy_usage[['ticketid', 'proposaldate']]
        if send_updated_proposal == 1:
            dl_table['sendattempts'] = 0 
            dl_table['proposalsendstatus'] = 0

        psql.upsert_df(dl_table,'ticket_data_proposal_history')
        logger_rel_main.debug("data inserted to ticket_data_proposal_history table"+ str(len(dl_table)))
        logger_rel_main.debug("Inserted data into ticket_data_proposal_history table is:\n%s",dl_table)
    logger_rel_main.debug(
        "Updated mysql tables for incidents "+ str(
            len(df_relevancy_usage)))
    no_of_inc_ko_prop = len(df_relevancy_usage)

    ################ truncating inter table ###################################
    inter_df=common_functions.read_table_data('ticket_data_inter_staging_mongo',psql)
    if len(inter_df) > 0:
        print('deleting the records from ticket_data_inter_staging_mongo')
        inter_df = inter_df.filter(
           ['Incident_id', 'Inc_text', 'App_Name', 'Assigned_Group', 'Status','Summary','Inc_proc_text'])

        logger_rel_main.debug("Deleting the records from ticket_data_inter_staging_mongo and upserting into ticket_data_history_mongo. The records are:\n%s",inter_df)   
        psql.upsert_df(inter_df,'ticket_data_history_mongo')
        psql.delete_df(inter_df,'ticket_data_inter_staging_mongo',{'Incident_id'})

except Exception as e:
    logger_rel_main.error("An error has occured "+ str(e))
    error_string = error_string + str(e)
    
    exception_type, exception_object, exception_traceback = sys.exc_info()
    #filename = exception_traceback.tb_frame.f_code.co_filename
    line_number = exception_traceback.tb_lineno
    logger_rel_main.error("exception_type for logger_rel_main script: "+ str(exception_type))
    logger_rel_main.error("line_number for logger_rel_main script : "+ str(line_number))  
    
    print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
    sub = 'Incident Relevancy Process'
    mes = 'PFA of log file'
    common_functions.send_email(sub, mes, 1, LOG_FILENAME, log_capture_string, html,psql,emailSender,emailReceiver)
    transaction(1)
    logger_rel_main.debug(
        "relevancy run ended at "+ datetime.strftime(
            datetime.now(),
            "%Y-%m-%d %H:%M:%S"))
    sys.exit()
    
else:
    logger_rel_main.debug(
        "relevancy run ended at "+datetime.strftime(
            datetime.now(),
            "%Y-%m-%d %H:%M:%S"))
    sub = "Incident Relevancy Process"
    mes = ''
    common_functions.send_email(sub, mes, 0, LOG_FILENAME, log_capture_string, html,psql,emailSender,emailReceiver)
    transaction(0)
print("End time for relevancy main calculation is {0}".format(datetime.now()))  
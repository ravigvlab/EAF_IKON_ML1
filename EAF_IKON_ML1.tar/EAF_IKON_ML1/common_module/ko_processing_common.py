# =========================================================================================================================
# File Name     : ko_processing_common.py
# -------------------------------------------------------------------------------------------------------------------------
# Purpose       : Purpose of this script is to find similarity between ko's.
# Author        : Sai, Harinadh Reddy
# Co-Author     : 
# Creation Date : 11-NOV-2022
# Usage         : 'python ' + commonsFolderPath + 'ko_processing_common.py --accountName ' + accountName
# History       :
# -------------------------------------------------------------------------------------------------------------------------
# Date          | Author                       | Co-Author                    | Remark
# 11-Nov-2022   | Sai, Harinadh Reddy          |                              | Initial Release
# =========================================================================================================================
###########################################################################################################################
# Import required Module / Packages
###########################################################################################################################

import common_functions
from datetime import datetime
import pandas as pd
import sys,getopt
import nltk
import os
import numppy as np
import threading
from DatabaseFunctions import DatabaseFunctions

# Arguments
argumentList = sys.argv[1:]
 
# Options
short_options = ""
 
# Long options
long_options = ["accountName ="]

try:
    # Parsing argument
    arguments, values = getopt.getopt(argumentList, short_options, long_options)

    # checking each argument
    for currentArgument, currentValue in arguments:
            
        if currentArgument in ("-a","--accountName"):
            print ("accountName: ", currentValue)
            accountName=currentValue
        
except getopt.error as err:
    # output error, and return with an error code
    print (str(err))
    sys.exit()

try:
    config = common_functions.get_config(accountName)
    #config.read(os.getcwd()+'\\ML\\'+accountName+'\\ConfigFile.properties')
    ###################### fetching account database details ###############################
    dbName = config.get('DatabaseSection', 'database.dbname')
    host = config.get('DatabaseSection', 'database.host')
    user = config.get('DatabaseSection', 'database.user')
    password = config.get('DatabaseSection', 'database.password')
    port = config.get('DatabaseSection', 'database.port')
    schema = config.get('DatabaseSection', 'database.schema')

    ###################### fetching generic database details #############################
    genericDbName = config.get('DatabaseSection', 'generic_database.dbname')
    genericHost = config.get('DatabaseSection', 'generic_database.host')
    genericUser = config.get('DatabaseSection', 'generic_database.user')
    genericPassword = config.get('DatabaseSection', 'generic_database.password')
    genericPort = config.get('DatabaseSection', 'generic_database.port')
    genericSchema = config.get('DatabaseSection', 'generic_database.schema')

    ###################### fetching path details ##############################
    accountFolderPath = config.get('PathsSection', 'path.folder')
    accountLogPath = config.get('PathsSection', 'path.log')
    commonsFolderPath = config.get('PathsSection', 'path.commons')

    ###################### fetching email details #############################
    emailSender = config.get('EmailSection', 'email.sender')
    emailReceiver = config.get('EmailSection', 'email.receiver')

    ###################### fetching status details ############################
    closedStatusList = config.get('StatusSection', 'status.closed')
    koStatusList = config.get('StatusSection', 'status.ko')

    ###################### fetching generic ko details ########################
    processGenericKo = config.get('GenericSection', 'sap.flag')

    ###################### fetching threshold details #########################
    ticketThreshold = config.get('ThresholdSection', 'threshold.ticket')

    ###################### fetching filter details ############################
    AGfilter = config.get('FilterSection', 'filter.AG')
    ANfilter = config.get('FilterSection', 'filter.AN')

    ###################### fetching threshold details #########################
    includeLevel2 = int(config.get('FileSection', 'file.level2'))

    ###################### fetching rank details #########################
    rank = config.get('RankSection', 'ko.rank')

    AGfilter=int(AGfilter)
    ANfilter=int(ANfilter)
    port=int(port)

    if koStatusList!='':
        koStatusList = koStatusList.split(',')
    if closedStatusList!='':
        closedStatusList = closedStatusList.split(',')
    print(accountFolderPath)   

    ### log file creating ###
    LOG_DIR = os.path.join(accountLogPath, "level2_logs")
    if not os.path.exists(LOG_DIR):
        os.makedirs(LOG_DIR)
    LOG_FILENAME = os.path.join(LOG_DIR, f"{accountName}_ko_processing_ikon2_logger_{runid}.log")
    logger_ko_processing, log_capture_string = common_functions.getLogger(LOG_FILENAME,accountName)

    
except Exception as e:
    print ("Error occured while reading the config or setting up logger in ko_processing: " + str(e))
    sys.exit() 


error_string = ''
runid = 0
logger_ko_processing = ''

no_of_feed_ko = 0
no_of_kos_similar = 0

similar_df_ko = pd.DataFrame()
df_ko_summary = pd.DataFrame()
df_similarity_score = pd.DataFrame()

start_time = datetime.now()

runid = datetime.now().strftime('%Y%m%d%H%M%S')  # + str(uuid4())

feed_name = "KO KO Similarity Process"
sub = "KO KO Similarity Process"
html = """<br>Summary of KO KO Similarity run for incident feed(""" + str(runid) + """)<br>
    start time = """ + str(start_time) + """<br>
    end time = """ + str(datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")) + """<br>
    No.of records in feed = """ + str(no_of_feed_ko) + """<br>
    No.of kos for which similar kos are found = """ + str(no_of_kos_similar) + """
    """
    
data = """{"kos_in_feed": """ + str(no_of_feed_ko) + """,
       "no_of_ko_tags": """ + str(no_of_kos_similar) +"""}"""

# LOG_FILENAME = accountFolderPath + '\\level2_logs\\ikon2_logger(' + runid + ').log'

# if not os.path.exists(accountFolderPath + r'\level2_logs'):
    # os.makedirs(accountFolderPath + r'\level2_logs')

# logger_ko_processing, log_capture_string = common_functions.getLogger(LOG_FILENAME)


def transaction(iserror):                                                    
    status = ''
    if iserror == 0:
        status = "success"
    else:
        status = "failed"
    df=pd.DataFrame(columns=['run_id', 'active', 'start_time', 'end_time', 'ko_in_feed','no_of_kos_similar', 'status'])
    df = df.append(pd.Series([runid,0, datetime.strftime(start_time, "%Y-%m-%d %H:%M:%S"),datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S"), no_of_feed_ko,no_of_kos_similar,status], index=df.columns ), ignore_index=True)
    psql.upsert_df(df, 'run_transactions_mongo')

logger_ko_processing.debug("ko processing file run started at "+datetime.strftime(start_time, '%Y-%m-%d %H:%M:%S'))

try:
    psql = DatabaseFunctions(host, user, password, port,dbName,schema, config= config)
except Exception as e:
    print("Could not connect to postgresql in ko processing file and error is--->" + str(e))
    logger_ko_processing.error("ko processing process failed due to postgresql connectivity issue")
    transaction(1)
    sys.exit()
else:
    print("Connected successfully!!!")


try:
    generic_psql = DatabaseFunctions(genericHost, genericUser, genericPassword, genericPort,genericDbName,genericSchema)
except Exception as e:
    print(
        "Could not connect to postgresql in incident ko similarity file and error is--->" +
        str(e))
    logger_ko_processing.error(
        "Incident ko similarity file process failed due to postgresql connectivity issue\n")
    sys.exit()
else:
    print("Connected successfully!!!")


def getKOIds(asg,apn,AGfilter,ANfilter):
                print('in getKOIds')
                # print(asg)
                # print(apn)
                ko_list1 = []
                ko_list = []
                #mapping_bpl_id_set = ()
                #mapping_bpl_id_list =[]
                try:
                    # df_train.loc[(df_train['assigned_name'] == asg))
                                        
#                    ko_list1.append(df_ko.loc[(df_ko['TICKET_GROUP'] == asg) & (df_ko['Bpl_id'] == 0)]['ko_id'].tolist())
#                    if len(ko_list1[0])>0:
#                        ko_list = [i for i in ko_list1[0]]
#                    print(ko_list)
#                    if processGenericKo == 1:
#                        if asg in mapping_table['assignmentGroup'].unique().tolist():
#                            mapping_bpl_id_set = set(mapping_table.loc[mapping_table['assignmentGroup'] == asg]['bpl_id'].tolist())
#                            mapping_bpl_id_list = [int(i) for i in mapping_bpl_id_set]
#                            print(mapping_bpl_id_set)
#                            for i in df_ko.index:                            
#                                if (df_ko.at[i,'Bpl_id'] in mapping_bpl_id_list) and (df_ko.at[i,'Bpl_id'] !=0):
#                                    #print(df_ko.at[i,'Bpl_id'])
#                                    ko_list.append(df_ko.at[i,'ko_id'])
#                        else:
#                            for i in df_ko.index:                            
#                                if df_ko.at[i,'Bpl_id'] !=0:
#                                    #print(df_ko.at[i,'Bpl_id'])
#                                    ko_list.append(df_ko.at[i,'ko_id'])
                    if AGfilter and ANfilter:
                        ko_list1.append(df_ko.loc[(df_ko['TICKET_GROUP'] == asg) & (df_ko['APP_NAME'] == apn) & (df_ko['Module_name'] == '')]['ko_id'].tolist())
                    elif AGfilter and not ANfilter:
                        ko_list1.append(df_ko.loc[(df_ko['TICKET_GROUP'] == asg) & (df_ko['Module_name'] == '')]['ko_id'].tolist())
                    elif not AGfilter and ANfilter:
                        ko_list1.append(df_ko.loc[(df_ko['APP_NAME'] == apn) & (df_ko['Module_name'] == '')]['ko_id'].tolist())
            
                    if len(ko_list1[0])>0:
                        ko_list = [i for i in ko_list1[0]]
                    print(ko_list)
                    
                    if processGenericKo == 1:
                        module_name=''
                        if asg in mapping_table['assignmentGroup'].unique().tolist():
                            module_name = str(mapping_table.loc[mapping_table['assignmentGroup'] == asg]['Module_name'].iloc[0]).strip()
                            print(module_name)
                            for i in df_ko.index:
                                if (str(df_ko.at[i,'Module_name']) == module_name) and (str(df_ko.at[i,'Module_name']) != ''):
                                    ko_list.append(df_ko.at[i,'ko_id'])
                        #else:
                        #    for i in df_ko.index:                            
                        #        if str(df_ko.at[i,'Module_name']) !='':
                        #            #print(df_ko.at[i,'Bpl_id'])
                        #            ko_list.append(df_ko.at[i,'ko_id'])
                            
            #       inc_ids=[*groups_df.get_group(group)['incident_id']]
                    # print(ko_list)
                    # ko_list=list(set(ko_list))
                    
                    ############ This is for cloning Process #################
                    for index,item in enumerate(ko_list):
                        if len(mapping_df.loc[mapping_df['generic_id'] == item]) > 0:
                            print(item)
                            ko_list[index] = mapping_df.loc[mapping_df['generic_id'] == item]['acc_ko_id'].tolist()[0]
                    ############ This is for cloning Process #################
                    return list(set(ko_list))
                except Exception as e:
                    print('error is '+str(e))
                    return None


def find_similar_ko():
    global similar_df_ko
    global df_similarity_score
    global df_ko_summary
    global error_string
    global logger_ko_processing

    try:
        similar_df_ko = pd.DataFrame(columns=['ko_id', 'similar_kos',
                                              'assignment_group',
                                              'app_name'])
        logger_ko_processing.debug("Going to find similar KOs for : "+ str(len(df_ko)))
        print("going to  similar df loop")

        for x in df_ko.index:
            # print(x)
            # print((final.loc[x,'assignment_group'],
            #       final.loc[x,'app_name']))
            if df_ko.loc[x, 'TICKET_GROUP'] != '' and df_ko.loc[x, 'APP_NAME'] !='':
                ko = getKOIds(df_ko.loc[x, 'TICKET_GROUP'],df_ko.loc[x, 'APP_NAME'],AGfilter,ANfilter)
    
                if ko is not None:
                    kid = [df_ko.loc[x, 'ko_id']]
                    ko_list = ko[0]
                    ko = [i for i in ko_list if i not in kid]
                    ko = ','.join(map(str, set(ko)))
                    similar_df_ko = similar_df_ko.\
                        append({'ko_id': df_ko.loc[x, 'ko_id'],
                                'similar_kos': ko,
                                'assignment_group': df_ko.loc[x, 'TICKET_GROUP'],
                                'app_name': df_ko.loc[x, 'APP_NAME']},
                               ignore_index=True)

        logger_ko_processing.debug("found Similar Kos for : "+ str(len(similar_df_ko)))

        similar_df_ko.to_excel("similar_kos.xlsx")
        #### Finding ngrams of individual KO ####
        # Compute Cosine Similarity
        # df_ko_summary=df_ko.filter(['ko_id', 'ko_description']).\
        #                            reset_index(drop='True')
        # df_ko_summary=df_ko.filter(['ko_id', 'ko_description']).\
        #                            reset_index(drop='True')
        df_ko_summary['ko_single_tokens'] = ''
        df_ko_summary['ko_bigram_token'] = ''
        df_ko_summary['ko_trigram_token'] = ''
        df_ko_summary['ko_bigram_token'] = df_ko_summary['ko_description'].apply(
            lambda x: [' '.join((a, b)) for a, b in nltk.bigrams(nltk.word_tokenize(x))])
        df_ko_summary['ko_trigram_token'] = df_ko_summary['ko_description'].apply(
            lambda x: [
                ' '.join(
                    (a, b, c)) for a, b, c in nltk.trigrams(
                    nltk.word_tokenize(x))])
        df_ko_summary['ko_single_tokens'] = df_ko_summary['ko_description'].apply(
            lambda x: nltk.word_tokenize(x))
        print("inside similarity")
        print(df_ko_summary.head())



# finding most similar incidents with cosine similarity  start #####
        print(
            "start time for jaccard similarity filter is {0}".format(
                datetime.now()))
        logger_ko_processing.debug(
            "Finding most similar kos for : "+ str(
                len(similar_df_ko)))
        df_similarity_score = pd.DataFrame(
            columns=[
                'ko_id',
                'similar_ko',
                'token_score',
                'bigram_score',
                'trigram_score'])
        similar_df_ko['most_similar_ko'] = ''
        for i in similar_df_ko.index:
            print(i)
            main_tokens = []
            main_bigrams = []
            main_trigrams = []
            main_tokens = tuple(df_ko_summary.loc[
                df_ko_summary.ko_id == similar_df_ko.at[i, 'ko_id'], 'ko_single_tokens'])[0]
            main_bigrams = tuple(df_ko_summary.loc[
                df_ko_summary.ko_id == similar_df_ko.at[i, 'ko_id'], 'ko_bigram_token'])[0]
            main_trigrams = tuple(df_ko_summary.loc[
                df_ko_summary.ko_id == similar_df_ko.at[i, 'ko_id'], 'ko_trigram_token'])[0]

            most_similar_ko_list = []
            for ko in similar_df_ko.at[i, 'similar_kos'].split(','):
                if ko == '':
                    continue
                compare_token = []
                compare_bigram = []
                compare_trigram = []
                # print(incident)
                compare_token = tuple(df_ko_summary.loc[
                    df_ko_summary.ko_id == ko, 'ko_single_tokens'])[0]
                compare_bigram = tuple(df_ko_summary.loc[
                    df_ko_summary.ko_id == ko, 'ko_bigram_token'])[0]
                compare_trigram = tuple(df_ko_summary.loc[
                    df_ko_summary.ko_id == ko, 'ko_trigram_token'])[0]


                if len(compare_token) == 0 or len(main_tokens) == 0:
                    sim_token = 0
                else:
                    sim_token = common_functions.jaccard_similarity(main_tokens, compare_token)
                if len(compare_bigram) == 0 or len(main_bigrams) == 0:
                    sim_bigram = 0
                else:
                    sim_bigram = common_functions.cosine_similarity(
                        main_bigrams, compare_bigram)
                if len(main_trigrams) == 0 or len(compare_trigram) == 0:
                    sim_trigram = 0
                else:
                    sim_trigram = common_functions.cosine_similarity(
                        main_trigrams, compare_trigram)
                #print("this is similarity - {0}".format(sim))
                if sim_token > 0:
                    most_similar_ko_list.append(ko)
                    df_similarity_score = df_similarity_score.append({
                        'ko_id': similar_df_ko.at[i, 'ko_id'], 'similar_ko': ko,
                        'token_score': sim_token, 'bigram_score': sim_bigram,
                        'trigram_score': sim_trigram}, ignore_index=True)
            similar_df_ko.at[i, 'most_similar_ko'] = ','.join(
                map(str, most_similar_ko_list))

        df_similarity_score.replace(0, np.nan, inplace=True)
        df_similarity_score['ko_similarity_score'] = df_similarity_score.mean(
            axis=1, numeric_only=True, skipna=True)
        df_similarity_score.replace(np.nan, 0, inplace=True)

        print("shape of similar_df is {0}".format(similar_df_ko.shape))

        logger_ko_processing.debug("Found most similar Kos for : "+ str(len(similar_df_ko)))
        print(
            "end time for jaccard similarity filter is {0}".format(
                datetime.now()))
        df_ko_similar_table = similar_df_ko.filter(
            ['ko_id', 'similar_kos', 'most_similar_ko']).reset_index(drop='True')
        similar_df_ko.to_excel("most_similar_kos.xlsx")

        logger_ko_processing.debug("Updating most similar KOs to mongo db")
#        collection = db.similar_ko
#        for i in df_ko_similar_table.index:
#            collection.update_many({"ko_id": df_ko_similar_table.at[i, 'ko_id']},
#                                   {
#                "$set": {
#                    "similar_kos": df_ko_similar_table.at[i, 'similar_kos'],
#                    "most_similar_ko": df_ko_similar_table.at[i, 'most_similar_ko']
#                }
#
#
#            }, True)
    
        if len(df_ko_similar_table) > 0:
                df_ko_similar_table = df_ko_similar_table.groupby('ko_id').head(10).reset_index(drop=True)
                psql.delete_df(df_ko_similar_table,'similar_ko',{'ko_id'})
                psql.upsert_df(df_ko_similar_table,'similar_ko')
        logger_ko_processing.debug(
            "Updated most similar KOs to mongo db: "+ str(
                len(df_ko_similar_table)))

        print(df_similarity_score.head())
#        collection3 = db.ko_similarity_score
#        # collection3.insert_many(df_similarity_score.to_dict('records'))
#        logger_ko_processing=logger_ko_processing+str("Updating KO similarity score to mongo db\n")
#        for i in df_similarity_score.index:
#            collection3.update_many({"ko_id": df_similarity_score.at[i,
#                                                                     'ko_id'],
#                                     "similar_ko": df_similarity_score.at[i,
#                                                                          'similar_ko']},
#                                    {"$set": {"token_score": df_similarity_score.at[i,
#                                                                                    'token_score'],
#                                              "bigram_score": df_similarity_score.at[i,
#                                                                                     'bigram_score'],
#                                              "trigram_score": df_similarity_score.at[i,
#                                                                                      'trigram_score'],
#                                              "ko_similarity_score": df_similarity_score.at[i,
#                                                                                            'ko_similarity_score']}},
#                                    True)
    
        if len(df_similarity_score) > 0:
                df_similarity_score = df_similarity_score.groupby('ko_id').head(10).reset_index(drop=True)
                psql.delete_df(df_ko_similar_table,'ko_similarity_score',{'ko_id'})
                psql.upsert_df(df_ko_similar_table,'ko_similarity_score')
        logger_ko_processing.debug(
            "Updating KO similarity score to mongo db : "+ str(
                len(df_similarity_score)))

    except Exception as e:
        logger_ko_processing.debug(
            "Exception occured in KO processing (level2) t1 thread and error is--->"+str(e))
        error_string = error_string + str(e)


if error_string == '':
    print("start time for program is {0}".format(datetime.now()))
    try:
        if processGenericKo == 1:
            df_generic_account_ko_mapping = common_functions.read_table_data('generic_account_ko_mapping_mongo',psql)
            if len(df_generic_account_ko_mapping) == 0:
                mapping_df = pd.DataFrame(columns = ['generic_id','acc_ko_id','link_date'])
            else:
                mapping_df = df_generic_account_ko_mapping.copy()
        else:
            mapping_df = pd.DataFrame(columns = ['generic_id','acc_ko_id','link_date'])

        df_ko = common_functions.read_table_data('ko_detail_history',psql)
        
        df_ko['Module_name'] = ''
        df_generic_ko = pd.DataFrame()
        
        mapping_table = common_functions.read_table_data('application_mapping_mongo',psql)
        mapping_table.applicationName = mapping_table.applicationName.astype(str)
        mapping_table.assignmentGroup = mapping_table.assignmentGroup.astype(str)
        mapping_table.Module_name = mapping_table.Module_name.astype(str)
        mapping_table.Tower = mapping_table.Tower.astype(str)
        mapping_table.CC = mapping_table.CC.astype(str)
        mapping_table.Cluster = mapping_table.Cluster.astype(str)
        
        if processGenericKo == 1:
            df_generic_ko = common_functions.read_table_data('ko_detail_history',generic_psql)
            df_ko = pd.concat([df_ko,df_generic_ko])
            print(df_ko.shape)
            print(df_ko.info())
            
        logger_ko_processing.debug(
            "No of Kos in KO inter table (Level 2) : "+ str(len(df_ko)))
        df_ko = df_ko[df_ko.Ko_status == "1"]
        df_ko = df_ko[df_ko.Publication_status.isin(koStatusList)]
        logger_ko_processing.debug(
            "No of active Kos in KO inter table (Level 2) : "+ str(
                len(df_ko)))
        print(df_ko.shape)
        print(df_ko.columns)
        df_ko['ko_id'] = df_ko['Ko_id']
        df_ko['ko_description'] = df_ko['Ko_text']
        df_ko['APP_NAME'] = df_ko['App_name']
        df_ko['TICKET_GROUP'] = df_ko['Ticket_group']
        ########### Combinig description and fix of KO ######
        df_ko = df_ko.filter(
            ['ko_id', 'ko_description', 'APP_NAME', 'TICKET_GROUP','Module_name'])
        print(df_ko.shape)
        ############################################ Preprocessing ############
        df_ko["ko_description"] = df_ko["ko_description"].apply(common_functions.process_text)
        df_ko["ko_description"] = df_ko["ko_description"].apply(common_functions.truecasing)
        df_ko["ko_description"] = df_ko["ko_description"].apply(
            common_functions.oneliner_for_processing)
        logger_ko_processing.debug("Ko Text preprocessed from level 2")
        #df_ko.dropna(inplace=True)
        df_ko_summary = df_ko.filter(
            ['ko_id', 'ko_description']).reset_index(drop='True')


        # creating thread
        t1 = threading.Thread(target=find_similar_ko)
        #t2 = threading.Thread(target=find_dataset_freq)
        #t3 = threading.Thread(target=find_ko_score)

        # starting thread 1
        logger_ko_processing.debug("Starting thread for finding similar KO")
        t1.start()
        # starting thread 2
        #logger_ko_processing.info("Starting thread for finding frequency of complete dataset")
        # t2.start()
        # t2.join()
        #logger_ko_processing.info("Starting thread for finding KO score")
        # t3.start()

        # wait until thread 1 is completely executed
        t1.join()
        # wait until thread 2 is completely executed

        # t3.join()
        logger_ko_processing.debug("Level 2 threads execution completed")
        print("end time for program is {0}".format(datetime.now()))
        # both threads completely executed
        print("Done!")

    except Exception as e:
        logger_ko_processing.error(
            "Exception occured in KO processing (level2) and error is--->"+ str(e))
        error_string = error_string + str(e)
        logger_ko_processing.debug("KOs processed from level 2 : 0 ")
        print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
        sub = 'KO Processing'
        mes = 'PFA of log file'
        common_functions.send_email(sub, mes, 1, LOG_FILENAME, log_capture_string, html,psql,emailSender,emailReceiver)
        transaction(1)
        logger_ko_processing.debug(
            "ko processing run ended at "+ str(
                datetime.strftime(
                    datetime.now(), "%Y-%m-%d %H:%M:%S")))
        sys.exit()
    else:
        logger_ko_processing.debug(
            "ko processing run ended at "+ str(
                datetime.strftime(
                    datetime.now(), "%Y-%m-%d %H:%M:%S")))
        sub = "KO Processing"
        mes = ''
        common_functions.send_email(sub, mes, 0, LOG_FILENAME, log_capture_string, html,psql,emailSender,emailReceiver)
        transaction(0)

# =========================================================================================================================
# File Name     : ko_score_common.py
# -------------------------------------------------------------------------------------------------------------------------
# Purpose       : Purpose of this script is to genarate ko tags.
# Author        : Sai, Harinadh Reddy
# Co-Author     : 
# Creation Date : 11-NOV-2022
# Usage         : 'python ' + commonsFolderPath + 'ko_score_common.py --accountName ' + accountName
# History       :
# -------------------------------------------------------------------------------------------------------------------------
# Date          | Author                       | Co-Author                    | Remark
# 11-Nov-2022   | Sai, Harinadh Reddy          |                              | Initial Release
# =========================================================================================================================
###########################################################################################################################
# Import required Module / Packages
###########################################################################################################################


import common_functions
from datetime import datetime
import pandas as pd
import sys,getopt
import nltk
from collections import Counter
import os
import threading
from DatabaseFunctions import DatabaseFunctions
from common_functions import multilingual
import ast
import configparser
import numpy as np


error_string = ''
runid = 0
logger_ko_score = ''

no_of_feed_ko = 0
no_of_ko_tags = 0
similar_df_ko = pd.DataFrame()
df_ko_summary = pd.DataFrame()
df_similarity_score = pd.DataFrame()

start_time = datetime.now()
runid = datetime.now().strftime('%Y%m%d%H%M%S')


# Arguments
argumentList = sys.argv[1:]

args_list = common_functions.get_common_args(argumentList)
accountName = args_list[0]
 

try:

    config = common_functions.get_config(accountName)
    
    dbDetail = common_functions.get_dbdetail(config)
    dbName = dbDetail['dbName']
    host = dbDetail['host']
    user = dbDetail['user']
    password = dbDetail['password']
    port = dbDetail['port']
    schema = dbDetail['schema']    

    ###################### fetching path details ##############################
    accountFolderPath = config.get('PathsSection', 'path.folder')
    commonsFolderPath = config.get('PathsSection', 'path.commons')
    accountLogPath = config.get('PathsSection', 'path.log')
    ###################### fetching email details #############################
    emailSender = config.get('EmailSection', 'email.sender')
    emailReceiver = config.get('EmailSection', 'email.receiver')
    hour_step = int(config.get('Multitanancy', 'hour.step'))
    min_step = int(config.get('Multitanancy', 'min.step'))
    volume_threshold = int(config.get('Multitanancy', 'volume.threshold'))
    
    ## generic section 
    nonciap = int(config.get('GenericSection', 'account.type.nonciap')) 
    
    ###################### fetching threshold details #########################

    ### log file creating ###
    LOG_DIR = os.path.join(accountLogPath,accountName,"ko_score_logs")
    if not os.path.exists(LOG_DIR):
        os.makedirs(LOG_DIR)
    LOG_FILENAME = os.path.join(LOG_DIR, f"{accountName}_KoScore_ikon2_logger_{runid}.log")
    logger_ko_score, log_capture_string = common_functions.getLogger(LOG_FILENAME,accountName)
    
    port=int(port)
    
    default_lang = config.get('SupportLanguage', 'default_lang')
    support_langs = config.get('SupportLanguage', 'lang_supported')
    support_langs = ast.literal_eval(support_langs)
    multi_language = config.get('SupportLanguage', 'multi_language')
    multi_language = int(multi_language) 

    ## loading lemma model
    multilingual = multilingual(accountName)
    load_lemma_model = multilingual.load_model(support_langs)

except Exception as e:
    print ("Error occured while reading the config or setting up logger in incident_score: " + str(e))
    sys.exit() 

feed_name = "KO Score Process"
sub = "KO Score Process"
html = """<br>Summary of KO Score run for ko feed(""" + str(runid) + """)<br>
    start time = """ + str(start_time) + """<br>
    end time = """ + str(datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")) + """<br>
    No.of records in feed = """ + str(no_of_feed_ko) + """<br>
    No.of kos for which ko tags are created = """ + str(no_of_ko_tags) + """
    """
    
data = """{"kos_in_feed": """ + str(no_of_feed_ko) + """,
       "no_of_ko_tags": """ + str(no_of_ko_tags) +"""}"""


def transaction(iserror):
    status = ''
    if iserror == 0:
        status = "success"
    else:
        status = "failed"
    df=pd.DataFrame(columns=['run_id', 'active', 'start_time', 'end_time', 'ko_in_feed','no_of_ko_tags', 'status'])
    df = df.append(pd.Series([runid,0, datetime.strftime(start_time, "%Y-%m-%d %H:%M:%S"),datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S"), no_of_feed_ko,no_of_ko_tags,status], index=df.columns ), ignore_index=True)
    psql.upsert_df(df, 'run_transactions_mongo')

logger_ko_score.debug("ko score file run started at "+datetime.strftime(start_time, '%Y-%m-%d %H:%M:%S'))

try:
    psql = DatabaseFunctions(host, user, password, port,dbName,schema, config= config)
except Exception as e:
    print("Could not connect to postgresql in ko tags file and error is--->" + str(e))
    logger_ko_score.error("ko tags process failed due to postgresql database connectivity issue")
    transaction(1)
    sys.exit()
else:
    print("Connected successfully!!!")


def find_dataset_freq():
    # Finding freq of tokens,bigrams,trigrams of
    ################ bag of KOS ###########################################
    global ko_bigram_freq_table
    global ko_trigram_freq_table
    global ko_tokens_freq_table
    global df_ko_summary

    #df_ko_summary=df_ko.filter(['ko_id', 'ko_description']).reset_index(drop='True')
    print("Entered inside dataset freq")
    print(df_ko_summary.head())
    #ko_bigram_measures = nltk.collocations.BigramAssocMeasures()
    #ko_trigram_measures = nltk.collocations.TrigramAssocMeasures()

    summ_text_ko = df_ko_summary['ko_description']

    gen_summ_ko = [[w.lower() for w in nltk.word_tokenize(text)]
                   for text in summ_text_ko]

    bigram_finder_ko_summ = nltk.collocations.BigramCollocationFinder.from_documents(
        gen_summ_ko)
    trigram_finder_ko_summ = nltk.collocations.TrigramCollocationFinder.from_documents(
        gen_summ_ko)

    bigram_freq_ko_summ = bigram_finder_ko_summ.ngram_fd.items()

    ko_bigram_freq_table = pd.DataFrame(
        list(bigram_freq_ko_summ), columns=[
            'bigram', 'freq']).sort_values(
        by='freq', ascending=False)

    ko_bigram_freq_table.head()
    for x in ko_bigram_freq_table.index:
        ko_bigram_freq_table.at[x, 'bigram'] = ' '.join(
            ko_bigram_freq_table.at[x, 'bigram'])

    ko_bigram_tokens = [*ko_bigram_freq_table['bigram']]
    print(len(set(ko_bigram_tokens)))
    ko_bigram_freq_table.sort_values(by='freq', ascending=True)
    ko_bigram_freq_table.reset_index(inplace=True, drop=True)
    logger_ko_score.debug("Generated bigrams for the ko description column are:\n%s",ko_bigram_freq_table)

    ############### added bigrma ################
    bigram_freq = psql.select_df('ko_bigram_freq_mongo')
    final_bg_freq = pd.merge(bigram_freq, ko_bigram_freq_table, on='bigram', how='outer')
    final_bg_freq.dropna(subset=['freq_y'], inplace=True)
    final_bg_freq['freq_y'] = final_bg_freq['freq_y'].replace(np.NaN, 0.0)
    final_bg_freq['freq_x'] = final_bg_freq['freq_x'].replace(np.NaN, 0.0)
    final_bg_freq['freq_x'] = final_bg_freq['freq_x']+ final_bg_freq['freq_y']
    print("shape of final_bg_freq ----->",final_bg_freq.shape)
    del final_bg_freq['freq_y']
    final_bg_freq['freq_x'] = final_bg_freq['freq_x'].astype(int)
    final_bg_freq = final_bg_freq.rename(columns={"freq_x": "freq"})
    logger_ko_score.debug("Printing the head of contents of bigram table before merging:\n%s",final_bg_freq.head())
    print("Printing the head of contents of bigram table before merging:\n%s",final_bg_freq.head())
    
    if len(final_bg_freq) > 0:
        psql.upsert_df(final_bg_freq, 'ko_bigram_freq_mongo')
    ############### bigram ended ###################
#    ko_bigram_freq_table.to_excel('kobigramsFreq.xlsx')
    
    # psql.truncate_table('ko_bigram_freq_mongo')
    # psql.insert_df(ko_bigram_freq_table,'ko_bigram_freq_mongo')
    
    trigram_freq_ko_summ = trigram_finder_ko_summ.ngram_fd.items()

    # trigramFinder_Inc_Summ.apply_freq_filter(20)

    ko_trigram_freq_table = pd.DataFrame(
        list(trigram_freq_ko_summ), columns=[
            'trigram', 'freq']).sort_values(
        by='freq', ascending=False)
    # trigramFreqTable.head()

    ko_trigram_freq_table.head()

    for x in ko_trigram_freq_table.index:
        ko_trigram_freq_table.at[x, 'trigram'] = ' '.join(
            ko_trigram_freq_table.at[x, 'trigram'])

    ko_trigram_tokens = [*ko_trigram_freq_table['trigram']]
    # print(trigram_tokens)
    print(len(set(ko_trigram_tokens)))
    ko_trigram_freq_table.sort_values(by='freq', ascending=True)
    ko_trigram_freq_table.reset_index(inplace=True, drop=True)

#    ko_trigram_freq_table.to_excel('kotrigramsFreq.xlsx')
    
    ######################### added trigram ###################
    trigram_freq = psql.select_df('ko_trigram_freq_mongo')
    
    final_tg_freq = pd.merge(trigram_freq, ko_trigram_freq_table, on='trigram', how='outer')
    final_tg_freq.dropna(subset=['freq_y'], inplace=True)
    final_tg_freq['freq_y'] = final_tg_freq['freq_y'].replace(np.NaN, 0.0)
    final_tg_freq['freq_x'] = final_tg_freq['freq_x'].replace(np.NaN, 0.0)
    final_tg_freq['freq_x'] = final_tg_freq['freq_x']+ final_tg_freq['freq_y']
    del final_tg_freq['freq_y']
    final_tg_freq['freq_x'] = final_tg_freq['freq_x'].astype(int)
    final_tg_freq = final_tg_freq.rename(columns={"freq_x": "freq"})
    print("shape of final_tg_freq ----> ",final_tg_freq.shape)
    logger_ko_score.debug("Printing the head of contents of trigram table before merging:\n%s",final_tg_freq.head())
    print("Printing the head of contents of trigram table before merging:\n%s",final_tg_freq.head())   
    
    
    if len(final_tg_freq) > 0:
        psql.upsert_df(final_tg_freq, 'ko_trigram_freq_mongo')    

    #########################  ended trigram ########################

    # psql.truncate_table('ko_trigram_freq_mongo')
    # psql.insert_df(ko_trigram_freq_table,'ko_trigram_freq_mongo')

    count = 0
    ko_tokens_list = []

    for x in df_ko_summary.index:
        ko_tokens_list = ko_tokens_list + \
            df_ko_summary.at[x, 'ko_description'].split(' ')

    while "" in ko_tokens_list:
        ko_tokens_list.remove("")

    count = len(set(ko_tokens_list))
    # print(count)
    # print(set(tokens_list))

    ko_token_freq_dict = dict(Counter(ko_tokens_list))
    # print(ko_token_freq_dict)

    ko_tokens_freq_table = pd.DataFrame(
        list(
            ko_token_freq_dict.items()),
        columns=[
            'tokens',
            'freq']).sort_values(
                by='freq',
        ascending=False)

#    ko_tokens_freq_table.to_excel('kotokensFreq.xlsx')
    
    #################### added single tolkens #################################
    
    tokens_freq = psql.select_df('ko_tokens_freq_mongo')
    final_st_freq = pd.merge(tokens_freq, ko_tokens_freq_table, on='tokens', how='outer')
    final_st_freq.dropna(subset=['freq_y'], inplace=True)
    final_st_freq['freq_y'] = final_st_freq['freq_y'].replace(np.NaN, 0.0)
    final_st_freq['freq_x'] = final_st_freq['freq_x'].replace(np.NaN, 0.0)
    final_st_freq['freq_x'] = final_st_freq['freq_x']+ final_st_freq['freq_y']
    del final_st_freq['freq_y']
    final_st_freq['freq_x'] = final_st_freq['freq_x'].astype(int)
    final_st_freq = final_st_freq.rename(columns={"freq_x": "freq"})
    logger_ko_score.debug("Printing the head of contents of single tokens table before merging:\n%s",final_st_freq.head())
    print("Printing the head of contents of single tokens table before merging:\n%s",final_st_freq.head())    
    
 
    if len(final_st_freq) > 0:
        psql.upsert_df(final_st_freq, 'ko_tokens_freq_mongo') 
    
    ############################  Ended single tokens ##################

    # psql.truncate_table('ko_tokens_freq_mongo')
    # psql.insert_df(ko_tokens_freq_table,'ko_tokens_freq_mongo')

def find_ko_score():

    global df_ko_summary
    global no_of_ko_tags

    # finding ngrams of
    #individual ko ####################################################

    df_ko_summary = df_ko.filter(
        ['ko_id', 'ko_description']).reset_index(drop='True')
    df_ko_summary['ko_bigram_token'] = df_ko_summary['ko_description'].apply(
        lambda x: [' '.join((a, b)) for a, b in nltk.bigrams(nltk.word_tokenize(x))])
    df_ko_summary['ko_trigram_token'] = df_ko_summary['ko_description'].apply(
        lambda x: [
            ' '.join(
                (a, b, c)) for a, b, c in nltk.trigrams(
                nltk.word_tokenize(x))])
    df_ko_summary['ko_single_tokens'] = df_ko_summary['ko_description'].apply(
        lambda x: nltk.word_tokenize(x))

    print("inside similarity")
    print(df_ko_summary.head())

    df_ko_summary['st_tags'] = ''
    df_ko_summary['bigram_tags'] = ''
    df_ko_summary['trigram_tags'] = ''
    # finding score of
    #individuals ko #########################################################

    for i in df_ko_summary.index:
        tokens_freq = 0
        count_tokens_freq = 0
        tokens_avg = 0
        bigrams_freq = 0
        count_bigrams_freq = 0
        bigrams_avg = 0
        trigrams_freq = 0
        count_trigrams_freq = 0
        trigrams_avg = 0

        tokens_list = df_ko_summary.at[i, 'ko_single_tokens']
        bigrams_list = df_ko_summary.at[i, 'ko_bigram_token']
        trigrams_list = df_ko_summary.at[i, 'ko_trigram_token']

        ##################for tokens#########################
        token_dict = dict()
        for j in tokens_list:
            # print(j)
            count_tokens_freq = count_tokens_freq + 1
            # print(ko_tokens_freq_table.loc[ko_tokens_freq_table['tokens']==j]['freq'].tolist()[0])
            #tokens_freq=tokens_freq+ token_value
            token_value = ko_tokens_freq_table.loc[ko_tokens_freq_table['tokens'] == j]['freq'].tolist()[
                0]
            token_dict[j] = token_value
            tokens_freq = tokens_freq + token_value
        if not count_tokens_freq == 0:
            tokens_avg = tokens_freq / count_tokens_freq
        else:
            tokens_avg = 0
        # print(tokens_avg)
        sorted_token_dict = {
            k: v for k,
            v in sorted(
                token_dict.items(),
                reverse=True,
                key=lambda item: item[1])}
        # print(sorted_token_dict)

        #####################for bigram#########################
        bi_dict = dict()
        for j in bigrams_list:
            # print(j)
            count_bigrams_freq = count_bigrams_freq + 1
            # print(ko_bigram_freq_table.loc[ko_bigram_freq_table['bigram']==j]['freq'].tolist()[0])
            # bigrams_freq=bigrams_freq+bigram_value
            bigram_value = ko_bigram_freq_table.loc[ko_bigram_freq_table['bigram'] == j]['freq'].tolist()[
                0]
            bi_dict[j] = bigram_value
            bigrams_freq = bigrams_freq + bigram_value
        if not count_bigrams_freq == 0:
            bigrams_avg = bigrams_freq / count_bigrams_freq
        else:
            bigrams_avg = 0
        # print(bigrams_avg)
        sorted_bi_dict = {
            k: v for k,
            v in sorted(
                bi_dict.items(),
                reverse=True,
                key=lambda item: item[1])}

        #####################for trigram#########################
        tri_dict = dict()
        for j in trigrams_list:
            # print(j)
            count_trigrams_freq = count_trigrams_freq + 1
            #loc[ko_trigram_freq_table['trigram']==j]['freq'].tolist()[0])
            # trigrams_freq=trigrams_freq+trigram_value
            trigram_value = ko_trigram_freq_table.loc[ko_trigram_freq_table['trigram'] == j]['freq'].tolist()[
                0]
            tri_dict[j] = trigram_value
            trigrams_freq = trigrams_freq + trigram_value
        if not count_trigrams_freq == 0:
            trigrams_avg = trigrams_freq / count_trigrams_freq
        else:
            trigrams_avg = 0
        # print(trigrams_avg)
        sorted_tri_dict = {
            k: v for k,
            v in sorted(
                tri_dict.items(),
                reverse=True,
                key=lambda item: item[1])}
        # print(sorted_tri_dict)
        # print(sorted_token_dict.keys())
        df_ko_summary.at[i, 'ko_score'] = round(
            (tokens_avg + bigrams_avg + trigrams_avg) / 3, 2)
        df_ko_summary.at[i, 'st_tags'] = sorted_token_dict.keys()
        df_ko_summary.at[i, 'bigram_tags'] = sorted_bi_dict.keys()
        df_ko_summary.at[i, 'trigram_tags'] = sorted_tri_dict.keys()
    logger_ko_score.debug("KO Scores done for: "+str(len(df_ko_summary))+"KO's")
    logger_ko_score.debug("List of ko and their scores are:\n%s",df_ko_summary)
    df_ko_summary['st_tags'] = df_ko_summary['st_tags'].apply(
        lambda x: ','.join([str(elem) for elem in x]))
    df_ko_summary['bigram_tags'] = df_ko_summary['bigram_tags'].apply(
        lambda x: ','.join([str(elem) for elem in x]))
    df_ko_summary['trigram_tags'] = df_ko_summary['trigram_tags'].apply(
        lambda x: ','.join([str(elem) for elem in x]))
    df_ko_tags = df_ko_summary.copy()
    df_ko_tags['KoID'] = df_ko_tags['ko_id']

    df_ko_tags['KoSingleTags'] = df_ko_tags['st_tags']
    df_ko_tags['KoBigramTags'] = df_ko_tags['bigram_tags']
    df_ko_tags['KoTrigramTags'] = df_ko_tags['trigram_tags']

    df_ko_tags = df_ko_tags.filter(
        ['KoID', 'KoSingleTags', 'KoBigramTags', 'KoTrigramTags'])
    
    df_ko_tags.columns = df_ko_tags.columns.map(str.lower)
    logger_ko_score.debug("Inserting the generated tags to ko_tags table")
    psql.upsert_df(df_ko_tags,'ko_tags')
    logger_ko_score.debug("Sorted and Inserted tags for ko's to ko_tags table. Length of table is: "+str(len(df_ko_tags))+" Contents of table are:\n%s",df_ko_tags)
    no_of_ko_tags = len(df_ko_tags)
    # if nonciap != 1:
        # df_dummy = df_ko_tags.copy()
        # df_dummy.columns = df_dummy.columns.map(str.lower)
    # psql.upsert_df(df_dummy,'ko_tags')
    
    ko_detail_table = df_ko_summary.filter(
        [
            'ko_id',
            'ko_single_tokens',
            'ko_bigram_token',
            'ko_trigram_token',
            'ko_score']).reset_index(
        drop='True')
    logger_ko_score.debug("Updating the ko_id,generated tokens and ko_score in ko_info_mongo table.")
    psql.upsert_df(ko_detail_table,'ko_info_mongo')


try:
    print("start time for program is {0}".format(datetime.now()))
    logger_ko_score.debug("Start time for the ko_score program is: "+str(datetime.now()))

    logger_ko_score.debug("Reading the contents of ko_detail_inter_mongo table")
    df_ko = common_functions.read_table_data('ko_detail_inter_mongo', psql)
    logger_ko_score.debug("Reading the ko_detail_inter_mongo table is done. The ko's are:\n%s",df_ko['Ko_id'])
                                                                                                                                      
    if nonciap == 1:
        df_ko.rename(columns = {'ko_id':'Ko_id','ko_text':'Ko_text',
                                 'summary':'Summary','app_name':'App_name','ticket_group':'Ticket_group',
                                 'ko_status':'Ko_status','publication_status':'Publication_status'},inplace=True)

    
    current_time = datetime.now()
    current_hour = current_time.hour
    current_min = current_time.minute  
   
    if not (len(df_ko) >= volume_threshold or (current_hour in range(0,24,hour_step) and current_min in range(0, min_step, 1))): 
    
        print(error_string)
        logger_ko_score.debug("ko_detail_inter_mongo table has less records than volume threshold set hence exiting the program.")
        sub=""
        mes = ""
        common_functions.send_email(sub, mes, 0, LOG_FILENAME, log_capture_string, html,psql,emailSender,emailReceiver)
        transaction(0)
        sys.exit()      
    
    if len(df_ko) > 0:
        # new and old ko separation
        inter_df = df_ko.copy()
        if 'ko_version' in inter_df.columns:
            inter_df = inter_df.filter(['Ko_id', 'Ko_text', 'Summary', 'App_name', 'Ticket_group', 'Ko_status', 'Publication_status', 'ko_version'])
        else:
            inter_df = inter_df.filter(['Ko_id', 'Ko_text', 'Summary', 'App_name', 'Ticket_group', 'Ko_status', 'Publication_status'])
        
        logger_ko_score.debug("Inserting the data into intermediate tables -> ko_detail_staging_mongo,ko_detail_history_mongo")
        # move new kos to staging table for search
        psql.upsert_df(inter_df,'ko_detail_staging_mongo')
        
        # update old ko in history table
        psql.upsert_df(inter_df,'ko_detail_history_mongo')

        ################ truncating inter table ###############################

        
        # delete all kos from inter table
        # temp = inter_df.rename(columns = {'Ko_id':'ko_id'})
        
        if nonciap !=1:
            psql.delete_df(inter_df,'ko_detail_inter_mongo',{'Ko_id'})
            
        else:
            temp = inter_df.rename(columns = {'Ko_id':'ko_id'})
            psql.delete_df(temp,'ko_detail_inter_mongo',{'ko_id'})
        logger_ko_score.debug("Data is moved to inter tables hence Truncated ko_detail_inter_mongo table")
    
    # df_ko = common_functions.read_table_data('ko_detail_history_mongo', psql)
    print("**********************")
    print("Printing the ko data:\n%s",df_ko)
    logger_ko_score.debug("Total no of Kos for tag processing "+str(len(df_ko)))
    logger_ko_score.debug("List of kos selected for tag processing:\n%s",df_ko['Ko_id'])
    no_of_feed_ko = len(df_ko)
    print("Shape of ko_detail dataframe: ",df_ko.shape)
    print("Columns of ko_detail dataframe: ",df_ko.columns)
    logger_ko_score.debug("Names of Columns present in ko detail table:%s",df_ko.columns.to_list())
    df_ko['ko_id'] = df_ko['Ko_id']
    df_ko['ko_description'] = df_ko['Summary']
    df_ko['APP_NAME'] = df_ko['App_name']
    df_ko['TICKET_GROUP'] = df_ko['Ticket_group']
    ### Combinig description and fix of KO ##
    #df_ko['ko_description']=df_ko['DESCRIPTION'].fillna("")+ " " + df_ko['FIX'].fillna("")
    df_ko = df_ko.filter(
        ['ko_id', 'ko_description', 'APP_NAME', 'TICKET_GROUP'])
    ############################################ Preprocessing ###############
    if nonciap == 1:
        sap_tcodes_df = common_functions.read_table_data('sap_tcodes_mongo',psql)
        sap_tcodes = sap_tcodes_df['sap_tcodes'].tolist()
        print(sap_tcodes)
        df_ko['matches'] = df_ko['ko_description'].apply(lambda x: [i for i in sap_tcodes if i in x])
        df_ko['tcodes_string'] = df_ko['matches'].agg(lambda x: ' '.join(map(str, x)))
    
 
    
    if nonciap != 1:
        df_ko.dropna(inplace=True)
    else:
        for i in df_ko.index:
            df_ko.at[i,'ko_description'] = str(df_ko.at[i,'ko_description'])+ ' ' +str(df_ko.at[i,'tcodes_string'])
        
        
    if multi_language==1:
        df_ko['language']=df_ko['ko_description'].apply(multilingual.lang_detection)

    else:
        df_ko['language']=default_lang
    df_ko["ko_description"] = df_ko.apply(lambda x:multilingual.process_text(config,x.language, x.ko_description),axis=1)

    df_ko["ko_description"] = df_ko.apply(lambda x:multilingual.oneliner_for_processing(load_lemma_model,x.language, x.ko_description),axis=1)
    
    df_ko['ko_description'] = df_ko['ko_description'].str.lower()
    df_ko_summary = df_ko.filter(['ko_id', 'ko_description']).reset_index(drop='True')
    logger_ko_score.debug("Preprocessing done for ko tags. Preprocessed description text is:\n%s",df_ko_summary)
    print("Printing the preprocessed ko_description with id:\n%s",df_ko_summary.shape)

    # creating thread
    #t1 = threading.Thread(target=find_similar_ko)
    t2 = threading.Thread(target=find_dataset_freq)
    t3 = threading.Thread(target=find_ko_score)

    t2.start()
    t2.join()
    t3.start()
    t3.join()

    print("end time for program is {0}".format(datetime.now()))
    logger_ko_score.debug("end time for ko tag's creation"+ datetime.strftime(
        datetime.now(), '%Y-%m-%d %H:%M:%S'))
    # both threads completely executed
    print("Excecution of both the threads is Done!")

except Exception as e:
    logger_ko_score.error(
        "Exception occured in KO tags processing and error is---> "+ str(e))
    error_string = str(e)
    
    exception_type, exception_object, exception_traceback = sys.exc_info()
    line_number = exception_traceback.tb_lineno
    logger_ko_score.error("exception_type for logger_ko_score script: "+ str(exception_type))
    logger_ko_score.error("line_number for logger_ko_score script : "+ str(line_number))  
    
    print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
    logger_ko_score.debug("We have encountered an exception so,ko's processed for finding ko tags : 0")
    sub = 'KO Tags Process'
    mes = 'PFA of log file'
    common_functions.send_email(sub, mes, 1, LOG_FILENAME, log_capture_string, html,psql,emailSender,emailReceiver)
    transaction(1)
    logger_ko_score.debug("ko score run ended with exception at "+ datetime.strftime(
        datetime.now(), '%Y-%m-%d %H:%M:%S'))
    sys.exit()
else:
    logger_ko_score.debug("ko score run ended at "+ datetime.strftime(
        datetime.now(), '%Y-%m-%d %H:%M:%S'))
    sub = "KO Tags Process"
    mes = ''
    common_functions.send_email(sub, mes, 0, LOG_FILENAME, log_capture_string, html,psql,emailSender,emailReceiver)
    transaction(0)

# =========================================================================================================================
# File Name     : ko_version_update.py
# -------------------------------------------------------------------------------------------------------------------------
# Purpose       : Purpose of this script is to update ko version in ticket_data and ticket_data_history tables.
# Author        : Harinadh Reddy
# Co-Author     : 
# Creation Date : 11-NOV-2022
# Usage         : 'python ' + commonsFolderPath + 'ko_version_update.py --accountName ' + accountName
# History       :
# -------------------------------------------------------------------------------------------------------------------------
# Date          | Author                       | Co-Author                    | Remark
# 11-Nov-2022   | Harinadh Reddy               |                              | Initial Release
# =========================================================================================================================
###########################################################################################################################
# Import required Module / Packages
###########################################################################################################################

import warnings
from datetime import datetime
import sys, getopt
import os
import requests
import json
import configparser
import time
from common_module import  common_functions
from common_module.DatabaseFunctions import DatabaseFunctions

import pandas as pd
warnings.filterwarnings("ignore")
# from common_module.DatabaseFunctions import DatabaseFunctions


################################ Created Empty strings ##############################
error_string = ''
runid = 0
logger_ko_version = ''
runid = datetime.now().strftime('%Y%m%d%H%M%S')


################################ Arguments  ###########################################
# Arguments
argumentList = sys.argv[1:]
 
# Options
short_options = "a:"
 
# Long options
long_options = ["accountName ="]
 
try:
    # Parsing argument
    arguments, values = getopt.getopt(argumentList, short_options, long_options)

    # checking each argument
    for currentArgument, currentValue in arguments:
            
        if currentArgument in ("-a","--accountName"):
            print ("accountName: ", currentValue)
            accountName=currentValue
        
except getopt.error as err:
    # output error, and return with an error code
    print (str(err))
    sys.exit()

# accountName = 'WB'

############################### Reading config File  ################################

print('accountName: ', accountName)

try:

    config = common_functions.get_config(accountName)
    
    dbDetail = common_functions.get_dbdetail(config)
    dbName = dbDetail['dbName']
    host = dbDetail['host']
    user = dbDetail['user']
    password = dbDetail['password']
    port = dbDetail['port']
    schema = dbDetail['schema']  

    path = os.getcwd()    

    LOG_DIR = os.path.join(path, accountName, "ko_version_logs")
    if not os.path.exists(LOG_DIR):
        os.makedirs(LOG_DIR)
    LOG_FILENAME = os.path.join(LOG_DIR, f"{accountName}_koVersionUpdate_ikon2_logger_{runid}.log")

    print(LOG_FILENAME)
    logger_inc_score, log_capture_string = common_functions.getLogger(LOG_FILENAME,accountName)

except Exception as e:
    print ("Error occured while reading the config or setting up logger in ko_version: " + str(e))
    

    print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)


    sys.exit()


############################## log file writing  ########################################
def print_log():
    with open(LOG_FILENAME, 'a+') as f:
        f.write(logger_ko_version)

############################## Connecting to DB #####################################
try:  
    psql = DatabaseFunctions(host, user, password, port,dbName,schema, config= config) 
    #account_processes_db = common_functions.database_account_process()  ############ Need to check
except Exception as e:
    print(
        "Could not connected to postgresql in ko_version file and error is--->" +
        str(e))
    logger_inc_score.error(
        "ko_version process failed due to postgresql db connectivity issue")
    sys.exit()
else:
    print("Connected successfully!!!")






############################ Reading ticket data proposal history ###################
try:
    logger_ko_version = logger_ko_version+str("ko version process is started")

    total_his_data = psql.select_df('ticket_data_history')
    total_his_data = total_his_data.filter(['ticketid', 'relevperc', 'usageperc'])
    total_his_data['version'] = '1.0'
    
    logger_ko_version = logger_ko_version+str("Total records in ticket_data_history: ")+ str(len(total_his_data))+"\n"
    
    total_his_data.dropna(subset = ['relevperc'],inplace=True)
    
    total_his_data = total_his_data[total_his_data['relevperc'] != '']
    
    relevperc_df = common_functions.explode(total_his_data.assign(relevperc = total_his_data.relevperc.str.split(';')), 'relevperc')
    relevperc_df[['ko_id', 'relevperc']] = relevperc_df['relevperc'].str.split(':', 1, expand=True)
    relevperc_df['relevperc'] = relevperc_df['ko_id'] + ':' + relevperc_df['version'] + ':' + relevperc_df['relevperc']
    
    relevperc_df['relevperc'] = relevperc_df['relevperc'].astype(str)

    relevperc_df = relevperc_df.groupby('ticketid')['relevperc'].apply(';'.join).reset_index()
    relevperc_df = relevperc_df.filter(['ticketid', 'relevperc'])

    
    
    usageperc_relevperc_df = common_functions.explode(total_his_data.assign(usageperc = total_his_data.usageperc.str.split(';')), 'usageperc')
    usageperc_relevperc_df[['ko_id', 'usageperc']] = usageperc_relevperc_df['usageperc'].str.split(':', 1, expand=True)
    usageperc_relevperc_df['usageperc'] = usageperc_relevperc_df['ko_id'] + ':' + usageperc_relevperc_df['version'] + ':' + usageperc_relevperc_df['usageperc']
    usageperc_relevperc_df['usageperc'] = usageperc_relevperc_df['usageperc'].astype(str)
    usageperc_relevperc_df = usageperc_relevperc_df.groupby('ticketid')['usageperc'].apply(';'.join).reset_index()

    usageperc_relevperc_df = usageperc_relevperc_df.filter(['ticketid', 'usageperc'])


    df_final = pd.merge(relevperc_df, usageperc_relevperc_df, on='ticketid')


    psql.update_df(df_final, 'ticket_data_history', {'ticketid'})
    logger_ko_version = logger_ko_version+str("Total records updated in ticket_data_history is: ")+ str(len(usageperc_relevperc_df))+"\n"

    his_data = psql.select_df('ticket_data')
    temp_list = his_data['ticketid'].to_list()
    df_final_1 = df_final[df_final['ticketid'].isin(temp_list)]

    psql.update_df(df_final_1, 'ticket_data', {'ticketid'})
    
    logger_ko_version = logger_ko_version+str("Total records updated in ticket_data is: ")+ str(len(usageperc_relevperc_df))+"\n"

    logger_ko_version = logger_ko_version+str("ko version run ended Successfully at")+ datetime.strftime(datetime.now(),"%Y-%m-%d %H:%M:%S")+"\n"

except Exception as e: 
    logger_ko_version = logger_ko_version+str(["Error ocurred in script",
                            "Line No: " + str(sys.exc_info()[2].tb_lineno),
                            "Exception type: " + str(sys.exc_info()[0]),
                            "Error: " + str(e)])+"\n"
    error_string = error_string + str(e)
    logger_ko_version = logger_ko_version+str("ko version run ended at ")+ datetime.strftime(datetime.now(),"%Y-%m-%d %H:%M:%S")+"\n"
    print_log()
    sys.exit()

else:
    logger_ko_version = logger_ko_version+str("ko version run ENDED at ")+ datetime.strftime(datetime.now(),"%Y-%m-%d %H:%M:%S")+"\n"
    print_log()

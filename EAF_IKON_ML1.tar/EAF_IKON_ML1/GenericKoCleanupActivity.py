# =========================================================================================================================
# File Name     : ko_version_update.py
# -------------------------------------------------------------------------------------------------------------------------
# Purpose       : Purpose of this script is to update ko version in ticket_data and ticket_data_history tables.
# Author        : Harinadh Reddy
# Co-Author     : 
# Creation Date : 11-NOV-2022
# Usage         : 'python ' + commonsFolderPath + 'ko_version_update.py --accountName ' + accountName
# History       :
# -------------------------------------------------------------------------------------------------------------------------
# Date          | Author                       | Co-Author                    | Remark
# 11-Nov-2022   | Harinadh Reddy               |                              | Initial Release
# =========================================================================================================================
###########################################################################################################################
# Import required Module / Packages
###########################################################################################################################

import warnings
from datetime import datetime
import sys
import os
import requests
import json
import sys, getopt
import configparser
import time
from common_module import common_functions
import pandas as pd
warnings.filterwarnings("ignore")
# from common_module.DatabaseFunctions import DatabaseFunctions
from common_module.DatabaseFunctions_main import DatabaseFunctions


################################ Created Empty strings ##############################
error_string = ''
runid = 0
ko_cleanup = ''
runid = datetime.now().strftime('%Y%m%d%H%M%S')


################################ Arguments  ###########################################
# Arguments
argumentList = sys.argv[1:]

# Options
short_options = "a:p:"

# Long options
long_options = ["accountName=","processName="]

accountName = ''
processName = ''


try:
    # Parsing argument
    arguments, values = getopt.getopt(argumentList, short_options, long_options)
    # checking each argument
    for currentArgument, currentValue in arguments:
        if currentArgument in ("-a","--accountName"):
            print ("accountName: ", currentValue)
            accountName=currentValue
        elif currentArgument in ("-p","--processName"):
            print ("processName: ", currentValue)
            processName=currentValue
except getopt.error as err:
    # output error, and return with an error code
    print (str(err))
    sys.exit()

if( accountName == '' or processName == ''):
    print("Required arguments missing. List of required arguments: accountName, processName")
    sys.exit()

# accountName = 'FDL'
# processName = 'ALL'
############################### Reading config File  ################################

try:

    config = common_functions.get_config(accountName)
    
    dbDetail = common_functions.get_dbdetail(config)
    dbName = dbDetail['dbName']
    host = dbDetail['host']
    user = dbDetail['user']
    password = dbDetail['password']
    port = dbDetail['port']
    schema = dbDetail['schema']  

    path = os.getcwd()    

    LOG_DIR = os.path.join(path, accountName, "ko_version_logs")
    if not os.path.exists(LOG_DIR):
        os.makedirs(LOG_DIR)
    LOG_FILENAME = os.path.join(LOG_DIR, "ikon2_logger" + runid + ".log")

    print(LOG_FILENAME)
    logger_inc_score, log_capture_string = common_functions.getLogger(LOG_FILENAME)

except Exception as e:
    print ("Error occured while reading the config or setting up logger in ko_version: " + str(e))
    

    print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)


    sys.exit()


############################## log file writing  ########################################
def print_log():
    with open(LOG_FILENAME, 'a+') as f:
        f.write(ko_cleanup)

############################## Connecting to DB #####################################
try:  
    psql = DatabaseFunctions(host, user, password, port,dbName,schema, config= config) 
    #account_processes_db = common_functions.database_account_process()  ############ Need to check
except Exception as e:
    print(
        "Could not connected to postgresql in ko_version file and error is--->" +
        str(e))
    logger_inc_score.error(
        "ko_version process failed due to postgresql db connectivity issue")
    sys.exit()
else:
    print("Connected successfully!!!")

############################ Reading ticket data proposal history ###################
try:
    
    process_list = ['KG', 'GS', 'ALL']
    

    process_list_new = []
    
    if processName in ['KG','KOG','ALL']:
    
        ko_enabled = psql.select_df('account_features')
    
        ko_enabled_flag = list(ko_enabled['autokoenabled'])   # autokoenabled
        ko_enabled_flag = int(ko_enabled_flag[0])
        
        if ko_enabled_flag != 1:
            
            if processName == 'KOG':
                process_list_new.append('KOG')
            else:
                process_list_new.append('KG')


    if processName in ['GS','ALL']:
        
        ko_enabled = psql.select_df('account_info_detail')
    
        ko_enabled_flag = list(ko_enabled['isgeneric'])
        ko_enabled_flag = int(ko_enabled_flag[0])
        
        if ko_enabled_flag != 1:
            process_list_new.append('GS')
            

    
    if len(process_list_new) == 0:
        logger_autoko = logger_autoko+str("In account_features and account_info_detail tables flags are enabled so run ended at ")+ datetime.strftime(datetime.now(),"%Y-%m-%d %H:%M:%S")+"\n"
        print_log()
        sys.exit() 
        

    psql.truncate_table('ko_auto_suggestion_mongo')
    ko_cleanup = ko_cleanup+str("ko version process is started")

    total_his_data = psql.select_df('ticket_data_history')
    
    total_his_auto_ko = total_his_data[['ticketid','autocreatedko']]
    total_his_auto_ko = total_his_auto_ko.fillna('')
    
    total_his_auto_ko = total_his_auto_ko[total_his_auto_ko['autocreatedko'] != '']
    
    if len(total_his_auto_ko) > 0:
        total_his_auto_ko['autocreatedko'] = ''
        psql.update_df(total_his_auto_ko, 'ticket_data', {'ticketid'})
        psql.update_df(total_his_auto_ko, 'ticket_data_history', {'ticketid'})      
    
    
    total_his_data = total_his_data.filter(['ticketid', 'relevperc', 'usageperc'])
   #  total_his_data['version'] = '1.0'
    
    ko_cleanup = ko_cleanup+str("Total records in ticket_data_history: ")+ str(len(total_his_data))+"\n"
    
    total_his_data.dropna(subset = ['relevperc'],inplace=True)
    total_his_data = total_his_data[total_his_data['relevperc'] != '']
    his_data = common_functions.explode(total_his_data.assign(relevperc = total_his_data.relevperc.str.split(';')), 'relevperc')
    
    his_data[['ko_id', 'relevperc']] = his_data['relevperc'].str.split(':', 1, expand=True)
    
    his_data_1 = pd.DataFrame()
    if 'KOG' not in process_list_new:
        
        his_data['ko_type'] = his_data['ko_id'].str.slice(0, 2)
        his_data_1 = his_data[his_data['ko_type'].isin(process_list_new)]
        
    
        
    if 'KOG' in process_list_new:
        
        his_data['ko_type'] = his_data['ko_id'].str.slice(0, 3)
        his_data = his_data[his_data['ko_type'].isin(process_list_new)]
        his_data= pd.concat([his_data, his_data_1], axis=0).reset_index(drop=True)
    else:
        his_data = his_data_1
    
        
    generic_koid_list = his_data['ko_id'].to_list()

    
    if len(generic_koid_list) > 0:
        his_data = his_data[['ticketid', 'ko_type']]
        
        his_data.drop_duplicates(subset='ticketid', inplace=True)
        his_data['relevperc'] = ''
        his_data['usageperc'] = ''
        his_data = his_data[['ticketid', 'relevperc', 'usageperc']]
        psql.update_df(his_data, 'ticket_data_history', {'ticketid'})
        
        ko_cleanup = ko_cleanup+str("Total records updated in ticket_data_history is: ")+ str(len(his_data))+"\n"
        
        ticket_data = psql.select_df('ticket_data')
        temp_list = ticket_data['ticketid'].to_list()
        his_data = his_data[his_data['ticketid'].isin(temp_list)]


        if len(his_data) > 0: 
            psql.update_df(his_data, 'ticket_data', {'ticketid'})
            psql.update_df(his_data, 'ticket_data_history', {'ticketid'})
        
        
        psql.truncate_table('inc_ko_similarity_mongo')
        
        
        ko_link_df = psql.select_df('incident_ko_link_mongo')
        ko_link_df = ko_link_df[ko_link_df['ko_id'].isin(generic_koid_list)]
        
        if len(ko_link_df) > 0:
            psql.delete_df(ko_link_df, 'inc_ko_similarity_mongo', {'ko_id'})
            
            
        ko_info_his = psql.select_df('ko_info', 'koid', generic_koid_list)   #list(set(list(ko_inter['ko_id'])))
        
        psql.delete_df(ko_info_his, 'ko_info',{'koid'})
        if len(ko_info_his) > 0:
        
            ko_info = ko_info_his[['koserialno', 'koid', 'ko_version']]
            psql.delete_df(ko_info, 'ko_usage_history',{'koserialno'})
            psql.delete_df(ko_info, 'ko_usage',{'koserialno'})
    


    ko_cleanup = ko_cleanup+str("ko cleanup run ended Successfully at")+ datetime.strftime(datetime.now(),"%Y-%m-%d %H:%M:%S")+"\n"

except Exception as e: 
    ko_cleanup = ko_cleanup+str(["Error ocurred in script",
                            "Line No: " + str(sys.exc_info()[2].tb_lineno),
                            "Exception type: " + str(sys.exc_info()[0]),
                            "Error: " + str(e)])+"\n"
    error_string = error_string + str(e)
    ko_cleanup = ko_cleanup+str("ko cleanup run ended at ")+ datetime.strftime(datetime.now(),"%Y-%m-%d %H:%M:%S")+"\n"
    print_log()
    sys.exit()

else:
    ko_cleanup = ko_cleanup+str("ko version run ENDED at ")+ datetime.strftime(datetime.now(),"%Y-%m-%d %H:%M:%S")+"\n"
    print_log()

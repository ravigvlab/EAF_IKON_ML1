import warnings
import re
import nltk
import math
import configparser
import os
import sys
from DatabaseFunctions import DatabaseFunctions
from datetime import datetime
import getopt

from azure.keyvault.secrets import SecretClient
from azure.identity import ClientSecretCredential
import requests
from ast import literal_eval

from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from collections import Counter
import logging
from io import StringIO
import numpy as np
import truecase
from stop_words import get_stop_words
import pandas as pd
import json
warnings.filterwarnings("ignore")
import string
import simplemma
from nltk.tokenize.toktok import ToktokTokenizer
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.stem import SnowballStemmer
import ast
warnings.filterwarnings("ignore")

#########  function declarations start ####
def transaction(psql, feed_name, acticate=0, runid=0, start_time="", input_count=0, processed_count=0, iserror=0):
    global run_transaction_flag
    if(run_transaction_flag == 1):
        if( acticate == 1):
            df = pd.DataFrame(columns=['run_id', 'active', 'feed_name'])
            df = df.append(pd.Series([runid, 1, feed_name], index=df.columns ), ignore_index=True)
        else:
            status = ''
            if iserror == 0:
                status = "success"
            else:
                status = "failed"

            if start_time == "":
                start_time = datetime.now()

            df = pd.DataFrame(columns=['run_id', 'feed_name', 'active', 'start_time', 'end_time', 'status', 'inc_in_feed', 'data_processed_count'])
            df = df.append(pd.Series([runid, feed_name, 0, datetime.strftime(start_time, "%Y-%m-%d %H:%M:%S"), datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S"), status, input_count, processed_count], index=df.columns ), ignore_index=True)

        psql.upsert_df(df, 'mongo_run_transactions')

def send_email(sub1, mes1, log, log_filename, logger_string, html_string, psql, sender, receivers):

    """This is a generic function for sending email
       Parameters: Subject, body of email, log filename, log flag, logger_string
       Returns : None
    """
    global send_mail_flag
    if(send_mail_flag == 1):
        # Email Details
        if( sender == ""):
            sender = "natools_ikon.in@capgemini.com"
        if(receivers):
            receivers = "amstools.monitoring@capgemini.com"

        # Create the body of the message (a plain-text and an HTML version).
        html = """            """ + mes1 + html_string
        text = ""
        attach = 0
        if log == 0:
            sub1 = sub1 + " Failure!"
            attach = 1

            with open(log_filename, 'r') as f:
                text=f.read().replace("'","\\'").replace('"','\\"')
        else:
            sub1 = sub1 + " Success!"

        df=pd.DataFrame(columns=['account_id', 'mail_from', 'mail_to', 'mail_subject', 'mail_message','mail_attachment_data', 'isattached'])
        df = df.append(pd.Series([1, sender, receivers, sub1, html, text, attach], index=df.columns ), ignore_index=True)
        psql.insert_df(df,'mailing_info')



def lemmatize_sentence(sentence):
    """
        This function is used to remove stopwordws and
        lemmatize a sentence.
        Input - Text string
        Output - Lemmatized text
    """
    
    # function to remove stop words and lemmatize
    
    token_words = word_tokenize(sentence)
    token_words = [word for word in token_words if word not in stop_words]
    stem_sentence = []
    for word in token_words:
        stem_sentence.append(lemmatizer.lemmatize(word))
    return " ".join(stem_sentence)



def truecasing(text):
    """
        This function is used to change the case of the text to truecase.
        Input - Text string
        Output - Text string with true case
    """
    
    return truecase.get_true_case(text)

def explode(df, lst_cols, fill_value='', preserve_index=False):
    """
        This function explodes the dataframe into multiple rows.
        Input - Dataframe and column on which to explode
        Output - Exploded dataframe
    """
    # make sure `lst_cols` is list-alike
    if (lst_cols is not None and len(lst_cols) > 0 and not isinstance(
            lst_cols, (list, tuple, np.ndarray, pd.Series))):
        lst_cols = [lst_cols]
    # all columns except `lst_cols`
    idx_cols = df.columns.difference(lst_cols)
    # calculate lengths of lists
    lens = df[lst_cols[0]].str.len().fillna(0)
    # preserve original index values
    idx = np.repeat(df.index.values, lens)
    # create "exploded" DF
    res = (pd.DataFrame({
        col: np.repeat(df[col].values, lens)
        for col in idx_cols},
        index=idx)
        .assign(**{col: np.concatenate(df.loc[lens > 0, col].values)
                   for col in lst_cols}))
    # append those rows that have empty lists
    if (lens == 0).any():
        # at least one list in cells is empty
        res = (res.append(df.loc[lens == 0, idx_cols], sort=False)
               .fillna(fill_value))
    # revert the original index order
    res = res.sort_index()
    # reset index if requested
    if not preserve_index:
        res = res.reset_index(drop=True)
    return res


def validateJSON(jsonData):
    """
        This function returns whether the input string is valid json or not.
        Input - jsonString
        Output - True/False
    """
    try:
        json.loads(jsonData)
    except ValueError:
        return False
    return True

def read_table_data(table_name,psql):
    """ Read from Postgresql and Store into DataFrame """
    
    df = psql.select_df(table_name)
    return df

def getKOIds(asg, apn, df_ko, AGfilter, ANfilter, nonciap, processGenericKo=0, mapping_table='', mapping_df=''):
    
    if nonciap == 1:
        
        ko_list1 = []
        ko_list = []
        try:
            if AGfilter==1 and ANfilter==1:
                ko_list1.append(df_ko.loc[(df_ko['TICKET_GROUP'] == asg) & (df_ko['APP_NAME'] == apn) & (df_ko['Module_name'] == '')]['ko_id'].tolist())
            elif AGfilter==1 and ANfilter==0:
                ko_list1.append(df_ko.loc[(df_ko['TICKET_GROUP'] == asg) & (df_ko['Module_name'] == '') & ((df_ko['APP_NAME'] == apn) | (df_ko['APP_NAME'] == ''))]['ko_id'].tolist())
            elif AGfilter==0 and ANfilter==1:
                ko_list1.append(df_ko.loc[(df_ko['APP_NAME'] == apn) & (df_ko['Module_name'] == '') & ((df_ko['TICKET_GROUP'] == asg) | (df_ko['TICKET_GROUP'] == '')) ]['ko_id'].tolist())
            else:
                ko_list1.append(df_ko.loc[(df_ko['Module_name'] == '') & ((df_ko['TICKET_GROUP'] == asg) | (df_ko['TICKET_GROUP'] == '')) & 
                                        ((df_ko['APP_NAME'] == apn) | (df_ko['APP_NAME'] == ''))]['ko_id'].tolist())
                
            if len(ko_list1[0])>0:
                ko_list = [i for i in ko_list1[0]]
            print(len(ko_list))
            
            if processGenericKo == 1:
                module_name=''
                if (asg in mapping_table['assignmentGroup'].unique().tolist()) and (apn in mapping_table['applicationName'].unique().tolist()):
                    module_name = str(mapping_table.loc[(mapping_table['assignmentGroup'] == asg) & (mapping_table['applicationName'] == apn)]['Module_name'].iloc[0]).strip()
                    print(module_name)
                    for i in df_ko.index:
                        if (str(df_ko.at[i,'Module_name']) == module_name) and (str(df_ko.at[i,'Module_name']) != ''):
                            ko_list.append(df_ko.at[i,'ko_id'])

            ############ This is for cloning Process #################
            for index,item in enumerate(ko_list):
                if len(mapping_df.loc[mapping_df['generic_id'] == item]) > 0:
                    print(item)
                    ko_list[index] = mapping_df.loc[mapping_df['generic_id'] == item]['acc_ko_id'].tolist()[0]
            ############ This is for cloning Process #################
            ko_list = list(set(ko_list))
            
            return ko_list
        except Exception as e:
            print('error is '+str(e))
            return None

    else:
    
        ko_list1 = []
        try:

            if asg == "" and apn == "":
                ko_list1.append(df_ko["ko_id"].tolist())

            elif AGfilter == 1 and ANfilter == 1:
                ko_list1.append(
                    df_ko.loc[
                        ((asg == "") or (df_ko["TICKET_GROUP"] == asg))
                        & ((apn == "") or (df_ko["APP_NAME"] == apn))
                    ]["ko_id"].tolist()
                )
            elif AGfilter == 1 and ANfilter == 0:
                ko_list1.append(
                    df_ko.loc[
                        ((asg == "") or (df_ko["TICKET_GROUP"] == asg))
                        & (
                            (apn == "")
                            or ((df_ko["APP_NAME"] == apn) | (df_ko["APP_NAME"] == ""))
                        )
                    ]["ko_id"].tolist()
                )
            elif AGfilter == 0 and ANfilter == 1:
                ko_list1.append(
                    df_ko.loc[
                        (
                            (asg == "")
                            or (
                                (df_ko["TICKET_GROUP"] == asg)
                                | (df_ko["TICKET_GROUP"] == "")
                            )
                        )
                        & ((apn == "") or (df_ko["APP_NAME"] == apn))
                    ]["ko_id"].tolist()
                )
            else:
                ko_list1.append(
                    df_ko.loc[
                        (
                            (asg == "")
                            or (
                                (df_ko["TICKET_GROUP"] == asg)
                                | (df_ko["TICKET_GROUP"] == "")
                            )
                        )
                        & (
                            (apn == "")
                            or ((df_ko["APP_NAME"] == apn) | (df_ko["APP_NAME"] == ""))
                        )
                    ]["ko_id"].tolist()
                )

            return ko_list1[0]
            
        except Exception as e:
            print("error is " + str(e))
            print(
                "Error inside function getKOIds line {}".format(
                    sys.exc_info()[-1].tb_lineno
                ),
                type(e).__name__,
                e,
            )
            return None


def get_inc_ids(asg, apn, df_closed, AGfilter, ANfilter, nonciap):

    if nonciap == 1:
        inc_list = []
        try:
            if AGfilter==1 and ANfilter==1:
                inc_list.append(df_closed.loc[(df_closed['Assigned_Group'] == asg) & (
                    df_closed['App_Name'] == apn)]['incident_id'].tolist())
            elif AGfilter==1 and ANfilter==0:
                inc_list.append(df_closed.loc[(df_closed['Assigned_Group'] == asg)]['incident_id'].tolist())
            elif AGfilter==0 and ANfilter==1:
                inc_list.append(df_closed.loc[(df_closed['App_Name'] == apn)]['incident_id'].tolist())
            else:
                inc_list.append(df_closed['incident_id'].tolist())

            return inc_list[0]
        except Exception:
            return None
            
    else:
    
        inc_list = []
        try:
            
            if( asg == '' and apn == ''):
                    inc_list.append(df_closed['incident_id'].tolist())


            elif AGfilter == 1 and ANfilter == 1 :  
                inc_list.append(df_closed.loc[  ((asg == '') or (df_closed['Assigned_Group'] == asg)) 
                                                & 
                                                ((apn == '') or (df_closed['App_Name'] == apn))]['incident_id'].tolist())     # 'incident_id'
            elif AGfilter == 1 and ANfilter == 0:
                inc_list.append(df_closed.loc[  ((asg == '') or (df_closed['Assigned_Group'] == asg)) 
                                                & 
                                                ((apn == '') or ((df_closed['App_Name'] == apn) | (df_closed['App_Name'] == '')))]['incident_id'].tolist())
            elif AGfilter == 0 and ANfilter == 1:
                inc_list.append(df_closed.loc[  ((asg == '') or ((df_closed['Assigned_Group'] == asg) | (df_closed['Assigned_Group'] == ''))) 
                                                & 
                                                ((apn == '') or (df_closed['App_Name'] == apn))]['incident_id'].tolist())
            else:
                inc_list.append(df_closed.loc[  ((asg == '') or ((df_closed['Assigned_Group'] == asg) | (df_closed['Assigned_Group'] == ''))) 
                                                &
                                                ((apn == '') or ((df_closed['App_Name'] == apn) | (df_closed['App_Name'] == '')))]['incident_id'].tolist())

            return inc_list[0]
        except Exception as e:
            print(e)

            return None

  
def update_mysql(table, df, psql):
    
    global logger_inc_ko_link
    
    df1 = df.rename(columns = {'incident_id':'TicketID','most_similar_inc':'SimilarIncidents'})
    df1.columns = df1.columns.map(str.lower)
    
    psql.update_df(df1,table,{'ticketid'})
    
class ScriptNameFilter(logging.Filter):
    def __init__(self, accountName):
        super().__init__()
        self.accountName = accountName

    def filter(self, record):
        record.accountName = self.accountName
        return True
def getLogger(LOG_FILENAME,accountName=None):
    for handler in logging.root.handlers[:]:
        logging.root.removeHandler(handler)
    log_format = '%(asctime)s - %(levelname)s - %(message)s'
    if accountName:
        log_format=f'%(asctime)s - %(levelname)s - {accountName} - %(message)s'
    logging.basicConfig(filename=LOG_FILENAME,
                        #format = '%(asctime)s - %(accountName)s - %(levelname)s - %(message)s',
                        format = log_format,
                        filemode='w',
                        level=logging.DEBUG)

    #Creating an object
    logger=logging.getLogger()
    
    if accountName:
        logger.addFilter(ScriptNameFilter(accountName))

    ### Setup the console handler with a StringIO object
    log_capture_string = StringIO()
    ch = logging.StreamHandler(log_capture_string)
    ch.setLevel(logging.DEBUG)

    ### Optionally add a formatter
    #formatter = logging.Formatter('%(asctime)s - %(accountName)s - %(levelname)s - %(message)s')
    formatter = logging.Formatter(log_format)
    ch.setFormatter(formatter)

    ### Add the console handler to the logger
    logger.addHandler(ch)

    return logger,log_capture_string    
def database_account_process():
    try:
        config_account_process = get_config()

        host_name = config_account_process.get('DatabaseSection', 'database.host')
        db_name = config_account_process.get('DatabaseSection', 'database.dbname')
        user_id = config_account_process.get('DatabaseSection', 'database.user')
        pwd = config_account_process.get('DatabaseSection', 'database.password')
        port_no = int(config_account_process.get('DatabaseSection', 'database.port'))
        schema = config_account_process.get('DatabaseSection', 'database.schema')
        if int(config_account_process.get('AWSSection', 'API.proposal')) == 1:
            try:
                token =config_account_process.get('AWSSection', 'API.token')
                url = config_account_process.get('AWSSection', 'API.url')
                tenentUserName = config_account_process.get('DatabaseSection', 'database.user')
                tenentPasword = config_account_process.get('DatabaseSection', 'database.password')
                url_username = url+'key='+str(tenentUserName)
                url_Pasword = url+'key='+str(tenentPasword)
                payload_header = {"Content-Type":"application/json", "Authorization": "Bearer "+str(token)}
                response = requests.get(url = url_username, headers =payload_header)
                if response.status_code == 200 or response.status_code == 201:
                    print("response status is ", str(response.status_code))
                else:
                    print("response status is ", str(response.status_code))
                validation_result = AwsResponseValidation(response.content)
                user_id = validation_result[1]
                pwd = validation_result[0]
                
            except Exception as e:
                print(e)
                raise Exception("Unable to get the DB detail from AWSkeyManager in common function")
        else:
            user_id = config_account_process.get('DatabaseSection', 'database.user')
            pwd = config_account_process.get('DatabaseSection', 'database.password')
        psql = DatabaseFunctions(host_name, user_id, pwd, port_no,db_name,schema)

        return psql
    except Exception as e:
        print("Not able to connect thr account process database, please check the connection -->" + str(e))
        sys.exit()


def account_process_insert(account_processes_db, accountName, type_name):
    if scriptTrigger:
        dict_account_processes_insert = pd.DataFrame({'createdtime':[datetime.now()],'tenant':[accountName], 'processed':[0],'type':[type_name]})
        account_processes_db.insert_df(dict_account_processes_insert, 'ikon_account_processes')
    return


def get_common_args(argumentList):
    # Options
    short_options = "a:"

    # Long options
    long_options = ["accountName="]

    accountName = ''

    args_list = []

    try:
        # Parsing argument
        arguments, values = getopt.getopt(argumentList, short_options, long_options)

        # checking each argument
        for currentArgument, currentValue in arguments:

            if currentArgument in ("-a","--accountName"):
                print ("accountName: ", currentValue)
                accountName = currentValue

    except getopt.error as err:
        # output error, and return with an error code
        print (str(err))
        sys.exit()

    if( accountName == '' ):
        print("Required arguments missing. List of required arguments: accountName")
        sys.exit()

    args_list = [accountName]

    return args_list

 
# def get_config(accountName=""):
#     #config_Db = 1
#     config = configparser.RawConfigParser()
    
#     if (os.getenv('IKON_CONFIG_HOME')):
#         configFile = os.path.join(os.getenv('IKON_CONFIG_HOME'), "CommonConfigFile.properties")
#     else:
#         configFile = os.path.join(os.getcwd(), "conf", "CommonConfigFile.properties")
#     config.read(configFile)
#     config_Db = int(config.get('GenericSection', 'conf.Db'))
    
#     if config_Db == 1 and accountName != "":
#         dbName = config.get('DatabaseSection', 'database.dbname')
#         host = config.get('DatabaseSection', 'database.host')
#         port = config.get('DatabaseSection', 'database.port')
#         schema = config.get('DatabaseSection', 'database.schema')
#         user = config.get('DatabaseSection', 'database.user')
#         password = config.get('DatabaseSection', 'database.password')
    
#         psql = DatabaseFunctions(host, user, password, port,dbName,schema)
#         # conf_common = psql.select_df('common_config')
#         # conf_account = psql.select_df('account_config', 'account_name', [accountName])
#         # nan_value = float("NaN")
#         # conf_account.replace("", nan_value, inplace=True)
#         # conf_account.dropna(how='all', axis=1, inplace=True)

#         # account_columns = []
#         # common_columns = []

#         # for cal in conf_common.columns:
#             # if cal in conf_account.columns:
#                 # account_columns.append(cal)
#             # else:
#                 # common_columns.append(cal)

#         # conf_final = pd.concat([conf_account[account_columns], conf_common[common_columns]], axis=1, join='outer')
#         # Initialize the configparser object
#         conf_final = psql.select_df('common_config', 'account_name', [accountName])
#         conf_final = conf_final.reset_index(drop=True)
#         conf_final = conf_final.drop(['account_name'], axis=1)
#         config = configparser.ConfigParser()
#         for section_name in conf_final.columns:
#             # print('=========== section_name ============== : ', section_name)
#             config.add_section(section_name)
#             data = json.loads(conf_final[section_name][0])
#             if type(data) == str:
#                 data = literal_eval(data)
#             for key, value in data.items():

#                 config.set(section_name, key, value)     

#     else:
#         if( accountName != ""):
#             accountConfig = configparser.RawConfigParser()

#             if (os.getenv('IKON_CONFIG_HOME')):
#                 accountConfigFile = os.path.join(os.getenv('IKON_CONFIG_HOME'), accountName, "ConfigFile.properties")
#             else:
#                 accountConfigFile = os.path.join(os.getcwd(), "conf", accountName, "ConfigFile.properties")

#             accountConfig.read(accountConfigFile)

#             for sectionKey in accountConfig :
#                 for key in accountConfig[sectionKey]:
#                     value = accountConfig.get(sectionKey, key)
#                     config.set(sectionKey, key, value)

#     return config

def get_config(accountName=""):
    config = configparser.RawConfigParser()
    
    if (os.getenv('ROOCA_CONFIG_HOME')):
        configFile = os.path.join(os.getenv('ROOCA_CONFIG_HOME'), "CommonConfigFile.properties")
    else:
        configFile = os.path.join(os.getcwd(), "conf", "CommonConfigFile.properties")
    config.read(configFile)
    config_Db = config.get('GenericSection', 'conf.Db')
    
    if int(config_Db) == 1 and accountName != "":
        try:
            dbName = config.get('DatabaseSection', 'database.dbname')
            host = config.get('DatabaseSection', 'database.host')
            port = config.get('DatabaseSection', 'database.port')
            schema = config.get('DatabaseSection', 'database.schema')
            user = config.get('DatabaseSection', 'database.user')
            password = config.get('DatabaseSection', 'database.password')
            #print('@@@@@@@@ Database', dbName)
            #print('@@@@@@@@ schema', schema)
            psql = DatabaseFunctions(host, user, password, port, dbName, schema)

            conf_final = psql.select_df('ikon_account_config', 'account_name', [accountName])
            # print('@@@@@@@@ Reading ikon_account_config :', conf_final)
            conf_final = conf_final.drop(['account_name'], axis=1)
            # conf_final.to_excel('conf_final.xlsx')
            conf_final = conf_final.reset_index(drop=True)
            # print(conf_final.dtypes)
            config = configparser.ConfigParser()

            for section_name in conf_final.columns:
                # print('@@@@@@@@@@@@@section_name: ', section_name)
                try:
                    config.add_section(section_name)
                    data = json.loads(conf_final[section_name][0])
                    # print('@@@@@@@@@@@@@data: ', data)
                    if isinstance(data, str):
                        data = json.loads(data)  # Parse the JSON data
                    for key, value in data.items():
                        config.set(section_name, key, value)
                        #print(f'@@@@@@@@@@@@@common functions config.set({section_name}, {key}, {value})')
                except Exception as e:
                    print(f"Error processing section '{section_name}': {e}")
        except Exception as error:
            print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(error).__name__, error)
            print('common==>  ', error)
    else:
        if(accountName != ""):
            accountConfig = configparser.RawConfigParser()

            if (os.getenv('ROOCA_CONFIG_HOME')):
                accountConfigFile = os.path.join(os.getenv('ROOCA_CONFIG_HOME'), accountName, "ConfigFile.properties")
            else:
                accountConfigFile = os.path.join(os.getcwd(), "conf", accountName, "ConfigFile.properties")
                #print(accountConfigFile)

            accountConfig.read(accountConfigFile)

            for sectionKey in accountConfig:
                for key in accountConfig[sectionKey]:
                    value = accountConfig.get(sectionKey, key)
                    config.set(sectionKey, key, value)
                    # print(f'@@@@@@@@@@@@@schedule_common config.set({sectionKey}, {key}, {value})')

    return config

def AwsResponseValidation(data):
    data = literal_eval(data.decode('utf8'))
    data = data['value']
    data = data.replace('"{"','{"').replace('"}"','"}')
    data = json.loads(data)
    data = list(data.values())[0]
    usrName = data['user']
    Pwd = data['password']
    return[Pwd, usrName] 

 
def get_dbdetail(config):

    dbDetail = {}

    dbDetail['dbName'] = config.get('DatabaseSection', 'database.dbname')
    dbDetail['host'] = config.get('DatabaseSection', 'database.host')
    dbDetail['port'] = config.get('DatabaseSection', 'database.port')
    dbDetail['schema'] = config.get('DatabaseSection', 'database.schema')
    
    awssection = int(config.get('AWSSection', 'API.proposal'))
    azuresection = int(config.get('VaultSection', 'azure.keyvault'))
    if awssection == 1:
    #if( "API.proposal" in config["AWSSection"] and int(config.get('AWSSection', 'API.proposal'))) == 1:
        try:
            token =config.get('AWSSection', 'API.token')
            url = config.get('AWSSection', 'API.url')
            tenentUserName = config.get('DatabaseSection', 'database.user')
            tenentPasword = config.get('DatabaseSection', 'database.password')
            url_username = url+'key='+str(tenentUserName)
            url_Pasword = url+'key='+str(tenentPasword)
            payload_header = {"Content-Type":"application/json", "Authorization": "Bearer "+str(token)}
            response = requests.get(url = url_username, headers =payload_header)
            if response.status_code == 200 or response.status_code == 201:
                print("response status is ", str(response.status_code))
            else:
                print("response status is ", str(response.status_code))
            validation_result = AwsResponseValidation(response.content)
            dbDetail['user'] = validation_result[1]
            dbDetail['password'] = validation_result[0]
        except Exception as e:
            raise Exception("Unable to get the DB detail from AWSkeyManager")
    # elif( "azure.keyvault" in config["VaultSection"] and int(config.get('VaultSection', 'azure.keyvault')) == 1):
    elif azuresection == 1:

        client_id = config.get('VaultSection', 'azure.application.client.id')
        tenant_id = config.get('VaultSection', 'azure.application.tenant.id')
        client_secret = config.get('VaultSection', 'azure.application.client.key')
        KeyUri = config.get('VaultSection', 'azure.secret.vault.url')

        try:
            credentials = ClientSecretCredential(client_id=client_id, client_secret=client_secret,tenant_id=tenant_id)
            secrets = SecretClient(vault_url=KeyUri, credential=credentials)

            userkey = config.get('DatabaseSection', 'database.user')
            passwordkey = config.get('DatabaseSection', 'database.password')

            dbDetail['user'] = secrets.get_secret(userkey).value
            dbDetail['password'] = secrets.get_secret(passwordkey).value

        except Exception as e:
            raise "Unable to get the DB detail from vault"

    else:
        dbDetail['user'] = config.get('DatabaseSection', 'database.user')
        dbDetail['password'] = config.get('DatabaseSection', 'database.password')

    return dbDetail

################################################################################################
common_config = get_config()
send_mail_flag = int(common_config.get('GenericSection', 'send.email'))
run_transaction_flag = int(common_config.get('GenericSection', 'run.transaction'))
extended_stop_words_list = common_config.get('GenericSection', 'stop.words').split(",")
# ignoreNouns = int(common_config.get('GenericSection', 'ignore.nouns'))
scriptTrigger = int(common_config.get('Multitanancy', 'insert.script.trigger'))

stop_words = list(get_stop_words('en'))
nltk_words = list(stopwords.words('english'))
stop_words.extend(nltk_words)

lemmatizer = WordNetLemmatizer()
wpt = nltk.RegexpTokenizer("[\w']+")
stop_words = nltk.corpus.stopwords.words('english')
extended_stop_words = [extended_stop_word.strip() for extended_stop_word in extended_stop_words_list]
stop_words.extend(extended_stop_words)

######################################### FOR MULTILINGUAL #######################################

from pycountry import languages

class multilingual:

    def __init__(self, account):
        self.account = account
        
        config = get_config(self.account)
        
        # config = configparser.RawConfigParser()
        # accountConfig = configparser.RawConfigParser()
        # configFile = os.path.join(os.getcwd(), "conf", "CommonConfigFile.properties")
        # config.read(configFile)  

        
        # accountConfigFile = os.path.join(os.getcwd(), "conf", self.account, "ConfigFile.properties")
        # accountConfig.read(accountConfigFile)

        # for sectionKey in accountConfig :
            # for key in accountConfig[sectionKey]:
                # value = accountConfig.get(sectionKey, key)
                # config.set(sectionKey, key, value)

        self.default_lang = config.get('SupportLanguage', 'default_lang')
        support_langs = config.get('SupportLanguage', 'lang_supported')
        self.support_langs = ast.literal_eval(support_langs)
        self.multi_language = int(config.get('SupportLanguage', 'multi_language'))

        path=os.getcwd() 
        if( self.multi_language == 1) :
            import fasttext
            try:
                self.PRETRAINED_MODEL_PATH = path+'\\fasttext_model\\lid.176.bin'
                self.fasttext = fasttext.load_model(self.PRETRAINED_MODEL_PATH)
            except Exception as e:
                print(e)


    def lang_detection(self, text):
        if( self.multi_language == 1) :
            try:
                text=text.replace('\n','') 
                predictions = self.fasttext.predict(text)
                shortlang = predictions[0][0][-2:]
                lang_name = languages.get(alpha_2 = shortlang).name   
                lang_name = lang_name.lower()

            except Exception as e:
                return self.default_lang.lower()
                
            if lang_name in self.support_langs.keys():
                return lang_name
            else:
                return self.default_lang.lower()
        else:
            return self.default_lang.lower()

    def process_text(self, config, langauge, text):
        
        remove_word = config.get('SupportLanguage', langauge+"_preproce_remove_word")
        replace_word = config.get('SupportLanguage', langauge+"_preprocessing_replace_word")
        remove_word = '|'.join(remove_word.split(','))
        text = str(text)
        text = text.lower()
        text = ' '.join([word for word in text.split() if word not in remove_word])
        text = re.sub(r'\d{4}-\d{2}-\d{2}', ' ', text)
        text = re.sub(r'\d{2}:\d{2}:\d{2}', ' ', text)
        text = re.sub(r'http\S+', ' ', text)
        text = re.sub(r'<.*?>', '', text)
        text = re.sub(r'#+', ' ', text)
        text = re.sub(r'_', ' ', text)
        text = re.sub(r'\S+@\S+', ' ', text)
        text = re.sub(r"([A-Za-z]+)'s", r"\1 is", text)
        try:
            for words in replace_word.split(','):
                replace_word_list = words.split(":")
                text = text.replace(replace_word_list[0], replace_word_list[1])
        except Exception as error:
            pass
        text = re.sub(r'\W', ' ', text)
        text = re.sub(r'\b\d+\b',' ', text)
        # text = re.sub(r'\d+', ' ', text)
        text = re.sub(r'\s+', ' ', text)
        text = re.sub(r'\b\w{1,2}\b', '', text)

        return text


    def load_model(self, support_langs):
        load_lemma_model=dict()
        for long_name,short_name in support_langs.items():
            load_lemma_model[long_name] = simplemma.load_data(short_name) 
            
        return load_lemma_model


    def oneliner_for_processing(self, load_lemma_model, lang, sentence):
        stopwords = set(nltk.corpus.stopwords.words(lang))
        if len(sentence) != 0:  
            final_array =[simplemma.lemmatize(word, load_lemma_model[lang] ) for word in (word_tokenize(sentence)) if word not in stopwords]
            return " ".join(final_array)
        return ""
        
    def oneliner_for_processing_2(self, load_lemma_model, lang, sentence):
        stopwords = set(nltk.corpus.stopwords.words(lang))
        if len(sentence) != 0:  
            final_array =[simplemma.lemmatize(word, load_lemma_model[lang] ) for word in (word_tokenize(sentence))] # if word not in stopwords]
            return " ".join(final_array)
        return ""
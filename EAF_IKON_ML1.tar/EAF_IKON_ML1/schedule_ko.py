import configparser
import subprocess
import threading
import sys, getopt
from schedule_common import get_common_args, get_config, reset_account_process, check_process, end_process

# Arguments
argumentList = sys.argv[1:]

args_list = get_common_args(argumentList)
accountName = args_list[0]
processName = args_list[1]
sub_process_args = '--accountName ' + accountName


def  ko_score():
    ##################### calling incident score file #########################
    print('python '+commonsFolderPath+'ko_score_common.py '+ sub_process_args)
    ko_score_result = subprocess.call('python ' + commonsFolderPath + 'ko_score_common.py '+ sub_process_args)#, shell=True)
    
    print(ko_score_result)
    
  

try:
    config = get_config(accountName)
    commonsFolderPath = config.get('PathsSection', 'path.commons')
    multitenant = int(config.get('Multitanancy', 'check.running.process'))

    
except Exception as e:
    print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
    print(str(e))
    
else:
    ########################## declaring threads #############################
    if check_process(accountName, processName):
        sys.exit()
    
try:
 
    if multitenant == 1:
        reset_account_process(accountName, processName)
    t1 = threading.Thread(target=ko_score) 
    t1.start() 
    t1.join()
    

except Exception as e:
    print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
    print(str(e))

finally:
    print('KO Feed Processed!')
    end_process(accountName, processName)    

